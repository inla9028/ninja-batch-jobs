SELECT a.org_priceplan, a.new_priceplan, a.org_soc, b.new_soc
  FROM mw_tmp_dups a, priceplan_replacements b
  WHERE a.org_priceplan = b.org_priceplan
  AND a.new_priceplan = b.new_priceplan
  AND a.org_soc = b.org_soc
  ORDER BY b.new_priceplan, b.org_soc, b.new_soc
