 select process_status, count(*)
  from batch_charge_addition a
  where charge_code='FLEX' and record_creation_date > sysdate -1
GROUP BY process_status
