UPDATE batch_charge_addition b
SET b.stream = '9'
WHERE b.transaction_number IN 
(SELECT	*
FROM	(
SELECT  transaction_number
FROM	 batch_charge_addition
WHERE	 stream =  '6' AND process_status = 'WAITING'
ORDER BY transaction_number desc
)
WHERE	rownum <= 100);
COMMIT;
