 select to_char(a.process_time, 'MMDD HH24:MI') AS time, count(*)
  from batch_charge_addition a
  where charge_code='FLEX' and record_creation_date > sysdate -1
  AND a.process_status = 'PRSD_SUCCESS'
  AND a.stream <> '1'
  GROUP BY to_char(a.process_time, 'MMDD HH24:MI')

