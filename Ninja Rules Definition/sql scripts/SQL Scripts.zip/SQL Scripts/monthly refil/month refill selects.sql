
  
  select process_status, count(*)
  from batch_charge_addition a
  where charge_code='FLEX' and record_creation_date > sysdate -1
  group by process_status
  
  select process_status, count(*), TO_CHAR(sysdate,'HH24MISS')
  from  batch_charge_addition a
  where charge_code='FLEX' and record_creation_date > sysdate -1
  group by process_status
  
  select * from batch_charge_addition
  where charge_code='FLEX' and record_creation_date > sysdate -1
  and process_status='PRSD_ERROR'
  and status_desc not like 'Cannot add charge to subscription on this ban. Unable to add one-time charge to pre-paid ban%'
  
  
  update batch_charge_addition
  set stream = DECODE(mod(subscriber_no,10)+1,null,1,mod(subscriber_no,10)+1)
  where process_status='WAITING'
  and charge_code='FLEX';
  commit;
  
  update batch_charge_addition
  set stream = 5
  where process_status='WAITING'
  and stream = 10
  and rownum < 50
  and charge_code='FLEX';
  commit;
  
  select stream, count(*)
  from batch_charge_addition
  where charge_code='FLEX'
  and process_status='WAITING'
  group by stream;
  
  select count(*) from monthly_refill_charges
  
  select * from ninja_jobs_control
