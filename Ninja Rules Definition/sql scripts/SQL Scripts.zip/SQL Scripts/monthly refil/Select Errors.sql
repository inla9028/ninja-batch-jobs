SELECT a.transaction_number, a.ban_no, a.subscriber_no, a.charge_code,
       a.actv_reason_code, a.amount, a.user_bill_text, a.memo_text,
       a.effective_date, a.process_status, a.process_time,
       a.status_desc, a.record_creation_date, a.request_id, a.stream,
       a.request_user_id
  FROM batch_charge_addition a
  where a.charge_code='FLEX' and a.record_creation_date > sysdate -1
  AND a.process_status = 'PRSD_ERROR'
