PROMPT Creating index: EXT_DRIVER_IDX1
CREATE INDEX	ext_driver_idx1
ON		ext_driver( old_id  )
TABLESPACE	cnvrt_index;
