select c_cycle_code,c_cont_status,count(*) from contract
where c_cycle_code = '10'
group by c_cycle_code,c_cont_status;
