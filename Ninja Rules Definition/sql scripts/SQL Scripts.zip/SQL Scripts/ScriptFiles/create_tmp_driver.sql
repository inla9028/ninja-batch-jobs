insert into tmp_driver select substr(old_id, 1,8), substr(old_id, 9, 2) from mdcust.acc_trans_key

commit;
