select kmbn_activation_status,count(*)
from    kmbn_activate_header
group by kmbn_activation_status
