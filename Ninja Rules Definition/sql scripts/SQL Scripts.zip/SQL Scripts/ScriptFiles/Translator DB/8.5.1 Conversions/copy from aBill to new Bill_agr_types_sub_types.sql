INSERT INTO bill_agr_types_sub_types
SELECT * FROM abill_agr_types_sub_types;
COMMIT;
