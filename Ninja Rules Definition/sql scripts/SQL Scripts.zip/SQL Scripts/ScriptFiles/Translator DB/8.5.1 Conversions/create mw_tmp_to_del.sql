TRUNCATE TABLE mw_tmp_to_del REUSE STORAGE;
INSERT into mw_tmp_to_del
--CREATE TABLE mw_tmp_to_del AS 
SELECT MIN(rowid) AS rowid_to_delete
FROM abill_agr_types_sub_types a
  GROUP BY a.agreement_type, a.ban_tree_ind,
       a.account_type, a.account_sub_type, a.org_priceplan,
       a.new_priceplan, a.org_commitment_band, a.new_commitment_months,
       a.new_campaign_id, a.remaining_com_months,
       a.subscription_type_id,
       a.handset_provisioning
       HAVING COUNT(*) > 1
       

