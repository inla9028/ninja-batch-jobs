-- Start of DDL Script for Table NINJADEVRULES.ABILL_AGR_TYPES_SUB_TYPES
-- Generated 11-nov-2004 22:50:08 from NINJADEVRULES@NINJA.WSRV1.NETCOM-GSM.NO

CREATE TABLE abill_agr_types_sub_types
    (bill_agr_types_sub_id          NUMBER(6,0) NOT NULL,
    agreement_type                 VARCHAR2(15) NOT NULL,
    ban_tree_ind                   VARCHAR2(1) NOT NULL,
    account_type                   VARCHAR2(1) NOT NULL,
    account_sub_type               VARCHAR2(2) NOT NULL,
    org_priceplan                  VARCHAR2(9) NOT NULL,
    new_priceplan                  VARCHAR2(9) NOT NULL,
    org_commitment_band            VARCHAR2(1),
    new_commitment_months          NUMBER(2,0) NOT NULL,
    new_campaign_id                VARCHAR2(9) NOT NULL,
    remaining_com_months           NUMBER(2,0) NOT NULL,
    subscription_type_id           VARCHAR2(15) NOT NULL,
    effective_date                 DATE NOT NULL,
    expiration_date                DATE NOT NULL,
    handset_provisioning           VARCHAR2(1))
/

-- Indexes for ABILL_AGR_TYPES_SUB_TYPES

CREATE UNIQUE INDEX abil_tmp_idx1 ON abill_agr_types_sub_types
  (
    bill_agr_types_sub_id           ASC
  )
/



-- End of DDL Script for Table NINJADEVRULES.ABILL_AGR_TYPES_SUB_TYPES

