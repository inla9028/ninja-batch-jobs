  update address_data SET adr_p1 = NULL,
                          adr_p2 = NULL,
                          adr_p3 = NULL,
                          adr_p4 = NULL,
                          adr_p5 = NULL,
                          adr_p6 = NULL,
                          adr_p7 = NULL,
                          adr_p8 = NULL,
                          adr_p9 = NULL,
                          adr_p10 = NULL;
COMMIT;                          
                          
                          

