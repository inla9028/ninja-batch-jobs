delete
from	uf_soc_uf0070
WHERE	(uf0070_old_id, uf0070_subscriber_no, uf0070_soc) IN
	(select	uf0070_old_id, uf0070_subscriber_no, uf0070_soc
	from	uf_soc_uf0070,cnvrt_error
	where	uf0070_old_id like acct || contract || '%' and
      		uf0070_ftr_special_telno = msisdn and
            uf = '2000' and error_no = 23)
/
