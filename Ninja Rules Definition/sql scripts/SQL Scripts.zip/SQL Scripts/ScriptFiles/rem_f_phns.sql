delete from uf_number_uf0130
where exists
(select ' ' from tmp_fucked_phones
where substr(uf0130_ctn,5,10) = tmp_f_phn)
