
-- Start of DDL script for NINJA_SUB_CHANGE_STATUS
-- Generated 10-sep-02  7:41:32 am
-- from kontant-KONTANT:3

-- Table NINJA_SUB_CHANGE_STATUS

CREATE TABLE ninja_sub_change_status
 (
  trans_number               NUMBER(9) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  action_code                VARCHAR2(7) NOT NULL,
  memo_text                  VARCHAR2(200),
  reason_code                VARCHAR2(15),
  fee_waiver_code            VARCHAR2(15),
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  priority                   NUMBER(1) DEFAULT 3 NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) DEFAULT 'WAITING' NOT NULL,
  status_desc                VARCHAR2(300),
  request_reference_id       VARCHAR2(6)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_SUB_CHANGE_STATUS

COMMENT ON TABLE ninja_sub_change_status IS 'Table for Storing Requests for Subscriber Status Changes (Suspend/Resume or Cancel) to Ninja'
/

-- Column Comments for NINJA_SUB_CHANGE_STATUS

COMMENT ON COLUMN ninja_sub_change_status.action_code IS 'Action Code - ''CANCEL'',''SUSPEND'' or ''RESUME'' (note Subcription must be Active for SUSPEND, Active or Suspended for CANCEL and Suspended for RESUME)'
/
COMMENT ON COLUMN ninja_sub_change_status.enter_time IS 'Time of Entering the Request'
/
COMMENT ON COLUMN ninja_sub_change_status.fee_waiver_code IS 'Fee Waiver Code to be used - If none is specified will use the system defaults)'
/
COMMENT ON COLUMN ninja_sub_change_status.memo_text IS 'Memo Text to be written into Fokus for the activity'
/
COMMENT ON COLUMN ninja_sub_change_status.priority IS 'Priority of the transaction. (values 1 thru 9), Default is 3'
/
COMMENT ON COLUMN ninja_sub_change_status.process_status IS 'Default Value ''WAITING'', (PRSD_SUCCESS or PRSD_ERROR - will be updated by Ninja)'
/
COMMENT ON COLUMN ninja_sub_change_status.process_time IS 'Time the request was processed by Ninja'
/
COMMENT ON COLUMN ninja_sub_change_status.reason_code IS 'Valid Fokus Reason Code to be used for the Activity.'
/
COMMENT ON COLUMN ninja_sub_change_status.request_time IS 'Time the Request Should be processed (earliest activation date/time)'
/
COMMENT ON COLUMN ninja_sub_change_status.status_desc IS 'Dsecriptive text in case of PRSD_ERROR'
/
COMMENT ON COLUMN ninja_sub_change_status.subscriber_no IS 'Subscriber where the transaction must be carried out'
/
COMMENT ON COLUMN ninja_sub_change_status.trans_number IS 'Unique transaction number.'
/
COMMENT ON COLUMN ninja_sub_change_status.request_reference_id IS 'Free text to associate the requestor to the transactions'
/
-- Indexes for NINJA_SUB_CHANGE_STATUS

CREATE  INDEX ninja_sub_chg_stat_idx1
 ON ninja_sub_change_status
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

CREATE  INDEX ninja_sub_chg_stat_idx2
 ON ninja_sub_change_status
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_SUB_CHANGE_STATUS

ALTER TABLE ninja_sub_change_status
 ADD CONSTRAINT ninja_sub_chg_stat_pk1 PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn1 CHECK ( PROCESS_STATUS IN ('IN_PROGRESS','WAITING','PRSD_ERROR','PRSD_SUCCESS')  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn2 CHECK ( ACTION_CODE IN ('CANCEL','RESUME','SUSPEND')  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn3 CHECK ( priority BETWEEN 1 AND 5  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn4 CHECK ( subscriber_no LIKE 'GSM047%' )
/


-- Triggers for NINJA_SUB_CHANGE_STATUS
CREATE SEQUENCE ninja_sub_chg_stat_seq
 INCREMENT BY 1
 START WITH 1
 MINVALUE 1
 MAXVALUE 999999999999999999999999999
 NOCYCLE
 ORDER
 CACHE 20
/


CREATE OR REPLACE TRIGGER ninja_sub_chg_stat_trg1
BEFORE INSERT
ON ninja_sub_change_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	ninja_sub_chg_stat_seq.nextval
		INTO	:new.trans_number
		FROM	dual;
        
        SELECT sysdate
        INTO :new.enter_time
        FROM dual;
        IF :new.request_time IS NULL
        THEN
            :new.request_time := :new.enter_time;
        END IF;
        
END;
/

-- End of DDL script for NINJA_SUB_CHANGE_STATUS
