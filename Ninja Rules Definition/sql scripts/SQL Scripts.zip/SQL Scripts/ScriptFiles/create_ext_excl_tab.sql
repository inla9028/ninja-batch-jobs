
-- Start of DDL script for EXT_CROSS_EXCL
-- Generated 11-Sep-99  6:41:49 pm
-- from wh-CNVRTD:2

-- Table EXT_CROSS_EXCL

CREATE TABLE ext_cross_excl
 (
  old_id                     VARCHAR2(14)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     20M
      NEXT        10M
      PCTINCREASE 0
   )
/

-- End of DDL script for EXT_CROSS_EXCL
