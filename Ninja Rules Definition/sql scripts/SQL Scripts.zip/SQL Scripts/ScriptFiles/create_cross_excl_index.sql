CREATE INDEX	ext_cross_excl_idx1
ON		ext_cross_excl( old_id )
TABLESPACE	cnvrt_index ;

