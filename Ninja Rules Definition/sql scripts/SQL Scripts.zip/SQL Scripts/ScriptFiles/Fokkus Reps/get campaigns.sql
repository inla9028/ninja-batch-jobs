
 SELECT
    CAMPAIGN_SEQ,
    CAMPAIGN,
    EFFECTIVE_DATE,
    CUSTOMER_TYPE,
    CUSTOMER_SUBTYPE,
    MIN_COMMIT_PERIOD,
    PP_CODE,
    DISCOUNT_GROUP_CODE,
    ACT_FEE,
    DLR_ACT_FEE,
    PENALTY_AMOUNT,
    PENALTY_PROR_IND,
    SALE_EFF_DATE,
    SALE_EXP_DATE,
    EXPIRATION_DATE
 FROM NTCREFWAIT.CAMPAIGN_COMMITMENTS
 where pp_code in ('PSFA','PSFB','PSKV')
 and nvl(sale_exp_date, sysdate + 1) > sysdate
 and nvl(expiration_date, sysdate + 1) > sysdate
order by pp_code, campaign
