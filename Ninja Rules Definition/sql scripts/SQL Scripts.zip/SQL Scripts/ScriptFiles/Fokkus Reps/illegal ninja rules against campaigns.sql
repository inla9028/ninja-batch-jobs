select *
from bill_agr_types_sub_types 
where sysdate between effective_date and expiration_date
and new_campaign_id <> '000000000'
and not exists (select ' ' 
                  FROM CAMPAIGN_COMMITMENTS@prod.world
                  where new_campaign_id = rtrim(campaign)
                  and nvl(sale_exp_date, sysdate + 1) > sysdate
                  and nvl(expiration_date, sysdate + 1) > sysdate)
                    
