SELECT a.campaign_seq, a.campaign, c.campaign_desc, a.effective_date, a.customer_type,
       a.customer_subtype, a.min_commit_period, a.pp_code,
       a.discount_group_code, b.disc_group_desc, a.penalty_amount, a.penalty_pror_ind, a.sale_eff_date,
       a.sale_exp_date, a.expiration_date, a.imei_ind
  FROM campaign_commitments a, discount_group b, campaign c
  WHERE a.discount_group_code IS NOT NULL
  AND a.expiration_date IS NULL
  AND a.campaign = c.campaign
  AND a.discount_group_code = b.discount_group_code
  AND  b.expiration_date IS NULL 
  ORDER BY a.pp_code,a.campaign
  
