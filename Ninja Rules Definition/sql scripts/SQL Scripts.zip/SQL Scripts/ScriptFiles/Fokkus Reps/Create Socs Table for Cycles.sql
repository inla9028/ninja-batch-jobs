CREATE TABLE mw_tmp_gprs02 AS
SELECT a.customer_id, a.subscriber_no
FROM ntcappo.service_agreement a
WHERE a.soc = 'GPRS02' 
AND a.expiration_date > SYSDATE
AND EXISTS (SELECT ' ' 
            FROM ntcappo.billing_account b
            WHERE b.customer_id = a.customer_id
            AND b.bill_cycle IN (3,5))
