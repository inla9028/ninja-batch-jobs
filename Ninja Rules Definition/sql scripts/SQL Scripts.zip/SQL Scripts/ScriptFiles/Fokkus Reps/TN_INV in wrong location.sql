SELECT a.ctn, b.phy_hlr, c.phd_id, a.sys_creation_date, a.sys_update_date, a.operator_id,
       a.application_id, a.dl_service_code, a.dl_update_stamp,
       a.last_trx_date, a.last_trx_code, a.last_trx_uid, a.ctn_status,
       a.nl, a.ngp, a.special_trx_date, a.tn_in_use, a.reason, a.pni,
       a.special_trx_no, a.conv_run_no
  FROM tn_inv a, msisdn_hlr_relation b, logic_phd c
  WHERE a.nl = 'NET' AND a.ctn_status = 'AA'
  AND a.ctn BETWEEN b.msisdn_begin_range AND b.msisdn_end_range
  AND b.phy_hlr = c.logical_dvc_id
--  AND c.phd_id <> '01'
