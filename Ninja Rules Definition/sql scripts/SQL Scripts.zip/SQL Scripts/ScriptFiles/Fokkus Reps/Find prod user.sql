select * from users@prod
where user_id = 200449
