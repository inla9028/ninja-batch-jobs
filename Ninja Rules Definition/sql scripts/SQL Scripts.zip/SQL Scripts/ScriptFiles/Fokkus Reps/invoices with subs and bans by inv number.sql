SELECT a.root_ban, a.ban, a.bill_seq_no, b.inv_seq_no, c.subscriber_no
  FROM bill a, mw_tmp_invs b, bill_ctn c
  WHERE a.invoice_seq_no = b.inv_seq_no
  AND c.root_ban = a.root_ban
  AND c.ban = a.ban 
  AND c.bill_seq_no = a.bill_seq_no
  ORDER BY a.root_ban, a.ban, b.inv_seq_no, c.subscriber_no
