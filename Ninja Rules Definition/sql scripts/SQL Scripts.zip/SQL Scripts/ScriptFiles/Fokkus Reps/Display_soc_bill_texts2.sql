select a.soc,a.soc_description,b.desc_text from soc a, bill_desc b
 where a.soc like 'MC%'
 and b.language_code = 'NO' and b.bill_desc_seq_num = a.soc_desc_seq
 and a.expiration_date is null
 order by a.soc
