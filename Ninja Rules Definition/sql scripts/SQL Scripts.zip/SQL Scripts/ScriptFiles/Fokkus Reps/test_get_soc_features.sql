SELECT	t1.soc,
        t2.feature_code,
        t2.mps_feature_code,
        t2.service_level,
        t2.feature_desc,
        t2.switch_code,
        t2.csm_param_req_ind,
        t2.def_sw_params,
        t2.feature_type,
        t2.msisdn_criteria,
        t2.tn_class_cd,
        t1.rc_info_ind,
        t3.mutual_exclus_ind,
        t3.switch_code AS ftr_switch_code,
        t1.fr_fm_plan_cd,
        t1.max_members,
        t1.fr_fm_free_digits
        FROM	rated_feature t1,
        feature t2,
        feature_types t3
        WHERE	t1.soc in ('VMBED','VMSTO+') AND
        t2.feature_code = t1.feature_code AND
        t2.feature_group = 'SF' AND
        t1.effective_date <= sysdate AND
        NVL(t1.expiration_date, sysdate +1) >= sysdate AND
        t3.feature_type = t2.feature_type
        ORDER BY t1.soc,t1.feature_code
