select a.subscriber_no, rtrim(a.soc) as PRICEPLAN , rtrim(b.soc) as MMSSOC
from service_agreement a, service_agreement b
where a.service_type = 'P'
and nvl(a.expiration_date, sysdate+1) > sysdate
and a.customer_id = b.customer_id
and a.subscriber_no = b.subscriber_no
and nvl(b.expiration_date, sysdate+1) > sysdate
and b.soc like 'MMS%'
