select * from soc_illegal_comb@prod.world
where soc_first like 'MC%' or soc_second like 'MC%'
and expiration_date is null and illegal_ind = 'Y'
