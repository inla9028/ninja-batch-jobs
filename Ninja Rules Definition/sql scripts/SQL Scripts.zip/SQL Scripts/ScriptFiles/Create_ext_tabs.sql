CREATE TABLE cnvrt_driver
 (
  c_acct                     VARCHAR2(8),
  c_contract                 VARCHAR2(2)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     40M
      NEXT        20M
      PCTINCREASE 0
   )
/

CREATE TABLE ext_cross_excl
 (
  old_id                     VARCHAR2(14)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     20M
      NEXT        10M
      PCTINCREASE 0
   )
/

-- Table CNVRT_ERROR

CREATE TABLE cnvrt_error
 (
  uf                         VARCHAR2(4),
  error_no                   NUMBER,
  severity                   VARCHAR2(1),
  acct                       VARCHAR2(8),
  contract                   VARCHAR2(2),
  sim                        VARCHAR2(20),
  msisdn                     VARCHAR2(20),
  description                VARCHAR2(255),
  uf_rec                     VARCHAR2(2100)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     50M
      NEXT        25M
      PCTINCREASE 0
   )
/

-- Comments for CNVRT_ERROR

COMMENT ON TABLE cnvrt_error IS 'Error File for Conversion'
/


-- Start of DDL script for CNVRT_EXT
-- Generated 14-Aug-99  1:10:53 pm
-- from wh-CNVRTD:1

-- Table CNVRT_EXT

CREATE TABLE cnvrt_ext
 (
  cnvrt_srt_key              NUMBER(9),
  cnvrt_record               VARCHAR2(2100)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     999M
      NEXT        500M
      PCTINCREASE 0
   )
/

-- End of DDL script for CNVRT_EXT

-- Start of DDL script for CNVRT_EXT1
-- Generated 14-Aug-99  1:11:15 pm
-- from wh-CNVRTD:1

-- Table CNVRT_EXT1

CREATE TABLE cnvrt_ext1
 (
  cnvrt_srt_key              NUMBER(9),
  cnvrt_record               VARCHAR2(2100)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     100M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- End of DDL script for CNVRT_EXT1

-- Start of DDL script for CNVRT_EXT2
-- Generated 14-Aug-99  1:11:42 pm
-- from wh-CNVRTD:1

-- Table CNVRT_EXT2

CREATE TABLE cnvrt_ext2
 (
  cnvrt_srt_key              NUMBER(9),
  cnvrt_record               VARCHAR2(2100)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     100M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- End of DDL script for CNVRT_EXT2

-- Start of DDL script for CNVRT_EXT3
-- Generated 14-Aug-99  1:12:09 pm
-- from wh-CNVRTD:1

-- Table CNVRT_EXT3

CREATE TABLE cnvrt_ext3
 (
  cnvrt_srt_key              NUMBER(9),
  cnvrt_record               VARCHAR2(2100)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     200M
      NEXT        100M
      PCTINCREASE 0
   )
/

-- End of DDL script for CNVRT_EXT3

-- Start of DDL script for CNVRT_SUBS
-- Generated 14-Aug-99  1:12:31 pm
-- from wh-CNVRTD:1

-- Table CNVRT_SUBS

CREATE TABLE cnvrt_subs
 (
  subscriber_no              VARCHAR2(20)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     100M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- Comments for CNVRT_SUBS

COMMENT ON TABLE cnvrt_subs IS 'Conversion of subs'
/

-- End of DDL script for CNVRT_SUBS

-- Start of DDL script for EXT_DRIVER
-- Generated 14-Aug-99  1:14:00 pm
-- from wh-CNVRTD:1

-- Table EXT_DRIVER

CREATE TABLE ext_driver
 (
  old_id                     VARCHAR2(14)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     75M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- End of DDL script for EXT_DRIVER

-- Start of DDL script for TMP_BAN
-- Generated 14-Aug-99  1:14:29 pm
-- from wh-CNVRTD:1

-- Table TMP_BAN

CREATE TABLE tmp_ban
 (
  tmp_acct                   VARCHAR2(8),
  tmp_contract               VARCHAR2(2)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     50M
      NEXT        25M
      PCTINCREASE 0
   )
/

-- Comments for TMP_BAN

COMMENT ON TABLE tmp_ban IS 'Contains the BAN''s that will be Migrated'
/


-- Table MIGRATED_PHNS

CREATE TABLE migrated_phns
 (
  m_phone                    VARCHAR2(18)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     40M
      NEXT        20M
      PCTINCREASE 0
   )
/

-- Comments for MIGRATED_PHNS

COMMENT ON TABLE migrated_phns IS 'Migrated Phones to Fokus'
/

-- Grants for MIGRATED_PHNS

GRANT SELECT ON migrated_phns TO cnvrtb WITH GRANT OPTION
/



-- End of DDL script for TMP_BAN
