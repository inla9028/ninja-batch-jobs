
CREATE TABLE tmp_phone_err
 (
  tmp_phn                    VARCHAR2(18)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for TMP_PHONE_ERR

CREATE  INDEX tmp_p_e_idx1
 ON tmp_phone_err
  ( tmp_phn  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE cnvrt_index
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/




insert into tmp_phone_err
select msisdn from cnvrt_error where uf = '0130';


select pag_f.* from tmp_phone_err,pag_f
where
c_phone = tmp_phn
and c_pag_phone_status IN ('AC','SU')



update phone_no
set c_acn = (select pag_f.c_acct from pag_f where
	     c_phone = pag_f.c_phone 
	     and c_pag_phone_status IN ('AC','SU') and rownum = 1)
where c_phone in
(select tmp_phn from tmp_phone_err
where tmp_phn = c_phone)

update phone_no
set c_phn_contract = (select pag_f.c_contract from pag_f where
	     c_phone = pag_f.c_phone 
	     and c_pag_phone_status IN ('AC','SU') and rownum = 1)
where c_phone in
(select tmp_phn from tmp_phone_err
where tmp_phn = c_phone)

update phone_no
set c_phn_esn_sim = (select pag_f.c_esn_sim from pag_f where
	     c_phone = pag_f.c_phone 
	     and c_pag_phone_status IN ('AC','SU') and rownum = 1)
where c_phone in
(select tmp_phn from tmp_phone_err
where tmp_phn = c_phone)


