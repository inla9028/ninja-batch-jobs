
 SELECT
    JOB_ID,
    JOB_STATUS,
    WAS_RUNNING,
    SLEEP_TIME,
    SLEEP_MODE,
    NEXT_EXEC_TIME,
    STATUS_TIME,
    STATUS_DESC,
    BEAN,
    METHOD,
    URL,
    USER_NAME,
    PASSWORD,
    JOB_DESC
 FROM NINJA.NINJA_JOBS
order by job_id
