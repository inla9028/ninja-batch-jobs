select * from service_transactions where soc = 'GPRS02' and process_status = 'PRSD_ERROR' and to_char(process_time,'YYYYMMDD') = '20020110'
