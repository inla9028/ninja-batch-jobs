select to_char(process_time, 'YYYYMMDD'), process_status, count(*)
from service_transactions
where soc = 'GPRS02'
group by to_char(process_time, 'YYYYMMDD'), process_status
