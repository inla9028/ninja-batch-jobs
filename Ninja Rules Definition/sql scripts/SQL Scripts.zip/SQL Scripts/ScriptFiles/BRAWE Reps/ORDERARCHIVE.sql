SELECT a.ordernumber, a.orderdate, a.usecasename, a.xml, a.activation,
       a.bannumber, a.mannumber, a.systemname, a.stacktrace, a.login,
       a.fokuscode, a.dealercode, a.username, a.activation_reason
  FROM orderarchive a
  where orderdate > to_date(to_char(sysdate,'YYYYMMDD'),'YYYYMMDD')


  
