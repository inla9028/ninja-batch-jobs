CREATE TABLE master_chg_pp_trans
 (
  subscriber_no              VARCHAR2(20) NOT NULL,
  new_priceplan              VARCHAR2(9) NOT NULL,
  new_campaign_code          VARCHAR2(9) NOT NULL,
  new_subscription_type      VARCHAR2(15) NOT NULL,
  handle_commitment          VARCHAR2(1) NOT NULL,
  effective_date             DATE,
  dealer                     VARCHAR2(6),
  sales_agent                VARCHAR2(6),
  reason_code                VARCHAR2(5) NOT NULL,
  memo_text                  VARCHAR2(200),
  waive_fees                 VARCHAR2(1) NOT NULL,
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(200),
  priority                   NUMBER(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_chg_pp_trans IS 'Holds transactions for priceplan changes to be processed by the Master priceplan changer demon'
/

COMMENT ON COLUMN master_chg_pp_trans.dealer IS 'Dealer who performed the change. If left blank, the original dealer code on the subscription is used'
/
COMMENT ON COLUMN master_chg_pp_trans.effective_date IS 'Date when the change must be effective from'
/
COMMENT ON COLUMN master_chg_pp_trans.enter_time IS 'Time when row was inserted into this table. Automatically set on insert operation'
/
COMMENT ON COLUMN master_chg_pp_trans.handle_commitment IS 'How to handle the existing commitment period. N, (NONE) R, (REPLACE OLD (default)) E, (EXTEND OLD) K, (KEEP OLD)'
/
COMMENT ON COLUMN master_chg_pp_trans.new_campaign_code IS 'The new campaign code'
/
COMMENT ON COLUMN master_chg_pp_trans.new_subscription_type IS 'The new Subscription Profile Type'
/
COMMENT ON COLUMN master_chg_pp_trans.new_priceplan IS 'The new priceplan code'
/
COMMENT ON COLUMN master_chg_pp_trans.priority IS 'Transaction priority. Lowest value=highest priority. Valid values: 1 to 5'
/
COMMENT ON COLUMN master_chg_pp_trans.process_status IS 'Status of transaction. Valid values: ''WAITING'', ''IN_PROGRESS'', ''PRSD_SUCCESS'' and ''PRSD_ERROR'''
/
COMMENT ON COLUMN master_chg_pp_trans.process_time IS 'Time when this transaction was actually processed'
/
COMMENT ON COLUMN master_chg_pp_trans.reason_code IS 'Reason code for PP change'
/
COMMENT ON COLUMN master_chg_pp_trans.memo_text IS 'Foksu Memo Text for PP change'
/
COMMENT ON COLUMN master_chg_pp_trans.request_time IS 'Time when PP change is supposed to take place'
/
COMMENT ON COLUMN master_chg_pp_trans.sales_agent IS 'Sales agent who performed the change. If left blank, the original sales agent code on the subscription is used'
/
COMMENT ON COLUMN master_chg_pp_trans.status_desc IS 'Status description'
/
COMMENT ON COLUMN master_chg_pp_trans.subscriber_no IS 'Subscriber number of subscriber who is going to get his priceplan changed'
/
COMMENT ON COLUMN master_chg_pp_trans.waive_fees IS 'Waive fees relating to the PP change Valud values: ''Y'' and ''N'''
/


CREATE  INDEX master_chg_pp_trans_idx1
 ON master_chg_pp_trans
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_chg_pp_trans
 ADD PRIMARY KEY (subscriber_no,new_priceplan,enter_time)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_100 CHECK ( waive_fees IN ('Y', 'N'))
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_101 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR'))
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_102 CHECK ( priority BETWEEN 1 AND 5 )
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_103 CHECK ( handle_commitment IN ('N','K','E','R' ) )
/

CREATE OR REPLACE TRIGGER master_chg_pp_trans_trg1
BEFORE INSERT
ON master_chg_pp_trans
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  IF INSERTING
  THEN
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;
  END IF;
 END;
/
