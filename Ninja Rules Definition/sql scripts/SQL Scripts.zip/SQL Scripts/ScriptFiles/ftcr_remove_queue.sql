delete from ftcr_queue
where ftcr_robot_no = 7
and ftcr_process_result is null;
commit;
