select pp, ads, count(*)
from mw_tmp_tab1
group by pp,ads
