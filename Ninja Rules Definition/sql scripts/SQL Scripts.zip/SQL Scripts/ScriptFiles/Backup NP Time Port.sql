update ninja_jobs
set job_status = 'STOPPING'
where job_id = 3;
commit;
insert into arch_np_time_port
select * from np_time_port
where np_status <> 'INIT';
delete from np_time_port
where np_status <> 'INIT';
commit work;
update ninja_jobs
set job_status = 'STARTING'
where job_id = 3;
commit;
