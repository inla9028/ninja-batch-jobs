
-- Start of DDL script for WAP_PP_SOC
-- Generated 6-Apr-00  12:56:46 pm
-- from wh-INTERF:1

-- Table WAP_PP_SOC

CREATE TABLE wap_pp_soc
 (
  price_plan                 VARCHAR2(9),
  soc_code                   VARCHAR2(9)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
/

-- Comments for WAP_PP_SOC

COMMENT ON TABLE wap_pp_soc IS 'Contains the WAP Soc to be Added to the Price Plan'
/

-- End of DDL script for WAP_PP_SOC
