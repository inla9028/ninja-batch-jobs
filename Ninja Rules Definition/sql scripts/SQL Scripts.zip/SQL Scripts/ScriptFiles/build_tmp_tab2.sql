insert into mw_tmp_tab2
(select unique sub,pp,act_type,act_sub_type,campaign from mw_tmp_tab1);

commit;
