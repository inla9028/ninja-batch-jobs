insert
into cnvrt_driver
select c_acct,c_contract
from contract
where c_cont_status in('AC','CN','SU') and
    c_cycle_code = '04';

COMMIT;

CREATE INDEX    cnvrt_driver_idx1
ON              cnvrt_driver(c_acct, c_contract)
TABLESPACE      cnvrt_index;




