select * from pag_f,contract,phone_no where pag_f.c_pag_phone_status = 'AC' and
contract.c_acct = pag_f.c_acct and contract.c_contract = pag_f.c_contract and
contract.c_cycle_code = '03' and
phone_no.c_phone = pag_f.c_phone and
phone_no.c_phone__status != 'N'
