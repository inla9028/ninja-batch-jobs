
-- Start of DDL script for CNVRT_DRIVER
-- Generated 20-Aug-99  2:55:08 am
-- from wh-CNVRT:2

-- Table CNVRT_DRIVER

CREATE TABLE cnvrt_driver
 (
  c_acct                     VARCHAR2(8),
  c_contract                 VARCHAR2(2)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     40M
      NEXT        20M
      PCTINCREASE 0
   )
/
