
-- Start of DDL script for WAP_ADDITIONS
-- Generated 6-Apr-00  12:56:19 pm
-- from wh-INTERF:1

-- Table WAP_ADDITIONS

CREATE TABLE wap_additions
 (
  sub_no                     VARCHAR2(20),
  robot_id                   VARCHAR2(1),
  proc_status                VARCHAR2(1),
  proc_date                  DATE,
  proc_rsn_txt               VARCHAR2(80),
  proc_priority              VARCHAR2(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
/

-- Comments for WAP_ADDITIONS

COMMENT ON TABLE wap_additions IS 'Table to hold the WAP additions'
/

-- Column Comments for WAP_ADDITIONS

COMMENT ON COLUMN wap_additions.proc_date IS '(Robot Use only - Set to NULL when entering records)  The date the record was processed by the Robot'
/
COMMENT ON COLUMN wap_additions.proc_priority IS 'The Priority associated with this record'
/
COMMENT ON COLUMN wap_additions.proc_rsn_txt IS '(Robot Use only - Set to NULL when entering records)  In case of failure this indicates what caused the failure'
/
COMMENT ON COLUMN wap_additions.proc_status IS '(Robot Use only - Set to NULL when entering records) The Status of the Addition, Null = not processed, Y = Ok, X = failure.'
/
COMMENT ON COLUMN wap_additions.robot_id IS 'The Number of the Robot to Process this Record'
/
COMMENT ON COLUMN wap_additions.sub_no IS 'The Subscriber Number excluding the ''GSM0'' i.e. 4792810211'
/

-- End of DDL script for WAP_ADDITIONS
