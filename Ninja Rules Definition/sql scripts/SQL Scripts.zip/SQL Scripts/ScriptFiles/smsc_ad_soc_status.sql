select soc, action, processed, count(*)
from fokus.smsc_ad_soc
group by soc, action, processed
