DECLARE 
   V_VMS_FAX           VMS.C_VMS_FAX%TYPE;
   CURSOR C_DUPLICATE IS 
     select c_vms_fax 
       from vms 
       where c_vms_status = 'AC' 
       group by c_vms_fax
       having count(c_vms_fax) > 1;
BEGIN 
  OPEN C_DUPLICATE;
  LOOP
   FETCH C_DUPLICATE INTO V_VMS_FAX;
   EXIT WHEN C_DUPLICATE%NOTFOUND;
  END LOOP;
  CLOSE C_DUPLICATE;
END;  
  
