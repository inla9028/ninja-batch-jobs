SELECT a.c_acct,a.c_contract,a.c_esn_sim,a.c_phone,a.c_pag_phone_status,a.c_phone_lvl,b.c_phone__status FROM
    PAG_F a, PHONE_NO b WHERE
a.c_phone_lvl = 'M' AND a.C_ESN_SIM LIKE '8947080%' AND
a.c_pag_phone_status IN ('AC','SU') and 
a.c_primary_prod in('TELEFON','ALPHA01') 
