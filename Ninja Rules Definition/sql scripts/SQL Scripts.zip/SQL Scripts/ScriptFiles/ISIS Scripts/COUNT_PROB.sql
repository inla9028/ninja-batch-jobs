select a.c_acct,a.c_contract,a.c_esn_sim,a.c_phone,a.c_pag_phone_status,
       a.c_phone_lvl,a.c_user_no,a.c_cycle_code,b.C_VMS_ATTRACTIVE_INDEX_F,B.C_VMSCLASS_COS_CODE,b.c_vms_status 
from faxes a, vms b
where  a.c_user_no = b.c_userinfo_number and
       b.c_vms_status in ('AC','SU') and
       1 != (select count(*) from pag_f c where a.c_acct = c.c_acct and
                      a.c_contract = c.c_contract and
                      a.c_pag_phone_status in ('AC','SU'))
 order by a.c_acct                     
       
                      

       
             
