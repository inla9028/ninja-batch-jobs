
insert into temp_pag_cont
(c_acct,c_contract,c_esn_sim,c_phone,c_activation_date,c_pag_phone_status,c_disc_date,c_phone_lvl,c_cont_status,c_cycle_code)

select a.c_acct,a.c_contract,a.c_esn_sim,a.c_phone,a.c_activation_date,a.c_pag_phone_status,a.c_disc_date,a.c_phone_lvl,b.c_cont_status,b.c_cycle_code
from pag_f a, contract b
where a.c_pag_phone_status in('AC','SU') and
     b.c_acct = a.c_acct and
    b.c_contract = a.c_contract and
   b.c_cont_status not in ('AC','SU')
