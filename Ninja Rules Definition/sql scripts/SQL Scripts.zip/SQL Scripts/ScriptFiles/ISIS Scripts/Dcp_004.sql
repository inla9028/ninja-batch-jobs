SELECT c_acct,c_contract,c_esn_sim,c_phone,c_pag_phone_status
FROM PAG_F WHERE
  c_pag_phone_status IN ('AC') AND
    NOT EXISTS (SELECT ' ' FROM PHONE_NO WHERE
         PAG_F.C_PHONE = PHONE_NO.C_PHONE AND
         PAG_F.C_ACCT = PHONE_NO.c_acn and
         pag_f.c_contract = phone_no.c_phn_contract and
         pag_f.c_esn_sim = phone_no.c_phn_esn_sim and
         phone_no.c_phone__status = 'N')
