select * from pag_f where c_pag_phone_status in ('AC','SU') and C_PRIMARY_PROD = 'PERSVAR' AND
NOT exists
(select ' ' from VMS where
PAG_F.C_USER_NO = VMS.c_userinfo_number and
pag_f.c_phone = vms.c_vms_fax)
