select * from phone_no where c_phone__status not in('A','Q','S','R','N')
