DECLARE
   V_VMS_FAX           VMS.C_VMS_FAX%TYPE;
   V_VMS_RECORD        DUPLICATE_FAX3%ROWTYPE;
   v_userinfo_number   VMS.C_USERINFO_NUMBER%TYPE;
   V_vms_sub_id        VMS.c_vms_sub_id%TYPE;
   V_vms_phone         VMS.c_vms_phone%TYPE;
   V_acct              PAG_F.c_acct%TYPE;
   V_contract          PAG_F.c_contract%TYPE;
   V_pag_phone_status  PAG_F.c_pag_phone_status%TYPE;


   CURSOR C_DUPLICATE IS
     select c_vms_fax
       from vms
       where c_vms_status = 'AC'
       group by c_vms_fax
       having count(c_vms_fax) > 1;

   CURSOR C_DUPLICATE2 IS
      select c_userinfo_number,c_vms_sub_id,c_vms_phone,c_vms_fax,c_acct,c_contract,c_pag_phone_status
        FROM  VMS, PAG_F
        WHERE c_vms_fax = V_VMS_FAX and
              c_phone = V_VMS_FAX and
              c_pag_phone_status in ('AC','SU');

BEGIN
  OPEN C_DUPLICATE;
  LOOP
     FETCH C_DUPLICATE INTO V_VMS_FAX;
     OPEN C_DUPLICATE2;
     LOOP
       FETCH C_DUPLICATE2 INTO V_VMS_RECORD;
        v_userinfo_number := v_vms_record.c_userinfo_number;
        v_vms_sub_id := v_vms_record.c_vms_sub_id;
        V_vms_phone := v_vms_record.c_vms_phone;
        V_acct := v_vms_record.c_acct;
        v_contract := v_vms_record.c_contract;
        v_pag_phone_status := v_vms_record.c_pag_phone_status;

       insert into duplicate_fax3
          values ( v_userinfo_number,v_vms_sub_id,v_vms_phone,  v_vms_fax,v_acct,v_contract,v_pag_phone_status) ;

       EXIT WHEN C_DUPLICATE2%NOTFOUND;
     END LOOP;
     CLOSE C_DUPLICATE2;
   EXIT WHEN C_DUPLICATE%NOTFOUND;
  END LOOP;
  CLOSE C_DUPLICATE;
END;
