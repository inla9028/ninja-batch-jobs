select * from duplicate_fax3
