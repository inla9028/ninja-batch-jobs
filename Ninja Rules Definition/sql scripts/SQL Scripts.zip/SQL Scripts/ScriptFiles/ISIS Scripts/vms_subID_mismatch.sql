 select * from vms 
   where substr(c_vms_phone,1,4) || substr(c_vms_phone,6, length(c_vms_phone)) != 
   substr(c_vms_sub_id,1,4) || substr(c_vms_sub_id,6, length(c_vms_sub_id))
