
select c_acct , c_contract , c_esn_sim , c_phone, c_user_no
from pag_f 
where c_pag_phone_status not in ( 'CN' , 'XC')
and not exists
( select ' ' from userinfo 
  where userinfo.c_userinfo_number = pag_f.c_user_no )

