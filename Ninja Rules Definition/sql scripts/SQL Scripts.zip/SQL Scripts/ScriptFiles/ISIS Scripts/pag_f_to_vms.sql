select * from pag_f where c_pag_phone_status in ('AC','SU') and c_primary_prod = 'PERSVAR' and
    not exists
   (select ' ' from vms where vms.c_userinfo_number = pag_f.c_user_no and
   vms.c_vms_fax = pag_f.c_phone )
