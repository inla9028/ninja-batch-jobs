SELECT esn_sim.c_esn_sim,
     esn_sim.c_location,
     pag_f.c_pag_phone_status,
     pag_f.c_acct,
     pag_f.c_contract,
     pag_f.c_phone
    FROM pag_f,
     esn_sim
    WHERE pag_f.c_pag_phone_status IN ('AC', 'SU') AND
    pag_f.c_esn_sim = esn_sim.c_esn_sim AND
    esn_sim.c_location != 'AA'
