
select b.c_acct,b.c_contract,b.c_cont_status,b.c_cycle_code,a.c_phone,a.c_pag_phone_status,a.c_phone_lvl,a.c_esn_sim
from pag_f a, contract b
where a.c_pag_phone_status not in('CN','XC') and
     b.c_acct = a.c_acct and
    b.c_contract = a.c_contract and
   b.c_cont_status in ('CL','CN')
