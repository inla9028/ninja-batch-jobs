select * from pag_f where c_pag_phone_status in ('AC') and
exists
(select ' ' from phone_no where
phone_no.c_phone = pag_f.c_phone and
phone_no.c_phone__status not in('N'))
