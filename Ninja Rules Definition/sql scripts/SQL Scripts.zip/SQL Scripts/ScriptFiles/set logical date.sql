update logical_date
set logical_date = sysdate where expiration_date is null;
commit;
select * from logical_date where expiration_date is null;
