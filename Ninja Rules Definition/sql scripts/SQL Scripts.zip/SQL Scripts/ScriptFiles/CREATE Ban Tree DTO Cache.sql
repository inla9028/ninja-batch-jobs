-- Start of DDL Script for Table NINJADEVDATA.CACHED_BAN_TREES
-- Generated 31-okt-2004 13:34:01 from NINJADEVDATA@NINJA.WSRV1.NETCOM-GSM.NO

CREATE TABLE cached_ban_tree_dto
    (tree_root_ban                  NUMBER(9,0),
     time_stored                    DATE,
     ban_tree_dto                   BLOB DEFAULT empty_blob()
 )
 TABLESPACE data
 STORAGE   (
      INITIAL     50M
      NEXT        25M
)      
   	LOB (BAN_TREE_DTO) STORE AS (TABLESPACE NINJA_BLOB1
	CACHE 
	STORAGE (INITIAL 50M
	NEXT 50M )
	)  
/

-- Grants for Table
GRANT ALTER ON cached_ban_tree_dto TO ninjadevmain
/
GRANT DELETE ON cached_ban_tree_dto TO ninjadevmain
/
GRANT INDEX ON cached_ban_tree_dto TO ninjadevmain
/
GRANT INSERT ON cached_ban_tree_dto TO ninjadevmain
/
GRANT SELECT ON cached_ban_tree_dto TO ninjadevmain
/
GRANT UPDATE ON cached_ban_tree_dto TO ninjadevmain
/
GRANT REFERENCES ON cached_ban_tree_dto TO ninjadevmain
/
GRANT ALTER ON cached_ban_tree_dto TO ninjadevrules
/
GRANT DELETE ON cached_ban_tree_dto TO ninjadevrules
/
GRANT INDEX ON cached_ban_tree_dto TO ninjadevrules
/
GRANT INSERT ON cached_ban_tree_dto TO ninjadevrules
/
GRANT SELECT ON cached_ban_tree_dto TO ninjadevrules
/
GRANT UPDATE ON cached_ban_tree_dto TO ninjadevrules
/
GRANT REFERENCES ON cached_ban_tree_dto TO ninjadevrules
/
GRANT ALTER ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT DELETE ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT INDEX ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT INSERT ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT SELECT ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT UPDATE ON cached_ban_tree_dto TO ninjadevconfig
/
GRANT REFERENCES ON cached_ban_tree_dto TO ninjadevconfig
/



-- Indexes for CACHED_BAN_TREES

CREATE UNIQUE INDEX cached_ban_dto_idx1 ON cached_ban_tree_dto
  (
    tree_root_ban                   ASC,
    time_stored                     ASC
  )
/



-- Comments for CACHED_BAN_TREES

COMMENT ON TABLE cached_ban_tree_dto IS 'Contains the Cached Ban Tree IDS''s'
/
COMMENT ON COLUMN cached_ban_tree_dto.time_stored IS 'Time the Tree was Stored'
/
COMMENT ON COLUMN cached_ban_tree_dto.tree_root_ban IS 'The Tree Root Ban'
/

-- End of DDL Script for Table NINJADEVDATA.CACHED_BAN_TREES

