
-- Start of DDL script for ACCOMMODATION_TYPE
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ACCOMMODATION_TYPE

CREATE SYNONYM accommodation_type
           FOR ref.accommodation_type
/

-- End of DDL script for ACCOMMODATION_TYPE

-- Start of DDL script for ACCOUNT_TYPE
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ACCOUNT_TYPE

CREATE SYNONYM account_type
           FOR ref.account_type
/

-- End of DDL script for ACCOUNT_TYPE

-- Start of DDL script for ACCOUNT_TYPE_12_01
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ACCOUNT_TYPE_12_01

CREATE SYNONYM account_type_12_01
           FOR ref.account_type_12_01
/

-- End of DDL script for ACCOUNT_TYPE_12_01

-- Start of DDL script for ACCT_TYPE_CREDIT_REL
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ACCT_TYPE_CREDIT_REL

CREATE SYNONYM acct_type_credit_rel
           FOR ref.acct_type_credit_rel
/

-- End of DDL script for ACCT_TYPE_CREDIT_REL

-- Start of DDL script for ACTIVITY_REASON_TEXT
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ACTIVITY_REASON_TEXT

CREATE SYNONYM activity_reason_text
           FOR ref.activity_reason_text
/

-- End of DDL script for ACTIVITY_REASON_TEXT

-- Start of DDL script for AC_PGM_FILES_CONTROL
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym AC_PGM_FILES_CONTROL

CREATE SYNONYM ac_pgm_files_control
           FOR ref.ac_pgm_files_control
/

-- End of DDL script for AC_PGM_FILES_CONTROL

-- Start of DDL script for AC_PROGRAMS
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym AC_PROGRAMS

CREATE SYNONYM ac_programs
           FOR ref.ac_programs
/

-- End of DDL script for AC_PROGRAMS

-- Start of DDL script for ADJUSTMENT_REASON
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ADJUSTMENT_REASON

CREATE SYNONYM adjustment_reason
           FOR ref.adjustment_reason
/

-- End of DDL script for ADJUSTMENT_REASON

-- Start of DDL script for ADR_STREET_SUFFIX
-- Generated 3-Oct-99  2:05:26 pm
-- from wh-CNVRTD:2

-- Synonym ADR_STREET_SUFFIX

CREATE SYNONYM adr_street_suffix
           FOR ref.adr_street_suffix
/

-- End of DDL script for ADR_STREET_SUFFIX

-- Start of DDL script for AGENTS_TMP
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym AGENTS_TMP

CREATE SYNONYM agents_tmp
           FOR cnvrt.agents_tmp
/

-- End of DDL script for AGENTS_TMP

-- Start of DDL script for AGENT_PROMOTION
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym AGENT_PROMOTION

CREATE SYNONYM agent_promotion
           FOR ref.agent_promotion
/

-- End of DDL script for AGENT_PROMOTION

-- Start of DDL script for APL_LIST
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym APL_LIST

CREATE SYNONYM apl_list
           FOR ref.apl_list
/

-- End of DDL script for APL_LIST

-- Start of DDL script for AR_ACTIVITIES
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym AR_ACTIVITIES

CREATE SYNONYM ar_activities
           FOR ref.ar_activities
/

-- End of DDL script for AR_ACTIVITIES

-- Start of DDL script for AR_ACTIVITIES_12_01
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym AR_ACTIVITIES_12_01

CREATE SYNONYM ar_activities_12_01
           FOR ref.ar_activities_12_01
/

-- End of DDL script for AR_ACTIVITIES_12_01

-- Start of DDL script for BACKOUT_REASON_CODE
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BACKOUT_REASON_CODE

CREATE SYNONYM backout_reason_code
           FOR ref.backout_reason_code
/

-- End of DDL script for BACKOUT_REASON_CODE

-- Start of DDL script for BALANCE_CHECK_REP
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BALANCE_CHECK_REP

CREATE SYNONYM balance_check_rep
           FOR ref.balance_check_rep
/

-- End of DDL script for BALANCE_CHECK_REP

-- Start of DDL script for BANKS
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BANKS

CREATE SYNONYM banks
           FOR ref.banks
/

-- End of DDL script for BANKS

-- Start of DDL script for BANK_BRANCHES
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BANK_BRANCHES

CREATE SYNONYM bank_branches
           FOR ref.bank_branches
/

-- End of DDL script for BANK_BRANCHES

-- Start of DDL script for BATCH_TRX_REJECT_RSN
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BATCH_TRX_REJECT_RSN

CREATE SYNONYM batch_trx_reject_rsn
           FOR ref.batch_trx_reject_rsn
/

-- End of DDL script for BATCH_TRX_REJECT_RSN

-- Start of DDL script for BILLPAGEPOS
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILLPAGEPOS

CREATE SYNONYM billpagepos
           FOR ref.billpagepos
/

-- End of DDL script for BILLPAGEPOS

-- Start of DDL script for BILL_CATEGORY
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILL_CATEGORY

CREATE SYNONYM bill_category
           FOR ref.bill_category
/

-- End of DDL script for BILL_CATEGORY

-- Start of DDL script for BILL_CATEGORY_DESC
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILL_CATEGORY_DESC

CREATE SYNONYM bill_category_desc
           FOR ref.bill_category_desc
/

-- End of DDL script for BILL_CATEGORY_DESC

-- Start of DDL script for BILL_DESC
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILL_DESC

CREATE SYNONYM bill_desc
           FOR ref.bill_desc
/

-- End of DDL script for BILL_DESC

-- Start of DDL script for BILL_DESC_TMP
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILL_DESC_TMP

CREATE SYNONYM bill_desc_tmp
           FOR ref.bill_desc_tmp
/

-- End of DDL script for BILL_DESC_TMP

-- Start of DDL script for BILL_DESC_TMP_NEW
-- Generated 3-Oct-99  2:05:27 pm
-- from wh-CNVRTD:2

-- Synonym BILL_DESC_TMP_NEW

CREATE SYNONYM bill_desc_tmp_new
           FOR ref.bill_desc_tmp_new
/

-- End of DDL script for BILL_DESC_TMP_NEW

-- Start of DDL script for BILL_PAGE
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BILL_PAGE

CREATE SYNONYM bill_page
           FOR ref.bill_page
/

-- End of DDL script for BILL_PAGE

-- Start of DDL script for BILL_PARAM_FORMAT
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BILL_PARAM_FORMAT

CREATE SYNONYM bill_param_format
           FOR ref.bill_param_format
/

-- End of DDL script for BILL_PARAM_FORMAT

-- Start of DDL script for BUDGET_PLAN
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BUDGET_PLAN

CREATE SYNONYM budget_plan
           FOR ref.budget_plan
/

-- End of DDL script for BUDGET_PLAN

-- Start of DDL script for BUREAU
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BUREAU

CREATE SYNONYM bureau
           FOR ref.bureau
/

-- End of DDL script for BUREAU

-- Start of DDL script for BUSINESS_ENTITY
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BUSINESS_ENTITY

CREATE SYNONYM business_entity
           FOR ref.business_entity
/

-- End of DDL script for BUSINESS_ENTITY

-- Start of DDL script for BUSINESS_INSTR
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym BUSINESS_INSTR

CREATE SYNONYM business_instr
           FOR ref.business_instr
/

-- End of DDL script for BUSINESS_INSTR

-- Start of DDL script for CALC_METHOD
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CALC_METHOD

CREATE SYNONYM calc_method
           FOR ref.calc_method
/

-- End of DDL script for CALC_METHOD

-- Start of DDL script for CALL_CENTER_INFO
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CALL_CENTER_INFO

CREATE SYNONYM call_center_info
           FOR ref.call_center_info
/

-- End of DDL script for CALL_CENTER_INFO

-- Start of DDL script for CALL_CHARACTERISTIC
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CALL_CHARACTERISTIC

CREATE SYNONYM call_characteristic
           FOR ref.call_characteristic
/

-- End of DDL script for CALL_CHARACTERISTIC

-- Start of DDL script for CALL_DUR_DISC
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CALL_DUR_DISC

CREATE SYNONYM call_dur_disc
           FOR ref.call_dur_disc
/

-- End of DDL script for CALL_DUR_DISC

-- Start of DDL script for CALL_DUR_DISC_TIER
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CALL_DUR_DISC_TIER

CREATE SYNONYM call_dur_disc_tier
           FOR ref.call_dur_disc_tier
/

-- End of DDL script for CALL_DUR_DISC_TIER

-- Start of DDL script for CAMPAIGN
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CAMPAIGN

CREATE SYNONYM campaign
           FOR ref.campaign
/

-- End of DDL script for CAMPAIGN

-- Start of DDL script for CAMPAIGN_COMMITMENTS
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CAMPAIGN_COMMITMENTS

CREATE SYNONYM campaign_commitments
           FOR ref.campaign_commitments
/

-- End of DDL script for CAMPAIGN_COMMITMENTS

-- Start of DDL script for CANCEL_REASON
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CANCEL_REASON

CREATE SYNONYM cancel_reason
           FOR ref.cancel_reason
/

-- End of DDL script for CANCEL_REASON

-- Start of DDL script for CASE_CLOSE_RSN
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CASE_CLOSE_RSN

CREATE SYNONYM case_close_rsn
           FOR ref.case_close_rsn
/

-- End of DDL script for CASE_CLOSE_RSN

-- Start of DDL script for CAS_APPLICATION_TYPE
-- Generated 3-Oct-99  2:05:28 pm
-- from wh-CNVRTD:2

-- Synonym CAS_APPLICATION_TYPE

CREATE SYNONYM cas_application_type
           FOR ref.cas_application_type
/

-- End of DDL script for CAS_APPLICATION_TYPE

-- Start of DDL script for CAS_ERROR
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CAS_ERROR

CREATE SYNONYM cas_error
           FOR ref.cas_error
/

-- End of DDL script for CAS_ERROR

-- Start of DDL script for CAS_STATUS_REASON
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CAS_STATUS_REASON

CREATE SYNONYM cas_status_reason
           FOR ref.cas_status_reason
/

-- End of DDL script for CAS_STATUS_REASON

-- Start of DDL script for CCIR_ACTIVITY
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CCIR_ACTIVITY

CREATE SYNONYM ccir_activity
           FOR ref.ccir_activity
/

-- End of DDL script for CCIR_ACTIVITY

-- Start of DDL script for CHARGE_INFO
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CHARGE_INFO

CREATE SYNONYM charge_info
           FOR ref.charge_info
/

-- End of DDL script for CHARGE_INFO

-- Start of DDL script for CNVRT_CONTROL
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CNVRT_CONTROL

CREATE SYNONYM cnvrt_control
           FOR ref.cnvrt_control
/

-- End of DDL script for CNVRT_CONTROL

-- Start of DDL script for CNV_DEF_PARAM
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym CNV_DEF_PARAM

CREATE SYNONYM cnv_def_param
           FOR ref.cnv_def_param
/

-- End of DDL script for CNV_DEF_PARAM

-- Start of DDL script for COLLECTION_ACTIVITIES
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_ACTIVITIES

CREATE SYNONYM collection_activities
           FOR ref.collection_activities
/

-- End of DDL script for COLLECTION_ACTIVITIES

-- Start of DDL script for COLLECTION_AGENCY
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_AGENCY

CREATE SYNONYM collection_agency
           FOR ref.collection_agency
/

-- End of DDL script for COLLECTION_AGENCY

-- Start of DDL script for COLLECTION_CATEGORY
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_CATEGORY

CREATE SYNONYM collection_category
           FOR ref.collection_category
/

-- End of DDL script for COLLECTION_CATEGORY

-- Start of DDL script for COLLECTION_POLICY_STEP
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_POLICY_STEP

CREATE SYNONYM collection_policy_step
           FOR ref.collection_policy_step
/

-- End of DDL script for COLLECTION_POLICY_STEP

-- Start of DDL script for COLLECTION_POLICY_STEP_12_01
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_POLICY_STEP_12_01

CREATE SYNONYM collection_policy_step_12_01
           FOR ref.collection_policy_step_12_01
/

-- End of DDL script for COLLECTION_POLICY_STEP_12_01

-- Start of DDL script for COLLECTION_REF_GRPS
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_REF_GRPS

CREATE SYNONYM collection_ref_grps
           FOR ref.collection_ref_grps
/

-- End of DDL script for COLLECTION_REF_GRPS

-- Start of DDL script for COLLECTION_REF_LINK
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COLLECTION_REF_LINK

CREATE SYNONYM collection_ref_link
           FOR ref.collection_ref_link
/

-- End of DDL script for COLLECTION_REF_LINK

-- Start of DDL script for COMMIT_SOC_RELATION
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COMMIT_SOC_RELATION

CREATE SYNONYM commit_soc_relation
           FOR ref.commit_soc_relation
/

-- End of DDL script for COMMIT_SOC_RELATION

-- Start of DDL script for COMMIT_TOLL_RS_RELATION
-- Generated 3-Oct-99  2:05:29 pm
-- from wh-CNVRTD:2

-- Synonym COMMIT_TOLL_RS_RELATION

CREATE SYNONYM commit_toll_rs_relation
           FOR ref.commit_toll_rs_relation
/

-- End of DDL script for COMMIT_TOLL_RS_RELATION

-- Start of DDL script for CONV_ERROR_CODE
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CONV_ERROR_CODE

CREATE SYNONYM conv_error_code
           FOR ref.conv_error_code
/

-- End of DDL script for CONV_ERROR_CODE

-- Start of DDL script for CONV_PARAM
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CONV_PARAM

CREATE SYNONYM conv_param
           FOR ref.conv_param
/

-- End of DDL script for CONV_PARAM

-- Start of DDL script for CRCARD_RANGES
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CRCARD_RANGES

CREATE SYNONYM crcard_ranges
           FOR ref.crcard_ranges
/

-- End of DDL script for CRCARD_RANGES

-- Start of DDL script for CREDIT_CLASS
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CREDIT_CLASS

CREATE SYNONYM credit_class
           FOR ref.credit_class
/

-- End of DDL script for CREDIT_CLASS

-- Start of DDL script for CREDIT_CLASS_POLICY
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CREDIT_CLASS_POLICY

CREATE SYNONYM credit_class_policy
           FOR ref.credit_class_policy
/

-- End of DDL script for CREDIT_CLASS_POLICY

-- Start of DDL script for CSM_ACTIVITY
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CSM_ACTIVITY

CREATE SYNONYM csm_activity
           FOR ref.csm_activity
/

-- End of DDL script for CSM_ACTIVITY

-- Start of DDL script for CSM_DEFAULT_VALUES
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CSM_DEFAULT_VALUES

CREATE SYNONYM csm_default_values
           FOR ref.csm_default_values
/

-- End of DDL script for CSM_DEFAULT_VALUES

-- Start of DDL script for CSM_STATUS_ACTIVITY
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CSM_STATUS_ACTIVITY

CREATE SYNONYM csm_status_activity
           FOR ref.csm_status_activity
/

-- End of DDL script for CSM_STATUS_ACTIVITY

-- Start of DDL script for CSM_SWITCH_FEATURE
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CSM_SWITCH_FEATURE

CREATE SYNONYM csm_switch_feature
           FOR ref.csm_switch_feature
/

-- End of DDL script for CSM_SWITCH_FEATURE

-- Start of DDL script for CUM_TREND_REP_COL
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CUM_TREND_REP_COL

CREATE SYNONYM cum_trend_rep_col
           FOR ref.cum_trend_rep_col
/

-- End of DDL script for CUM_TREND_REP_COL

-- Start of DDL script for CUM_TREND_REP_COUNT
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CUM_TREND_REP_COUNT

CREATE SYNONYM cum_trend_rep_count
           FOR ref.cum_trend_rep_count
/

-- End of DDL script for CUM_TREND_REP_COUNT

-- Start of DDL script for CUM_TREND_REP_LINE
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CUM_TREND_REP_LINE

CREATE SYNONYM cum_trend_rep_line
           FOR ref.cum_trend_rep_line
/

-- End of DDL script for CUM_TREND_REP_LINE

-- Start of DDL script for CUSTOMER_DEF_VALUES
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CUSTOMER_DEF_VALUES

CREATE SYNONYM customer_def_values
           FOR ref.customer_def_values
/

-- End of DDL script for CUSTOMER_DEF_VALUES

-- Start of DDL script for CUSTOMER_GROUPS
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CUSTOMER_GROUPS

CREATE SYNONYM customer_groups
           FOR ref.customer_groups
/

-- End of DDL script for CUSTOMER_GROUPS

-- Start of DDL script for CYCLE
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CYCLE

CREATE SYNONYM cycle
           FOR ref.cycle
/

-- End of DDL script for CYCLE

-- Start of DDL script for CYCLE_BAL_REP_COUNT
-- Generated 3-Oct-99  2:05:30 pm
-- from wh-CNVRTD:2

-- Synonym CYCLE_BAL_REP_COUNT

CREATE SYNONYM cycle_bal_rep_count
           FOR ref.cycle_bal_rep_count
/

-- End of DDL script for CYCLE_BAL_REP_COUNT

-- Start of DDL script for CYCLE_BAL_REP_LINE
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym CYCLE_BAL_REP_LINE

CREATE SYNONYM cycle_bal_rep_line
           FOR ref.cycle_bal_rep_line
/

-- End of DDL script for CYCLE_BAL_REP_LINE

-- Start of DDL script for CYCLE_FREQ
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym CYCLE_FREQ

CREATE SYNONYM cycle_freq
           FOR ref.cycle_freq
/

-- End of DDL script for CYCLE_FREQ

-- Start of DDL script for CYCLE_POPULATION
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym CYCLE_POPULATION

CREATE SYNONYM cycle_population
           FOR ref.cycle_population
/

-- End of DDL script for CYCLE_POPULATION

-- Start of DDL script for DACC_SERVE_SID
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DACC_SERVE_SID

CREATE SYNONYM dacc_serve_sid
           FOR ref.dacc_serve_sid
/

-- End of DDL script for DACC_SERVE_SID

-- Start of DDL script for DAYLIGHT_SAVING
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DAYLIGHT_SAVING

CREATE SYNONYM daylight_saving
           FOR ref.daylight_saving
/

-- End of DDL script for DAYLIGHT_SAVING

-- Start of DDL script for DD_COMPANY_DATA
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DD_COMPANY_DATA

CREATE SYNONYM dd_company_data
           FOR ref.dd_company_data
/

-- End of DDL script for DD_COMPANY_DATA

-- Start of DDL script for DEALER_PROFILE
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEALER_PROFILE

CREATE SYNONYM dealer_profile
           FOR ref.dealer_profile
/

-- End of DDL script for DEALER_PROFILE

-- Start of DDL script for DEALER_TEMP
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEALER_TEMP

CREATE SYNONYM dealer_temp
           FOR ref.dealer_temp
/

-- End of DDL script for DEALER_TEMP

-- Start of DDL script for DEALER_TYPE
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEALER_TYPE

CREATE SYNONYM dealer_type
           FOR ref.dealer_type
/

-- End of DDL script for DEALER_TYPE

-- Start of DDL script for DEF_MARKET_TOLL_RS
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEF_MARKET_TOLL_RS

CREATE SYNONYM def_market_toll_rs
           FOR ref.def_market_toll_rs
/

-- End of DDL script for DEF_MARKET_TOLL_RS

-- Start of DDL script for DEPARTMENT
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEPARTMENT

CREATE SYNONYM department
           FOR ref.department
/

-- End of DDL script for DEPARTMENT

-- Start of DDL script for DEPARTMENT_RELATIONS
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEPARTMENT_RELATIONS

CREATE SYNONYM department_relations
           FOR ref.department_relations
/

-- End of DDL script for DEPARTMENT_RELATIONS

-- Start of DDL script for DEPOSIT_TYPE
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEPOSIT_TYPE

CREATE SYNONYM deposit_type
           FOR ref.deposit_type
/

-- End of DDL script for DEPOSIT_TYPE

-- Start of DDL script for DEP_ACCTYPE_RELATIONS
-- Generated 3-Oct-99  2:05:31 pm
-- from wh-CNVRTD:2

-- Synonym DEP_ACCTYPE_RELATIONS

CREATE SYNONYM dep_acctype_relations
           FOR ref.dep_acctype_relations
/

-- End of DDL script for DEP_ACCTYPE_RELATIONS

-- Start of DDL script for DESC_COLUMN_LIST
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DESC_COLUMN_LIST

CREATE SYNONYM desc_column_list
           FOR ref.desc_column_list
/

-- End of DDL script for DESC_COLUMN_LIST

-- Start of DDL script for DESC_TRANSLATION
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DESC_TRANSLATION

CREATE SYNONYM desc_translation
           FOR ref.desc_translation
/

-- End of DDL script for DESC_TRANSLATION

-- Start of DDL script for DEVICE_TYPE
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DEVICE_TYPE

CREATE SYNONYM device_type
           FOR ref.device_type
/

-- End of DDL script for DEVICE_TYPE

-- Start of DDL script for DIRECTION
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DIRECTION

CREATE SYNONYM direction
           FOR ref.direction
/

-- End of DDL script for DIRECTION

-- Start of DDL script for DISCOUNT_CATEGORY
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_CATEGORY

CREATE SYNONYM discount_category
           FOR ref.discount_category
/

-- End of DDL script for DISCOUNT_CATEGORY

-- Start of DDL script for DISCOUNT_GROUP
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_GROUP

CREATE SYNONYM discount_group
           FOR ref.discount_group
/

-- End of DDL script for DISCOUNT_GROUP

-- Start of DDL script for DISCOUNT_GROUP_PLAN
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_GROUP_PLAN

CREATE SYNONYM discount_group_plan
           FOR ref.discount_group_plan
/

-- End of DDL script for DISCOUNT_GROUP_PLAN

-- Start of DDL script for DISCOUNT_PLAN
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_PLAN

CREATE SYNONYM discount_plan
           FOR ref.discount_plan
/

-- End of DDL script for DISCOUNT_PLAN

-- Start of DDL script for DISCOUNT_ROUTINES
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_ROUTINES

CREATE SYNONYM discount_routines
           FOR ref.discount_routines
/

-- End of DDL script for DISCOUNT_ROUTINES

-- Start of DDL script for DISCOUNT_TIER
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISCOUNT_TIER

CREATE SYNONYM discount_tier
           FOR ref.discount_tier
/

-- End of DDL script for DISCOUNT_TIER

-- Start of DDL script for DISC_CALC_PATH
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISC_CALC_PATH

CREATE SYNONYM disc_calc_path
           FOR ref.disc_calc_path
/

-- End of DDL script for DISC_CALC_PATH

-- Start of DDL script for DISC_ROUTINES_PATH
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DISC_ROUTINES_PATH

CREATE SYNONYM disc_routines_path
           FOR ref.disc_routines_path
/

-- End of DDL script for DISC_ROUTINES_PATH

-- Start of DDL script for DOMESTIC_PREFIX
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DOMESTIC_PREFIX

CREATE SYNONYM domestic_prefix
           FOR ref.domestic_prefix
/

-- End of DDL script for DOMESTIC_PREFIX

-- Start of DDL script for DROP_REASONS
-- Generated 3-Oct-99  2:05:32 pm
-- from wh-CNVRTD:2

-- Synonym DROP_REASONS

CREATE SYNONYM drop_reasons
           FOR ref.drop_reasons
/

-- End of DDL script for DROP_REASONS

-- Start of DDL script for DUTY_OPERATOR
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DUTY_OPERATOR

CREATE SYNONYM duty_operator
           FOR ref.duty_operator
/

-- End of DDL script for DUTY_OPERATOR

-- Start of DDL script for DVC_PARAM
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DVC_PARAM

CREATE SYNONYM dvc_param
           FOR ref.dvc_param
/

-- End of DDL script for DVC_PARAM

-- Start of DDL script for DVC_ROUTING
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DVC_ROUTING

CREATE SYNONYM dvc_routing
           FOR ref.dvc_routing
/

-- End of DDL script for DVC_ROUTING

-- Start of DDL script for DVC_STATUSES
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DVC_STATUSES

CREATE SYNONYM dvc_statuses
           FOR ref.dvc_statuses
/

-- End of DDL script for DVC_STATUSES

-- Start of DDL script for DVC_TRX_D
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DVC_TRX_D

CREATE SYNONYM dvc_trx_d
           FOR ref.dvc_trx_d
/

-- End of DDL script for DVC_TRX_D

-- Start of DDL script for DYNAMIC_COLUMNS
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym DYNAMIC_COLUMNS

CREATE SYNONYM dynamic_columns
           FOR ref.dynamic_columns
/

-- End of DDL script for DYNAMIC_COLUMNS

-- Start of DDL script for ECA_BAN_CODES
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym ECA_BAN_CODES

CREATE SYNONYM eca_ban_codes
           FOR ref.eca_ban_codes
/

-- End of DDL script for ECA_BAN_CODES

-- Start of DDL script for EMPLOYMENT_TYPE
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym EMPLOYMENT_TYPE

CREATE SYNONYM employment_type
           FOR ref.employment_type
/

-- End of DDL script for EMPLOYMENT_TYPE

-- Start of DDL script for EQUAL_ACCESS_RMR
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym EQUAL_ACCESS_RMR

CREATE SYNONYM equal_access_rmr
           FOR ref.equal_access_rmr
/

-- End of DDL script for EQUAL_ACCESS_RMR

-- Start of DDL script for ERROR_CODES
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym ERROR_CODES

CREATE SYNONYM error_codes
           FOR ref.error_codes
/

-- End of DDL script for ERROR_CODES

-- Start of DDL script for ERROR_GROUP_LIST
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym ERROR_GROUP_LIST

CREATE SYNONYM error_group_list
           FOR ref.error_group_list
/

-- End of DDL script for ERROR_GROUP_LIST

-- Start of DDL script for ESN_POOL_TRANSFER
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym ESN_POOL_TRANSFER

CREATE SYNONYM esn_pool_transfer
           FOR ref.esn_pool_transfer
/

-- End of DDL script for ESN_POOL_TRANSFER

-- Start of DDL script for EXCEPTIONS
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym EXCEPTIONS

CREATE SYNONYM exceptions
           FOR ref.exceptions
/

-- End of DDL script for EXCEPTIONS

-- Start of DDL script for EXCHANGE_RATE
-- Generated 3-Oct-99  2:05:33 pm
-- from wh-CNVRTD:2

-- Synonym EXCHANGE_RATE

CREATE SYNONYM exchange_rate
           FOR ref.exchange_rate
/

-- End of DDL script for EXCHANGE_RATE

-- Start of DDL script for FEATURE
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE

CREATE SYNONYM feature
           FOR ref.feature
/

-- End of DDL script for FEATURE

-- Start of DDL script for FEATURE_BILL_CATEGORY
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE_BILL_CATEGORY

CREATE SYNONYM feature_bill_category
           FOR ref.feature_bill_category
/

-- End of DDL script for FEATURE_BILL_CATEGORY

-- Start of DDL script for FEATURE_CATEGORY
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE_CATEGORY

CREATE SYNONYM feature_category
           FOR ref.feature_category
/

-- End of DDL script for FEATURE_CATEGORY

-- Start of DDL script for FEATURE_TRANSLATION
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE_TRANSLATION

CREATE SYNONYM feature_translation
           FOR ref.feature_translation
/

-- End of DDL script for FEATURE_TRANSLATION

-- Start of DDL script for FEATURE_TRANSLATION_12_01
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE_TRANSLATION_12_01

CREATE SYNONYM feature_translation_12_01
           FOR ref.feature_translation_12_01
/

-- End of DDL script for FEATURE_TRANSLATION_12_01

-- Start of DDL script for FEATURE_TYPES
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FEATURE_TYPES

CREATE SYNONYM feature_types
           FOR ref.feature_types
/

-- End of DDL script for FEATURE_TYPES

-- Start of DDL script for FIELDS_ERRORS
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FIELDS_ERRORS

CREATE SYNONYM fields_errors
           FOR ref.fields_errors
/

-- End of DDL script for FIELDS_ERRORS

-- Start of DDL script for FILES_AND_PROCESS
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FILES_AND_PROCESS

CREATE SYNONYM files_and_process
           FOR ref.files_and_process
/

-- End of DDL script for FILES_AND_PROCESS

-- Start of DDL script for FILES_APPLICATION
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FILES_APPLICATION

CREATE SYNONYM files_application
           FOR ref.files_application
/

-- End of DDL script for FILES_APPLICATION

-- Start of DDL script for FILES_OPERATION
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FILES_OPERATION

CREATE SYNONYM files_operation
           FOR ref.files_operation
/

-- End of DDL script for FILES_OPERATION

-- Start of DDL script for FINAL_BILL_DECISION
-- Generated 3-Oct-99  2:05:34 pm
-- from wh-CNVRTD:2

-- Synonym FINAL_BILL_DECISION

CREATE SYNONYM final_bill_decision
           FOR ref.final_bill_decision
/

-- End of DDL script for FINAL_BILL_DECISION

-- Start of DDL script for FLDESC
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FLDESC

CREATE SYNONYM fldesc
           FOR ref.fldesc
/

-- End of DDL script for FLDESC

-- Start of DDL script for FOLLOW_UP_TYPE
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FOLLOW_UP_TYPE

CREATE SYNONYM follow_up_type
           FOR ref.follow_up_type
/

-- End of DDL script for FOLLOW_UP_TYPE

-- Start of DDL script for FOREIGN_COUNTRY
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FOREIGN_COUNTRY

CREATE SYNONYM foreign_country
           FOR ref.foreign_country
/

-- End of DDL script for FOREIGN_COUNTRY

-- Start of DDL script for FORMDEFMAPS
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FORMDEFMAPS

CREATE SYNONYM formdefmaps
           FOR ref.formdefmaps
/

-- End of DDL script for FORMDEFMAPS

-- Start of DDL script for FORM_TYPE
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FORM_TYPE

CREATE SYNONYM form_type
           FOR ref.form_type
/

-- End of DDL script for FORM_TYPE

-- Start of DDL script for FR_FM_PLAN
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FR_FM_PLAN

CREATE SYNONYM fr_fm_plan
           FOR ref.fr_fm_plan
/

-- End of DDL script for FR_FM_PLAN

-- Start of DDL script for FR_FM_PLAN_12_01
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FR_FM_PLAN_12_01

CREATE SYNONYM fr_fm_plan_12_01
           FOR ref.fr_fm_plan_12_01
/

-- End of DDL script for FR_FM_PLAN_12_01

-- Start of DDL script for FUNCTION
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FUNCTION

CREATE SYNONYM function
           FOR ref.function
/

-- End of DDL script for FUNCTION

-- Start of DDL script for FYI_PARAMETERS
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FYI_PARAMETERS

CREATE SYNONYM fyi_parameters
           FOR ref.fyi_parameters
/

-- End of DDL script for FYI_PARAMETERS

-- Start of DDL script for FYI_TEXT
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FYI_TEXT

CREATE SYNONYM fyi_text
           FOR ref.fyi_text
/

-- End of DDL script for FYI_TEXT

-- Start of DDL script for FYI_TEXT_LINES
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym FYI_TEXT_LINES

CREATE SYNONYM fyi_text_lines
           FOR ref.fyi_text_lines
/

-- End of DDL script for FYI_TEXT_LINES

-- Start of DDL script for GENERAL_LEDGER_ACCOUNTS
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym GENERAL_LEDGER_ACCOUNTS

CREATE SYNONYM general_ledger_accounts
           FOR ref.general_ledger_accounts
/

-- End of DDL script for GENERAL_LEDGER_ACCOUNTS

-- Start of DDL script for GENERAL_LEDGER_ACCOUNTS_12_01
-- Generated 3-Oct-99  2:05:35 pm
-- from wh-CNVRTD:2

-- Synonym GENERAL_LEDGER_ACCOUNTS_12_01

CREATE SYNONYM general_ledger_accounts_12_01
           FOR ref.general_ledger_accounts_12_01
/

-- End of DDL script for GENERAL_LEDGER_ACCOUNTS_12_01

-- Start of DDL script for GENERAL_LEDGER_MONTHS
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GENERAL_LEDGER_MONTHS

CREATE SYNONYM general_ledger_months
           FOR ref.general_ledger_months
/

-- End of DDL script for GENERAL_LEDGER_MONTHS

-- Start of DDL script for GENERAL_LEDGER_REPORTING
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GENERAL_LEDGER_REPORTING

CREATE SYNONYM general_ledger_reporting
           FOR ref.general_ledger_reporting
/

-- End of DDL script for GENERAL_LEDGER_REPORTING

-- Start of DDL script for GENERAL_LEDGER_REPORTING_12_01
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GENERAL_LEDGER_REPORTING_12_01

CREATE SYNONYM general_ledger_reporting_12_01
           FOR ref.general_ledger_reporting_12_01
/

-- End of DDL script for GENERAL_LEDGER_REPORTING_12_01

-- Start of DDL script for GENERIC_CODES
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GENERIC_CODES

CREATE SYNONYM generic_codes
           FOR ref.generic_codes
/

-- End of DDL script for GENERIC_CODES

-- Start of DDL script for GL_LOGICAL_ACCOUNTS
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GL_LOGICAL_ACCOUNTS

CREATE SYNONYM gl_logical_accounts
           FOR ref.gl_logical_accounts
/

-- End of DDL script for GL_LOGICAL_ACCOUNTS

-- Start of DDL script for GOLD_PATTERN
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GOLD_PATTERN

CREATE SYNONYM gold_pattern
           FOR ref.gold_pattern
/

-- End of DDL script for GOLD_PATTERN

-- Start of DDL script for GSM_CODE
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym GSM_CODE

CREATE SYNONYM gsm_code
           FOR ref.gsm_code
/

-- End of DDL script for GSM_CODE

-- Start of DDL script for HOLIDAYS
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym HOLIDAYS

CREATE SYNONYM holidays
           FOR ref.holidays
/

-- End of DDL script for HOLIDAYS

-- Start of DDL script for ID_TYPE
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym ID_TYPE

CREATE SYNONYM id_type
           FOR ref.id_type
/

-- End of DDL script for ID_TYPE

-- Start of DDL script for ID_TYPE_ACC_TYPE_REL
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym ID_TYPE_ACC_TYPE_REL

CREATE SYNONYM id_type_acc_type_rel
           FOR ref.id_type_acc_type_rel
/

-- End of DDL script for ID_TYPE_ACC_TYPE_REL

-- Start of DDL script for IMEI_PREFIX
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym IMEI_PREFIX

CREATE SYNONYM imei_prefix
           FOR ref.imei_prefix
/

-- End of DDL script for IMEI_PREFIX

-- Start of DDL script for INCLUS_BY_PERIOD
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym INCLUS_BY_PERIOD

CREATE SYNONYM inclus_by_period
           FOR ref.inclus_by_period
/

-- End of DDL script for INCLUS_BY_PERIOD

-- Start of DDL script for INCOLLECT_EXCH_BOUNDS
-- Generated 3-Oct-99  2:05:36 pm
-- from wh-CNVRTD:2

-- Synonym INCOLLECT_EXCH_BOUNDS

CREATE SYNONYM incollect_exch_bounds
           FOR ref.incollect_exch_bounds
/

-- End of DDL script for INCOLLECT_EXCH_BOUNDS

-- Start of DDL script for INCOL_SID_PAIR
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym INCOL_SID_PAIR

CREATE SYNONYM incol_sid_pair
           FOR ref.incol_sid_pair
/

-- End of DDL script for INCOL_SID_PAIR

-- Start of DDL script for INSERTERTRAYS
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym INSERTERTRAYS

CREATE SYNONYM insertertrays
           FOR ref.insertertrays
/

-- End of DDL script for INSERTERTRAYS

-- Start of DDL script for INTL_PREFIX_CODES
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym INTL_PREFIX_CODES

CREATE SYNONYM intl_prefix_codes
           FOR ref.intl_prefix_codes
/

-- End of DDL script for INTL_PREFIX_CODES

-- Start of DDL script for INVOICE_TYPE
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym INVOICE_TYPE

CREATE SYNONYM invoice_type
           FOR ref.invoice_type
/

-- End of DDL script for INVOICE_TYPE

-- Start of DDL script for INV_CARRIER
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym INV_CARRIER

CREATE SYNONYM inv_carrier
           FOR ref.inv_carrier
/

-- End of DDL script for INV_CARRIER

-- Start of DDL script for ITEM_CAT
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym ITEM_CAT

CREATE SYNONYM item_cat
           FOR ref.item_cat
/

-- End of DDL script for ITEM_CAT

-- Start of DDL script for ITEM_DEFINITION
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym ITEM_DEFINITION

CREATE SYNONYM item_definition
           FOR ref.item_definition
/

-- End of DDL script for ITEM_DEFINITION

-- Start of DDL script for ITEM_POLICY
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym ITEM_POLICY

CREATE SYNONYM item_policy
           FOR ref.item_policy
/

-- End of DDL script for ITEM_POLICY

-- Start of DDL script for ITEM_SUBCAT
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym ITEM_SUBCAT

CREATE SYNONYM item_subcat
           FOR ref.item_subcat
/

-- End of DDL script for ITEM_SUBCAT

-- Start of DDL script for LAYOUT
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym LAYOUT

CREATE SYNONYM layout
           FOR ref.layout
/

-- End of DDL script for LAYOUT

-- Start of DDL script for LETTERS
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym LETTERS

CREATE SYNONYM letters
           FOR ref.letters
/

-- End of DDL script for LETTERS

-- Start of DDL script for LETTER_APPLICATIONS
-- Generated 3-Oct-99  2:05:37 pm
-- from wh-CNVRTD:2

-- Synonym LETTER_APPLICATIONS

CREATE SYNONYM letter_applications
           FOR ref.letter_applications
/

-- End of DDL script for LETTER_APPLICATIONS

-- Start of DDL script for LETTER_VARIABLES
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LETTER_VARIABLES

CREATE SYNONYM letter_variables
           FOR ref.letter_variables
/

-- End of DDL script for LETTER_VARIABLES

-- Start of DDL script for LETTER_VARIABLE_LINK
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LETTER_VARIABLE_LINK

CREATE SYNONYM letter_variable_link
           FOR ref.letter_variable_link
/

-- End of DDL script for LETTER_VARIABLE_LINK

-- Start of DDL script for LOCAL_CALL_PREFIX
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LOCAL_CALL_PREFIX

CREATE SYNONYM local_call_prefix
           FOR ref.local_call_prefix
/

-- End of DDL script for LOCAL_CALL_PREFIX

-- Start of DDL script for LOCATION_COMPID_LINK
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LOCATION_COMPID_LINK

CREATE SYNONYM location_compid_link
           FOR ref.location_compid_link
/

-- End of DDL script for LOCATION_COMPID_LINK

-- Start of DDL script for LOGIC_PHD
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LOGIC_PHD

CREATE SYNONYM logic_phd
           FOR ref.logic_phd
/

-- End of DDL script for LOGIC_PHD

-- Start of DDL script for LSN_ERRORS
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym LSN_ERRORS

CREATE SYNONYM lsn_errors
           FOR ref.lsn_errors
/

-- End of DDL script for LSN_ERRORS

-- Start of DDL script for MAF_APPLICATION
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_APPLICATION

CREATE SYNONYM maf_application
           FOR ref.maf_application
/

-- End of DDL script for MAF_APPLICATION

-- Start of DDL script for MAF_DAYLIGHT_SAVING
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_DAYLIGHT_SAVING

CREATE SYNONYM maf_daylight_saving
           FOR ref.maf_daylight_saving
/

-- End of DDL script for MAF_DAYLIGHT_SAVING

-- Start of DDL script for MAF_MESSAGE
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_MESSAGE

CREATE SYNONYM maf_message
           FOR ref.maf_message
/

-- End of DDL script for MAF_MESSAGE

-- Start of DDL script for MAF_OPERATION
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_OPERATION

CREATE SYNONYM maf_operation
           FOR ref.maf_operation
/

-- End of DDL script for MAF_OPERATION

-- Start of DDL script for MAF_PERIOD
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_PERIOD

CREATE SYNONYM maf_period
           FOR ref.maf_period
/

-- End of DDL script for MAF_PERIOD

-- Start of DDL script for MAF_PERIOD_NAME
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_PERIOD_NAME

CREATE SYNONYM maf_period_name
           FOR ref.maf_period_name
/

-- End of DDL script for MAF_PERIOD_NAME

-- Start of DDL script for MAF_PERIOD_SET
-- Generated 3-Oct-99  2:05:38 pm
-- from wh-CNVRTD:2

-- Synonym MAF_PERIOD_SET

CREATE SYNONYM maf_period_set
           FOR ref.maf_period_set
/

-- End of DDL script for MAF_PERIOD_SET

-- Start of DDL script for MANUFACTURER
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MANUFACTURER

CREATE SYNONYM manufacturer
           FOR ref.manufacturer
/

-- End of DDL script for MANUFACTURER

-- Start of DDL script for MARITAL_STATUS
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARITAL_STATUS

CREATE SYNONYM marital_status
           FOR ref.marital_status
/

-- End of DDL script for MARITAL_STATUS

-- Start of DDL script for MARKET
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARKET

CREATE SYNONYM market
           FOR ref.market
/

-- End of DDL script for MARKET

-- Start of DDL script for MARKET_12_01
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARKET_12_01

CREATE SYNONYM market_12_01
           FOR ref.market_12_01
/

-- End of DDL script for MARKET_12_01

-- Start of DDL script for MARKET_BAN_RANGES
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARKET_BAN_RANGES

CREATE SYNONYM market_ban_ranges
           FOR ref.market_ban_ranges
/

-- End of DDL script for MARKET_BAN_RANGES

-- Start of DDL script for MARKET_POLICY
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARKET_POLICY

CREATE SYNONYM market_policy
           FOR ref.market_policy
/

-- End of DDL script for MARKET_POLICY

-- Start of DDL script for MARKET_POLICY_12_02
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MARKET_POLICY_12_02

CREATE SYNONYM market_policy_12_02
           FOR ref.market_policy_12_02
/

-- End of DDL script for MARKET_POLICY_12_02

-- Start of DDL script for MEMO_TYPE
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MEMO_TYPE

CREATE SYNONYM memo_type
           FOR ref.memo_type
/

-- End of DDL script for MEMO_TYPE

-- Start of DDL script for MESSAGE_TEXT_PARAM
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MESSAGE_TEXT_PARAM

CREATE SYNONYM message_text_param
           FOR ref.message_text_param
/

-- End of DDL script for MESSAGE_TEXT_PARAM

-- Start of DDL script for MIGRATION_FEE
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MIGRATION_FEE

CREATE SYNONYM migration_fee
           FOR ref.migration_fee
/

-- End of DDL script for MIGRATION_FEE

-- Start of DDL script for MNG_PARAM
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MNG_PARAM

CREATE SYNONYM mng_param
           FOR ref.mng_param
/

-- End of DDL script for MNG_PARAM

-- Start of DDL script for MOU_BY_PERIOD
-- Generated 3-Oct-99  2:05:39 pm
-- from wh-CNVRTD:2

-- Synonym MOU_BY_PERIOD

CREATE SYNONYM mou_by_period
           FOR ref.mou_by_period
/

-- End of DDL script for MOU_BY_PERIOD

-- Start of DDL script for MPS_FEATURE
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MPS_FEATURE

CREATE SYNONYM mps_feature
           FOR ref.mps_feature
/

-- End of DDL script for MPS_FEATURE

-- Start of DDL script for MPS_PROFILE
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MPS_PROFILE

CREATE SYNONYM mps_profile
           FOR ref.mps_profile
/

-- End of DDL script for MPS_PROFILE

-- Start of DDL script for MPS_WRITE_OFF_RSN
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MPS_WRITE_OFF_RSN

CREATE SYNONYM mps_write_off_rsn
           FOR ref.mps_write_off_rsn
/

-- End of DDL script for MPS_WRITE_OFF_RSN

-- Start of DDL script for MSISDN_CRITERIA
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MSISDN_CRITERIA

CREATE SYNONYM msisdn_criteria
           FOR ref.msisdn_criteria
/

-- End of DDL script for MSISDN_CRITERIA

-- Start of DDL script for MSISDN_HLR_RELATION
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MSISDN_HLR_RELATION

CREATE SYNONYM msisdn_hlr_relation
           FOR ref.msisdn_hlr_relation
/

-- End of DDL script for MSISDN_HLR_RELATION

-- Start of DDL script for MSISDN_VM_RELATION
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym MSISDN_VM_RELATION

CREATE SYNONYM msisdn_vm_relation
           FOR ref.msisdn_vm_relation
/

-- End of DDL script for MSISDN_VM_RELATION

-- Start of DDL script for NAME_TITLE_SALUT
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NAME_TITLE_SALUT

CREATE SYNONYM name_title_salut
           FOR ref.name_title_salut
/

-- End of DDL script for NAME_TITLE_SALUT

-- Start of DDL script for NETWORK_CONNECTION
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NETWORK_CONNECTION

CREATE SYNONYM network_connection
           FOR ref.network_connection
/

-- End of DDL script for NETWORK_CONNECTION

-- Start of DDL script for NGP_PRODUCT_RELATION
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NGP_PRODUCT_RELATION

CREATE SYNONYM ngp_product_relation
           FOR ref.ngp_product_relation
/

-- End of DDL script for NGP_PRODUCT_RELATION

-- Start of DDL script for NL_DEALER_LINK
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NL_DEALER_LINK

CREATE SYNONYM nl_dealer_link
           FOR ref.nl_dealer_link
/

-- End of DDL script for NL_DEALER_LINK

-- Start of DDL script for NM_TRX_CODES
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NM_TRX_CODES

CREATE SYNONYM nm_trx_codes
           FOR ref.nm_trx_codes
/

-- End of DDL script for NM_TRX_CODES

-- Start of DDL script for NM_TRX_VALID_STS
-- Generated 3-Oct-99  2:05:40 pm
-- from wh-CNVRTD:2

-- Synonym NM_TRX_VALID_STS

CREATE SYNONYM nm_trx_valid_sts
           FOR ref.nm_trx_valid_sts
/

-- End of DDL script for NM_TRX_VALID_STS

-- Start of DDL script for NP_PRODUCT
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym NP_PRODUCT

CREATE SYNONYM np_product
           FOR ref.np_product
/

-- End of DDL script for NP_PRODUCT

-- Start of DDL script for NUMBER_GROUP
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym NUMBER_GROUP

CREATE SYNONYM number_group
           FOR ref.number_group
/

-- End of DDL script for NUMBER_GROUP

-- Start of DDL script for NUMBER_LOCATION
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym NUMBER_LOCATION

CREATE SYNONYM number_location
           FOR ref.number_location
/

-- End of DDL script for NUMBER_LOCATION

-- Start of DDL script for ONLINE_HELP
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ONLINE_HELP

CREATE SYNONYM online_help
           FOR ref.online_help
/

-- End of DDL script for ONLINE_HELP

-- Start of DDL script for ONLINE_MESSAGES
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ONLINE_MESSAGES

CREATE SYNONYM online_messages
           FOR ref.online_messages
/

-- End of DDL script for ONLINE_MESSAGES

-- Start of DDL script for OPERATOR_MESSAGE
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym OPERATOR_MESSAGE

CREATE SYNONYM operator_message
           FOR ref.operator_message
/

-- End of DDL script for OPERATOR_MESSAGE

-- Start of DDL script for ORA_ERROR_PARAM
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ORA_ERROR_PARAM

CREATE SYNONYM ora_error_param
           FOR ref.ora_error_param
/

-- End of DDL script for ORA_ERROR_PARAM

-- Start of DDL script for ORGANIZATION
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ORGANIZATION

CREATE SYNONYM organization
           FOR ref.organization
/

-- End of DDL script for ORGANIZATION

-- Start of DDL script for ORG_DEPARTMENT
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ORG_DEPARTMENT

CREATE SYNONYM org_department
           FOR ref.org_department
/

-- End of DDL script for ORG_DEPARTMENT

-- Start of DDL script for ORG_PABX_LINK
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym ORG_PABX_LINK

CREATE SYNONYM org_pabx_link
           FOR ref.org_pabx_link
/

-- End of DDL script for ORG_PABX_LINK

-- Start of DDL script for OUTCOLLECT_TOLL
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym OUTCOLLECT_TOLL

CREATE SYNONYM outcollect_toll
           FOR ref.outcollect_toll
/

-- End of DDL script for OUTCOLLECT_TOLL

-- Start of DDL script for OUTCOL_DESTINATION
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym OUTCOL_DESTINATION

CREATE SYNONYM outcol_destination
           FOR ref.outcol_destination
/

-- End of DDL script for OUTCOL_DESTINATION

-- Start of DDL script for OUTCOL_SID_PAIR
-- Generated 3-Oct-99  2:05:41 pm
-- from wh-CNVRTD:2

-- Synonym OUTCOL_SID_PAIR

CREATE SYNONYM outcol_sid_pair
           FOR ref.outcol_sid_pair
/

-- End of DDL script for OUTCOL_SID_PAIR

-- Start of DDL script for PABX_LIST
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PABX_LIST

CREATE SYNONYM pabx_list
           FOR ref.pabx_list
/

-- End of DDL script for PABX_LIST

-- Start of DDL script for PABX_NL_LINK
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PABX_NL_LINK

CREATE SYNONYM pabx_nl_link
           FOR ref.pabx_nl_link
/

-- End of DDL script for PABX_NL_LINK

-- Start of DDL script for PABX_TN_RANGE
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PABX_TN_RANGE

CREATE SYNONYM pabx_tn_range
           FOR ref.pabx_tn_range
/

-- End of DDL script for PABX_TN_RANGE

-- Start of DDL script for PAPER_WORK_STATUS
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PAPER_WORK_STATUS

CREATE SYNONYM paper_work_status
           FOR ref.paper_work_status
/

-- End of DDL script for PAPER_WORK_STATUS

-- Start of DDL script for PARAM_VALUES
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PARAM_VALUES

CREATE SYNONYM param_values
           FOR ref.param_values
/

-- End of DDL script for PARAM_VALUES

-- Start of DDL script for PAYMENT_DPST_LINK
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PAYMENT_DPST_LINK

CREATE SYNONYM payment_dpst_link
           FOR ref.payment_dpst_link
/

-- End of DDL script for PAYMENT_DPST_LINK

-- Start of DDL script for PAYMENT_METHOD
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PAYMENT_METHOD

CREATE SYNONYM payment_method
           FOR ref.payment_method
/

-- End of DDL script for PAYMENT_METHOD

-- Start of DDL script for PAYMENT_SOURCE
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PAYMENT_SOURCE

CREATE SYNONYM payment_source
           FOR ref.payment_source
/

-- End of DDL script for PAYMENT_SOURCE

-- Start of DDL script for PB_REPORTING
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PB_REPORTING

CREATE SYNONYM pb_reporting
           FOR ref.pb_reporting
/

-- End of DDL script for PB_REPORTING

-- Start of DDL script for PERIOD
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PERIOD

CREATE SYNONYM period
           FOR ref.period
/

-- End of DDL script for PERIOD

-- Start of DDL script for PERIOD_NAME
-- Generated 3-Oct-99  2:05:42 pm
-- from wh-CNVRTD:2

-- Synonym PERIOD_NAME

CREATE SYNONYM period_name
           FOR ref.period_name
/

-- End of DDL script for PERIOD_NAME

-- Start of DDL script for PERIOD_SET
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PERIOD_SET

CREATE SYNONYM period_set
           FOR ref.period_set
/

-- End of DDL script for PERIOD_SET

-- Start of DDL script for PH_SW_VM
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PH_SW_VM

CREATE SYNONYM ph_sw_vm
           FOR ref.ph_sw_vm
/

-- End of DDL script for PH_SW_VM

-- Start of DDL script for POOL
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym POOL

CREATE SYNONYM pool
           FOR ref.pool
/

-- End of DDL script for POOL

-- Start of DDL script for PP_AC_RATE
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_AC_RATE

CREATE SYNONYM pp_ac_rate
           FOR ref.pp_ac_rate
/

-- End of DDL script for PP_AC_RATE

-- Start of DDL script for PP_GROUP
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_GROUP

CREATE SYNONYM pp_group
           FOR ref.pp_group
/

-- End of DDL script for PP_GROUP

-- Start of DDL script for PP_OC_RATE
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_OC_RATE

CREATE SYNONYM pp_oc_rate
           FOR ref.pp_oc_rate
/

-- End of DDL script for PP_OC_RATE

-- Start of DDL script for PP_RC_RATE
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_RC_RATE

CREATE SYNONYM pp_rc_rate
           FOR ref.pp_rc_rate
/

-- End of DDL script for PP_RC_RATE

-- Start of DDL script for PP_REMARK
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_REMARK

CREATE SYNONYM pp_remark
           FOR ref.pp_remark
/

-- End of DDL script for PP_REMARK

-- Start of DDL script for PP_SCEN_PRD
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_SCEN_PRD

CREATE SYNONYM pp_scen_prd
           FOR ref.pp_scen_prd
/

-- End of DDL script for PP_SCEN_PRD

-- Start of DDL script for PP_UC_RATE
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PP_UC_RATE

CREATE SYNONYM pp_uc_rate
           FOR ref.pp_uc_rate
/

-- End of DDL script for PP_UC_RATE

-- Start of DDL script for PRICE_CODE_DESC
-- Generated 3-Oct-99  2:05:43 pm
-- from wh-CNVRTD:2

-- Synonym PRICE_CODE_DESC

CREATE SYNONYM price_code_desc
           FOR ref.price_code_desc
/

-- End of DDL script for PRICE_CODE_DESC

-- Start of DDL script for PRICING
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRICING

CREATE SYNONYM pricing
           FOR ref.pricing
/

-- End of DDL script for PRICING

-- Start of DDL script for PRINTERPAGE
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRINTERPAGE

CREATE SYNONYM printerpage
           FOR ref.printerpage
/

-- End of DDL script for PRINTERPAGE

-- Start of DDL script for PRINTER_ATTRIBUTES
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRINTER_ATTRIBUTES

CREATE SYNONYM printer_attributes
           FOR ref.printer_attributes
/

-- End of DDL script for PRINTER_ATTRIBUTES

-- Start of DDL script for PRINTFILERANGES
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRINTFILERANGES

CREATE SYNONYM printfileranges
           FOR ref.printfileranges
/

-- End of DDL script for PRINTFILERANGES

-- Start of DDL script for PRINT_BATCH
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRINT_BATCH

CREATE SYNONYM print_batch
           FOR ref.print_batch
/

-- End of DDL script for PRINT_BATCH

-- Start of DDL script for PRINT_CATEGORIES
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRINT_CATEGORIES

CREATE SYNONYM print_categories
           FOR ref.print_categories
/

-- End of DDL script for PRINT_CATEGORIES

-- Start of DDL script for PRODUCT
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PRODUCT

CREATE SYNONYM product
           FOR ref.product
/

-- End of DDL script for PRODUCT

-- Start of DDL script for PROMOTION_TERMS
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym PROMOTION_TERMS

CREATE SYNONYM promotion_terms
           FOR ref.promotion_terms
/

-- End of DDL script for PROMOTION_TERMS

-- Start of DDL script for QA_PARAMETERS
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym QA_PARAMETERS

CREATE SYNONYM qa_parameters
           FOR ref.qa_parameters
/

-- End of DDL script for QA_PARAMETERS

-- Start of DDL script for RATED_FEATURE
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym RATED_FEATURE

CREATE SYNONYM rated_feature
           FOR ref.rated_feature
/

-- End of DDL script for RATED_FEATURE

-- Start of DDL script for RATER_CONFIG
-- Generated 3-Oct-99  2:05:44 pm
-- from wh-CNVRTD:2

-- Synonym RATER_CONFIG

CREATE SYNONYM rater_config
           FOR ref.rater_config
/

-- End of DDL script for RATER_CONFIG

-- Start of DDL script for RATES_AND_FEES
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATES_AND_FEES

CREATE SYNONYM rates_and_fees
           FOR ref.rates_and_fees
/

-- End of DDL script for RATES_AND_FEES

-- Start of DDL script for RATE_GROUPS
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATE_GROUPS

CREATE SYNONYM rate_groups
           FOR ref.rate_groups
/

-- End of DDL script for RATE_GROUPS

-- Start of DDL script for RATE_RTN_PROC_ORD
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATE_RTN_PROC_ORD

CREATE SYNONYM rate_rtn_proc_ord
           FOR ref.rate_rtn_proc_ord
/

-- End of DDL script for RATE_RTN_PROC_ORD

-- Start of DDL script for RATE_SCENARIO
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATE_SCENARIO

CREATE SYNONYM rate_scenario
           FOR ref.rate_scenario
/

-- End of DDL script for RATE_SCENARIO

-- Start of DDL script for RATE_SCENARIO_RULE
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATE_SCENARIO_RULE

CREATE SYNONYM rate_scenario_rule
           FOR ref.rate_scenario_rule
/

-- End of DDL script for RATE_SCENARIO_RULE

-- Start of DDL script for RATE_SCENARIO_SET
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATE_SCENARIO_SET

CREATE SYNONYM rate_scenario_set
           FOR ref.rate_scenario_set
/

-- End of DDL script for RATE_SCENARIO_SET

-- Start of DDL script for RATING_ROUTINES
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RATING_ROUTINES

CREATE SYNONYM rating_routines
           FOR ref.rating_routines
/

-- End of DDL script for RATING_ROUTINES

-- Start of DDL script for RECORD_TYPES
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym RECORD_TYPES

CREATE SYNONYM record_types
           FOR ref.record_types
/

-- End of DDL script for RECORD_TYPES

-- Start of DDL script for REFUND_CRITERIA
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym REFUND_CRITERIA

CREATE SYNONYM refund_criteria
           FOR ref.refund_criteria
/

-- End of DDL script for REFUND_CRITERIA

-- Start of DDL script for REFUND_REASON
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym REFUND_REASON

CREATE SYNONYM refund_reason
           FOR ref.refund_reason
/

-- End of DDL script for REFUND_REASON

-- Start of DDL script for REGISTER
-- Generated 3-Oct-99  2:05:45 pm
-- from wh-CNVRTD:2

-- Synonym REGISTER

CREATE SYNONYM register
           FOR ref.register
/

-- End of DDL script for REGISTER

-- Start of DDL script for REJECT_INTERNAL_RRC
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym REJECT_INTERNAL_RRC

CREATE SYNONYM reject_internal_rrc
           FOR ref.reject_internal_rrc
/

-- End of DDL script for REJECT_INTERNAL_RRC

-- Start of DDL script for REPAIR_LOCATION
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym REPAIR_LOCATION

CREATE SYNONYM repair_location
           FOR ref.repair_location
/

-- End of DDL script for REPAIR_LOCATION

-- Start of DDL script for REPORTS_LOCATIONS
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym REPORTS_LOCATIONS

CREATE SYNONYM reports_locations
           FOR ref.reports_locations
/

-- End of DDL script for REPORTS_LOCATIONS

-- Start of DDL script for RMR_CIBER_RRC
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMR_CIBER_RRC

CREATE SYNONYM rmr_ciber_rrc
           FOR ref.rmr_ciber_rrc
/

-- End of DDL script for RMR_CIBER_RRC

-- Start of DDL script for RMR_INTERNAL_RRC
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMR_INTERNAL_RRC

CREATE SYNONYM rmr_internal_rrc
           FOR ref.rmr_internal_rrc
/

-- End of DDL script for RMR_INTERNAL_RRC

-- Start of DDL script for RMR_REJECT_RRC
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMR_REJECT_RRC

CREATE SYNONYM rmr_reject_rrc
           FOR ref.rmr_reject_rrc
/

-- End of DDL script for RMR_REJECT_RRC

-- Start of DDL script for RMS_ACTIVITY_CODE
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMS_ACTIVITY_CODE

CREATE SYNONYM rms_activity_code
           FOR ref.rms_activity_code
/

-- End of DDL script for RMS_ACTIVITY_CODE

-- Start of DDL script for RMS_CM_RSN_CODE
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMS_CM_RSN_CODE

CREATE SYNONYM rms_cm_rsn_code
           FOR ref.rms_cm_rsn_code
/

-- End of DDL script for RMS_CM_RSN_CODE

-- Start of DDL script for RMS_GL_ACCOUNT_NAME
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMS_GL_ACCOUNT_NAME

CREATE SYNONYM rms_gl_account_name
           FOR ref.rms_gl_account_name
/

-- End of DDL script for RMS_GL_ACCOUNT_NAME

-- Start of DDL script for RMS_GL_ACCOUNT_NAME_12_01
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMS_GL_ACCOUNT_NAME_12_01

CREATE SYNONYM rms_gl_account_name_12_01
           FOR ref.rms_gl_account_name_12_01
/

-- End of DDL script for RMS_GL_ACCOUNT_NAME_12_01

-- Start of DDL script for RMS_GL_ACTIVITY
-- Generated 3-Oct-99  2:05:46 pm
-- from wh-CNVRTD:2

-- Synonym RMS_GL_ACTIVITY

CREATE SYNONYM rms_gl_activity
           FOR ref.rms_gl_activity
/

-- End of DDL script for RMS_GL_ACTIVITY

-- Start of DDL script for RMS_GL_REPORTING
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_GL_REPORTING

CREATE SYNONYM rms_gl_reporting
           FOR ref.rms_gl_reporting
/

-- End of DDL script for RMS_GL_REPORTING

-- Start of DDL script for RMS_GL_REPORTING_12_01
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_GL_REPORTING_12_01

CREATE SYNONYM rms_gl_reporting_12_01
           FOR ref.rms_gl_reporting_12_01
/

-- End of DDL script for RMS_GL_REPORTING_12_01

-- Start of DDL script for RMS_IC_RSN_CODE
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_IC_RSN_CODE

CREATE SYNONYM rms_ic_rsn_code
           FOR ref.rms_ic_rsn_code
/

-- End of DDL script for RMS_IC_RSN_CODE

-- Start of DDL script for RMS_LOCATION
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_LOCATION

CREATE SYNONYM rms_location
           FOR ref.rms_location
/

-- End of DDL script for RMS_LOCATION

-- Start of DDL script for RMS_MARKET_POLICY
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_MARKET_POLICY

CREATE SYNONYM rms_market_policy
           FOR ref.rms_market_policy
/

-- End of DDL script for RMS_MARKET_POLICY

-- Start of DDL script for RMS_POS_RSN_CODE
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_POS_RSN_CODE

CREATE SYNONYM rms_pos_rsn_code
           FOR ref.rms_pos_rsn_code
/

-- End of DDL script for RMS_POS_RSN_CODE

-- Start of DDL script for RMS_REFUND_METHOD
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym RMS_REFUND_METHOD

CREATE SYNONYM rms_refund_method
           FOR ref.rms_refund_method
/

-- End of DDL script for RMS_REFUND_METHOD

-- Start of DDL script for ROAMING_OPERATOR
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym ROAMING_OPERATOR

CREATE SYNONYM roaming_operator
           FOR ref.roaming_operator
/

-- End of DDL script for ROAMING_OPERATOR

-- Start of DDL script for SC_LOG_DEVICES
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym SC_LOG_DEVICES

CREATE SYNONYM sc_log_devices
           FOR ref.sc_log_devices
/

-- End of DDL script for SC_LOG_DEVICES

-- Start of DDL script for SDR_EXCHANGE
-- Generated 3-Oct-99  2:05:47 pm
-- from wh-CNVRTD:2

-- Synonym SDR_EXCHANGE

CREATE SYNONYM sdr_exchange
           FOR ref.sdr_exchange
/

-- End of DDL script for SDR_EXCHANGE

-- Start of DDL script for SEQ_ARRAY
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SEQ_ARRAY

CREATE SYNONYM seq_array
           FOR ref.seq_array
/

-- End of DDL script for SEQ_ARRAY

-- Start of DDL script for SEQ_ARRAY_TEMP
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SEQ_ARRAY_TEMP

CREATE SYNONYM seq_array_temp
           FOR ref.seq_array_temp
/

-- End of DDL script for SEQ_ARRAY_TEMP

-- Start of DDL script for SERVICE_PROVIDERS
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SERVICE_PROVIDERS

CREATE SYNONYM service_providers
           FOR ref.service_providers
/

-- End of DDL script for SERVICE_PROVIDERS

-- Start of DDL script for SERVICE_STAT_DEF
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SERVICE_STAT_DEF

CREATE SYNONYM service_stat_def
           FOR ref.service_stat_def
/

-- End of DDL script for SERVICE_STAT_DEF

-- Start of DDL script for SETLMNT_CONTRACT
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SETLMNT_CONTRACT

CREATE SYNONYM setlmnt_contract
           FOR ref.setlmnt_contract
/

-- End of DDL script for SETLMNT_CONTRACT

-- Start of DDL script for SIM_TYPE
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SIM_TYPE

CREATE SYNONYM sim_type
           FOR ref.sim_type
/

-- End of DDL script for SIM_TYPE

-- Start of DDL script for SLAY
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SLAY

CREATE SYNONYM slay
           FOR ref.slay
/

-- End of DDL script for SLAY

-- Start of DDL script for SLOT
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SLOT

CREATE SYNONYM slot
           FOR ref.slot
/

-- End of DDL script for SLOT

-- Start of DDL script for SMS_ERRORS
-- Generated 3-Oct-99  2:05:48 pm
-- from wh-CNVRTD:2

-- Synonym SMS_ERRORS

CREATE SYNONYM sms_errors
           FOR ref.sms_errors
/

-- End of DDL script for SMS_ERRORS

-- Start of DDL script for SMS_OPERATOR_LIST
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SMS_OPERATOR_LIST

CREATE SYNONYM sms_operator_list
           FOR ref.sms_operator_list
/

-- End of DDL script for SMS_OPERATOR_LIST

-- Start of DDL script for SMS_RECEIVE_STYLE
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SMS_RECEIVE_STYLE

CREATE SYNONYM sms_receive_style
           FOR ref.sms_receive_style
/

-- End of DDL script for SMS_RECEIVE_STYLE

-- Start of DDL script for SOC
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC

CREATE SYNONYM soc
           FOR ref.soc
/

-- End of DDL script for SOC

-- Start of DDL script for SOC_BUNDLES
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_BUNDLES

CREATE SYNONYM soc_bundles
           FOR ref.soc_bundles
/

-- End of DDL script for SOC_BUNDLES

-- Start of DDL script for SOC_CREDIT_CLASS
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_CREDIT_CLASS

CREATE SYNONYM soc_credit_class
           FOR ref.soc_credit_class
/

-- End of DDL script for SOC_CREDIT_CLASS

-- Start of DDL script for SOC_ILLEGAL_COMB
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_ILLEGAL_COMB

CREATE SYNONYM soc_illegal_comb
           FOR ref.soc_illegal_comb
/

-- End of DDL script for SOC_ILLEGAL_COMB

-- Start of DDL script for SOC_LOAN
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_LOAN

CREATE SYNONYM soc_loan
           FOR ref.soc_loan
/

-- End of DDL script for SOC_LOAN

-- Start of DDL script for SOC_RELATION
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_RELATION

CREATE SYNONYM soc_relation
           FOR ref.soc_relation
/

-- End of DDL script for SOC_RELATION

-- Start of DDL script for SOC_RELATION_TMP
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_RELATION_TMP

CREATE SYNONYM soc_relation_tmp
           FOR ref.soc_relation_tmp
/

-- End of DDL script for SOC_RELATION_TMP

-- Start of DDL script for SOC_SALE_CHANNEL
-- Generated 3-Oct-99  2:05:49 pm
-- from wh-CNVRTD:2

-- Synonym SOC_SALE_CHANNEL

CREATE SYNONYM soc_sale_channel
           FOR ref.soc_sale_channel
/

-- End of DDL script for SOC_SALE_CHANNEL

-- Start of DDL script for SPECIAL_DAYS
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SPECIAL_DAYS

CREATE SYNONYM special_days
           FOR ref.special_days
/

-- End of DDL script for SPECIAL_DAYS

-- Start of DDL script for SPECIAL_DAYS_SET
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SPECIAL_DAYS_SET

CREATE SYNONYM special_days_set
           FOR ref.special_days_set
/

-- End of DDL script for SPECIAL_DAYS_SET

-- Start of DDL script for SPECIAL_NUMBERS
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SPECIAL_NUMBERS

CREATE SYNONYM special_numbers
           FOR ref.special_numbers
/

-- End of DDL script for SPECIAL_NUMBERS

-- Start of DDL script for SPF_PARAM
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SPF_PARAM

CREATE SYNONYM spf_param
           FOR ref.spf_param
/

-- End of DDL script for SPF_PARAM

-- Start of DDL script for SP_TOLL_RS
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SP_TOLL_RS

CREATE SYNONYM sp_toll_rs
           FOR ref.sp_toll_rs
/

-- End of DDL script for SP_TOLL_RS

-- Start of DDL script for SRV_DVC_PRIORITY
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SRV_DVC_PRIORITY

CREATE SYNONYM srv_dvc_priority
           FOR ref.srv_dvc_priority
/

-- End of DDL script for SRV_DVC_PRIORITY

-- Start of DDL script for SRV_PARAM
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SRV_PARAM

CREATE SYNONYM srv_param
           FOR ref.srv_param
/

-- End of DDL script for SRV_PARAM

-- Start of DDL script for SRV_STATUSES
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SRV_STATUSES

CREATE SYNONYM srv_statuses
           FOR ref.srv_statuses
/

-- End of DDL script for SRV_STATUSES

-- Start of DDL script for SRV_TO_DVC
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SRV_TO_DVC

CREATE SYNONYM srv_to_dvc
           FOR ref.srv_to_dvc
/

-- End of DDL script for SRV_TO_DVC

-- Start of DDL script for SRV_TRX_TYPE
-- Generated 3-Oct-99  2:05:50 pm
-- from wh-CNVRTD:2

-- Synonym SRV_TRX_TYPE

CREATE SYNONYM srv_trx_type
           FOR ref.srv_trx_type
/

-- End of DDL script for SRV_TRX_TYPE

-- Start of DDL script for STATEMENT_REQUEST_FEATURE
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym STATEMENT_REQUEST_FEATURE

CREATE SYNONYM statement_request_feature
           FOR ref.statement_request_feature
/

-- End of DDL script for STATEMENT_REQUEST_FEATURE

-- Start of DDL script for STORE_PAYMENT_METHOD
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym STORE_PAYMENT_METHOD

CREATE SYNONYM store_payment_method
           FOR ref.store_payment_method
/

-- End of DDL script for STORE_PAYMENT_METHOD

-- Start of DDL script for SUPPLY_METHOD
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SUPPLY_METHOD

CREATE SYNONYM supply_method
           FOR ref.supply_method
/

-- End of DDL script for SUPPLY_METHOD

-- Start of DDL script for SUPPORTED_LANGUAGES
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SUPPORTED_LANGUAGES

CREATE SYNONYM supported_languages
           FOR ref.supported_languages
/

-- End of DDL script for SUPPORTED_LANGUAGES

-- Start of DDL script for SWITCH_FEATURE_INDEX
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SWITCH_FEATURE_INDEX

CREATE SYNONYM switch_feature_index
           FOR ref.switch_feature_index
/

-- End of DDL script for SWITCH_FEATURE_INDEX

-- Start of DDL script for SWITCH_INDEX_VALUE
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SWITCH_INDEX_VALUE

CREATE SYNONYM switch_index_value
           FOR ref.switch_index_value
/

-- End of DDL script for SWITCH_INDEX_VALUE

-- Start of DDL script for SWITCH_SHARING
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SWITCH_SHARING

CREATE SYNONYM switch_sharing
           FOR ref.switch_sharing
/

-- End of DDL script for SWITCH_SHARING

-- Start of DDL script for SWITCH_TYPE
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SWITCH_TYPE

CREATE SYNONYM switch_type
           FOR ref.switch_type
/

-- End of DDL script for SWITCH_TYPE

-- Start of DDL script for SW_PHYSICAL_DEVICE
-- Generated 3-Oct-99  2:05:51 pm
-- from wh-CNVRTD:2

-- Synonym SW_PHYSICAL_DEVICE

CREATE SYNONYM sw_physical_device
           FOR ref.sw_physical_device
/

-- End of DDL script for SW_PHYSICAL_DEVICE

-- Start of DDL script for SYSTEM_MARKET
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym SYSTEM_MARKET

CREATE SYNONYM system_market
           FOR ref.system_market
/

-- End of DDL script for SYSTEM_MARKET

-- Start of DDL script for TABLES_LIST
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TABLES_LIST

CREATE SYNONYM tables_list
           FOR ref.tables_list
/

-- End of DDL script for TABLES_LIST

-- Start of DDL script for TAX_CATEGORY
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TAX_CATEGORY

CREATE SYNONYM tax_category
           FOR ref.tax_category
/

-- End of DDL script for TAX_CATEGORY

-- Start of DDL script for TAX_RATE
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TAX_RATE

CREATE SYNONYM tax_rate
           FOR ref.tax_rate
/

-- End of DDL script for TAX_RATE

-- Start of DDL script for TBL_RLT
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TBL_RLT

CREATE SYNONYM tbl_rlt
           FOR ref.tbl_rlt
/

-- End of DDL script for TBL_RLT

-- Start of DDL script for TERM_ACT_PRD_STAT
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TERM_ACT_PRD_STAT

CREATE SYNONYM term_act_prd_stat
           FOR ref.term_act_prd_stat
/

-- End of DDL script for TERM_ACT_PRD_STAT

-- Start of DDL script for THRESH_TOLER_CHK_REP
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym THRESH_TOLER_CHK_REP

CREATE SYNONYM thresh_toler_chk_rep
           FOR ref.thresh_toler_chk_rep
/

-- End of DDL script for THRESH_TOLER_CHK_REP

-- Start of DDL script for TIER
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TIER

CREATE SYNONYM tier
           FOR ref.tier
/

-- End of DDL script for TIER

-- Start of DDL script for TNT_STATISTICAL_CODES
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TNT_STATISTICAL_CODES

CREATE SYNONYM tnt_statistical_codes
           FOR ref.tnt_statistical_codes
/

-- End of DDL script for TNT_STATISTICAL_CODES

-- Start of DDL script for TN_CLASSES
-- Generated 3-Oct-99  2:05:52 pm
-- from wh-CNVRTD:2

-- Synonym TN_CLASSES

CREATE SYNONYM tn_classes
           FOR ref.tn_classes
/

-- End of DDL script for TN_CLASSES

-- Start of DDL script for TN_GROUPING
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TN_GROUPING

CREATE SYNONYM tn_grouping
           FOR ref.tn_grouping
/

-- End of DDL script for TN_GROUPING

-- Start of DDL script for TN_STATUSES
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TN_STATUSES

CREATE SYNONYM tn_statuses
           FOR ref.tn_statuses
/

-- End of DDL script for TN_STATUSES

-- Start of DDL script for TOLL_RATE_GROUP
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TOLL_RATE_GROUP

CREATE SYNONYM toll_rate_group
           FOR ref.toll_rate_group
/

-- End of DDL script for TOLL_RATE_GROUP

-- Start of DDL script for TOLL_RATE_GRP_COUNTRIES
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TOLL_RATE_GRP_COUNTRIES

CREATE SYNONYM toll_rate_grp_countries
           FOR ref.toll_rate_grp_countries
/

-- End of DDL script for TOLL_RATE_GRP_COUNTRIES

-- Start of DDL script for TOLL_RATE_GRP_RATING
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TOLL_RATE_GRP_RATING

CREATE SYNONYM toll_rate_grp_rating
           FOR ref.toll_rate_grp_rating
/

-- End of DDL script for TOLL_RATE_GRP_RATING

-- Start of DDL script for TOLL_RS
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TOLL_RS

CREATE SYNONYM toll_rs
           FOR ref.toll_rs
/

-- End of DDL script for TOLL_RS

-- Start of DDL script for TRX_GRP
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TRX_GRP

CREATE SYNONYM trx_grp
           FOR ref.trx_grp
/

-- End of DDL script for TRX_GRP

-- Start of DDL script for TRX_NAME
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TRX_NAME

CREATE SYNONYM trx_name
           FOR ref.trx_name
/

-- End of DDL script for TRX_NAME

-- Start of DDL script for TT_ACCT_EXCL
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TT_ACCT_EXCL

CREATE SYNONYM tt_acct_excl
           FOR ref.tt_acct_excl
/

-- End of DDL script for TT_ACCT_EXCL

-- Start of DDL script for TT_COLLECTION
-- Generated 3-Oct-99  2:05:53 pm
-- from wh-CNVRTD:2

-- Synonym TT_COLLECTION

CREATE SYNONYM tt_collection
           FOR ref.tt_collection
/

-- End of DDL script for TT_COLLECTION

-- Start of DDL script for TT_NETREF1_ACC_TYPE
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_ACC_TYPE

CREATE SYNONYM tt_netref1_acc_type
           FOR ref.tt_netref1_acc_type
/

-- End of DDL script for TT_NETREF1_ACC_TYPE

-- Start of DDL script for TT_NETREF1_BILL_PARAM_FORMAT
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_BILL_PARAM_FORMAT

CREATE SYNONYM tt_netref1_bill_param_format
           FOR ref.tt_netref1_bill_param_format
/

-- End of DDL script for TT_NETREF1_BILL_PARAM_FORMAT

-- Start of DDL script for TT_NETREF1_CHARGE_INFO
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_CHARGE_INFO

CREATE SYNONYM tt_netref1_charge_info
           FOR ref.tt_netref1_charge_info
/

-- End of DDL script for TT_NETREF1_CHARGE_INFO

-- Start of DDL script for TT_NETREF1_COLLECTION_AGENCY
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_COLLECTION_AGENCY

CREATE SYNONYM tt_netref1_collection_agency
           FOR ref.tt_netref1_collection_agency
/

-- End of DDL script for TT_NETREF1_COLLECTION_AGENCY

-- Start of DDL script for TT_NETREF1_CSM_STATUS_ACTIVITY
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_CSM_STATUS_ACTIVITY

CREATE SYNONYM tt_netref1_csm_status_activity
           FOR ref.tt_netref1_csm_status_activity
/

-- End of DDL script for TT_NETREF1_CSM_STATUS_ACTIVITY

-- Start of DDL script for TT_NETREF1_CYCLE
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_CYCLE

CREATE SYNONYM tt_netref1_cycle
           FOR ref.tt_netref1_cycle
/

-- End of DDL script for TT_NETREF1_CYCLE

-- Start of DDL script for TT_NETREF1_DEALER_PROFILE
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_DEALER_PROFILE

CREATE SYNONYM tt_netref1_dealer_profile
           FOR ref.tt_netref1_dealer_profile
/

-- End of DDL script for TT_NETREF1_DEALER_PROFILE

-- Start of DDL script for TT_NETREF1_DEPARTMENT
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_DEPARTMENT

CREATE SYNONYM tt_netref1_department
           FOR ref.tt_netref1_department
/

-- End of DDL script for TT_NETREF1_DEPARTMENT

-- Start of DDL script for TT_NETREF1_FOREIGN_COUNTRY
-- Generated 3-Oct-99  2:05:54 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_FOREIGN_COUNTRY

CREATE SYNONYM tt_netref1_foreign_country
           FOR ref.tt_netref1_foreign_country
/

-- End of DDL script for TT_NETREF1_FOREIGN_COUNTRY

-- Start of DDL script for TT_NETREF1_FR_FM_PLAN
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_FR_FM_PLAN

CREATE SYNONYM tt_netref1_fr_fm_plan
           FOR ref.tt_netref1_fr_fm_plan
/

-- End of DDL script for TT_NETREF1_FR_FM_PLAN

-- Start of DDL script for TT_NETREF1_ID_TYPE
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_ID_TYPE

CREATE SYNONYM tt_netref1_id_type
           FOR ref.tt_netref1_id_type
/

-- End of DDL script for TT_NETREF1_ID_TYPE

-- Start of DDL script for TT_NETREF1_ITEM_DEFINITION
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_ITEM_DEFINITION

CREATE SYNONYM tt_netref1_item_definition
           FOR ref.tt_netref1_item_definition
/

-- End of DDL script for TT_NETREF1_ITEM_DEFINITION

-- Start of DDL script for TT_NETREF1_MARKET
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_MARKET

CREATE SYNONYM tt_netref1_market
           FOR ref.tt_netref1_market
/

-- End of DDL script for TT_NETREF1_MARKET

-- Start of DDL script for TT_NETREF1_MEMO_TYPE
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_MEMO_TYPE

CREATE SYNONYM tt_netref1_memo_type
           FOR ref.tt_netref1_memo_type
/

-- End of DDL script for TT_NETREF1_MEMO_TYPE

-- Start of DDL script for TT_NETREF1_NUMBER_GROUP
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_NUMBER_GROUP

CREATE SYNONYM tt_netref1_number_group
           FOR ref.tt_netref1_number_group
/

-- End of DDL script for TT_NETREF1_NUMBER_GROUP

-- Start of DDL script for TT_NETREF1_NUMBER_LOCATION
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_NUMBER_LOCATION

CREATE SYNONYM tt_netref1_number_location
           FOR ref.tt_netref1_number_location
/

-- End of DDL script for TT_NETREF1_NUMBER_LOCATION

-- Start of DDL script for TT_NETREF1_PAYMENT_METHOD
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_PAYMENT_METHOD

CREATE SYNONYM tt_netref1_payment_method
           FOR ref.tt_netref1_payment_method
/

-- End of DDL script for TT_NETREF1_PAYMENT_METHOD

-- Start of DDL script for TT_NETREF1_POOL
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_POOL

CREATE SYNONYM tt_netref1_pool
           FOR ref.tt_netref1_pool
/

-- End of DDL script for TT_NETREF1_POOL

-- Start of DDL script for TT_NETREF1_RMS_LOCATION
-- Generated 3-Oct-99  2:05:55 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_RMS_LOCATION

CREATE SYNONYM tt_netref1_rms_location
           FOR ref.tt_netref1_rms_location
/

-- End of DDL script for TT_NETREF1_RMS_LOCATION

-- Start of DDL script for TT_NETREF1_SOC_LOAN
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_SOC_LOAN

CREATE SYNONYM tt_netref1_soc_loan
           FOR ref.tt_netref1_soc_loan
/

-- End of DDL script for TT_NETREF1_SOC_LOAN

-- Start of DDL script for TT_NETREF1_SUPPORTED_LANGUAGES
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_SUPPORTED_LANGUAGES

CREATE SYNONYM tt_netref1_supported_languages
           FOR ref.tt_netref1_supported_languages
/

-- End of DDL script for TT_NETREF1_SUPPORTED_LANGUAGES

-- Start of DDL script for TT_NETREF1_TN_STATUSES
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_NETREF1_TN_STATUSES

CREATE SYNONYM tt_netref1_tn_statuses
           FOR ref.tt_netref1_tn_statuses
/

-- End of DDL script for TT_NETREF1_TN_STATUSES

-- Start of DDL script for TT_ODB_SOC
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_ODB_SOC

CREATE SYNONYM tt_odb_soc
           FOR ref.tt_odb_soc
/

-- End of DDL script for TT_ODB_SOC

-- Start of DDL script for TT_PRICE_PLAN
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_PRICE_PLAN

CREATE SYNONYM tt_price_plan
           FOR ref.tt_price_plan
/

-- End of DDL script for TT_PRICE_PLAN

-- Start of DDL script for TT_SWC_FEATURE
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym TT_SWC_FEATURE

CREATE SYNONYM tt_swc_feature
           FOR ref.tt_swc_feature
/

-- End of DDL script for TT_SWC_FEATURE

-- Start of DDL script for UC_RATED_FEATURE
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym UC_RATED_FEATURE

CREATE SYNONYM uc_rated_feature
           FOR ref.uc_rated_feature
/

-- End of DDL script for UC_RATED_FEATURE

-- Start of DDL script for USAGE_ERR_HANDLING
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym USAGE_ERR_HANDLING

CREATE SYNONYM usage_err_handling
           FOR ref.usage_err_handling
/

-- End of DDL script for USAGE_ERR_HANDLING

-- Start of DDL script for UTC_PLANS
-- Generated 3-Oct-99  2:05:56 pm
-- from wh-CNVRTD:2

-- Synonym UTC_PLANS

CREATE SYNONYM utc_plans
           FOR ref.utc_plans
/

-- End of DDL script for UTC_PLANS

-- Start of DDL script for UTC_PLAN_DETAILS
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym UTC_PLAN_DETAILS

CREATE SYNONYM utc_plan_details
           FOR ref.utc_plan_details
/

-- End of DDL script for UTC_PLAN_DETAILS

-- Start of DDL script for VENDOR
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym VENDOR

CREATE SYNONYM vendor
           FOR ref.vendor
/

-- End of DDL script for VENDOR

-- Start of DDL script for VENDOR_ITEM
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym VENDOR_ITEM

CREATE SYNONYM vendor_item
           FOR ref.vendor_item
/

-- End of DDL script for VENDOR_ITEM

-- Start of DDL script for VM_DEVICE_LIST
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym VM_DEVICE_LIST

CREATE SYNONYM vm_device_list
           FOR ref.vm_device_list
/

-- End of DDL script for VM_DEVICE_LIST

-- Start of DDL script for VOUCHER_ACTIVITIES
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym VOUCHER_ACTIVITIES

CREATE SYNONYM voucher_activities
           FOR ref.voucher_activities
/

-- End of DDL script for VOUCHER_ACTIVITIES

-- Start of DDL script for WHSE_ITEM
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym WHSE_ITEM

CREATE SYNONYM whse_item
           FOR ref.whse_item
/

-- End of DDL script for WHSE_ITEM

-- Start of DDL script for WRITE_OFF_REASON
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym WRITE_OFF_REASON

CREATE SYNONYM write_off_reason
           FOR ref.write_off_reason
/

-- End of DDL script for WRITE_OFF_REASON

-- Start of DDL script for XMPS_VALIDATION_LOG
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym XMPS_VALIDATION_LOG

CREATE SYNONYM xmps_validation_log
           FOR ref.xmps_validation_log
/

-- End of DDL script for XMPS_VALIDATION_LOG

-- Start of DDL script for XVALIDATION_LOG
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym XVALIDATION_LOG

CREATE SYNONYM xvalidation_log
           FOR ref.xvalidation_log
/

-- End of DDL script for XVALIDATION_LOG

-- Start of DDL script for ZERO_AT_SOC_REP
-- Generated 3-Oct-99  2:05:57 pm
-- from wh-CNVRTD:2

-- Synonym ZERO_AT_SOC_REP

CREATE SYNONYM zero_at_soc_rep
           FOR ref.zero_at_soc_rep
/

-- End of DDL script for ZERO_AT_SOC_REP

-- Start of DDL script for ZERO_TOLL_FEATURE
-- Generated 3-Oct-99  2:05:58 pm
-- from wh-CNVRTD:2

-- Synonym ZERO_TOLL_FEATURE

CREATE SYNONYM zero_toll_feature
           FOR ref.zero_toll_feature
/

-- End of DDL script for ZERO_TOLL_FEATURE

-- Start of DDL script for ZIP_DECODE
-- Generated 3-Oct-99  2:05:58 pm
-- from wh-CNVRTD:2

-- Synonym ZIP_DECODE

CREATE SYNONYM zip_decode
           FOR ref.zip_decode
/

-- End of DDL script for ZIP_DECODE

-- Start of DDL script for ZONE_DISTANCE
-- Generated 3-Oct-99  2:05:58 pm
-- from wh-CNVRTD:2

-- Synonym ZONE_DISTANCE

CREATE SYNONYM zone_distance
           FOR ref.zone_distance
/

-- End of DDL script for ZONE_DISTANCE
