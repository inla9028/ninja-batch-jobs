select kmbn_activation_status,kmbn_activation_type,count(*) 
from    kmbn_activate_detail
group by kmbn_activation_status,kmbn_activation_type
