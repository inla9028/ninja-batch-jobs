insert into sms_send
            (sms_msisdn,
             sms_text,
             sms_status,
             sms_created,
             sms_sendt,
             sms_priority,
             sms_send,
             sms_orig)
select msisdn,
       'Wet&Wild! Torsdag er det kick off for sommerens feteste festival, ZAP Festivalen i T�nsberg! Music, Party, Action, Sports-ZAPs got it all, C Ya! -zaplife.com',
       null,
       sysdate,
       null,
       '2',
       null,
       '198900'
from mw_tmp_1;

--commit;
--rollback;

commit;
