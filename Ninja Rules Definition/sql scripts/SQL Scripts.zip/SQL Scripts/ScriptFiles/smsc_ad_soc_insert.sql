insert into fokus.smsc_ad_soc
values ('GSM04792810211','PKOC','PPCHG','1', sysdate, null,null);
commit;
