
-- Start of DDL script for NINJA_DATAFIELD
-- Generated 19-Jun-00  1:28:18 pm
-- from wh-INTERF:1

-- Table NINJA_DATAFIELD

CREATE TABLE ninja.ninja_datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD

CREATE  UNIQUE INDEX ninja.ninja_datafield_name_pk
 ON ninja.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD

ALTER TABLE ninja.ninja_datafield
 ADD CONSTRAINT ninja_datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
/

ALTER TABLE ninja.ninja_datafield
 ADD CONSTRAINT ninja_datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES ninja.ninja_dataset(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD

-- Start of DDL script for NINJA_DATAFIELD_NAME_PK
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- Index NINJA_DATAFIELD_NAME_PK

CREATE  UNIQUE INDEX ninja.ninja_datafield_name_pk
 ON ninja.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATAFIELD_NAME_PK

-- Start of DDL script for NINJA_DATAFIELD_VALUE
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- Table NINJA_DATAFIELD_VALUE

CREATE TABLE ninja.ninja_datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0) DEFAULT -1,
  datafield_ismandatory      NUMBER(*,0) DEFAULT -1,
  datafield_occurrance       NUMBER(*,0) DEFAULT 0 NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        98304
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD_VALUE

CREATE  UNIQUE INDEX ninja.ninja_datafield_value_pk
 ON ninja.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        98304
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD_VALUE

ALTER TABLE ninja.ninja_datafield_value
 ADD CONSTRAINT ninja_datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
/

ALTER TABLE ninja.ninja_datafield_value
 ADD CONSTRAINT ninja_datafieldv_ds_fk FOREIGN KEY (dataset_name,datafield_name)
      REFERENCES ninja.ninja_datafield(dataset_name,datafield_name) ON DELETE CASCADE
/

ALTER TABLE ninja.ninja_datafield_value
 ADD CONSTRAINT ninja_user_name_fk FOREIGN KEY (username)
      REFERENCES ninja.ninja_user(username) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD_VALUE

-- Start of DDL script for NINJA_DATAFIELD_VALUE_PK
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- Index NINJA_DATAFIELD_VALUE_PK

CREATE  UNIQUE INDEX ninja.ninja_datafield_value_pk
 ON ninja.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        98304
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATAFIELD_VALUE_PK

-- Start of DDL script for NINJA_DATASET
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- Table NINJA_DATASET

CREATE TABLE ninja.ninja_dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1),
  dataset_comment            VARCHAR2(80)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        65536
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATASET

CREATE  UNIQUE INDEX ninja.ninja_dataset_name_pk
 ON ninja.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATASET

ALTER TABLE ninja.ninja_dataset
 ADD CONSTRAINT ninja_dataset_name_pk PRIMARY KEY (dataset_name)
/


-- End of DDL script for NINJA_DATASET

-- Start of DDL script for NINJA_DATASETS
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- View NINJA_DATASETS

CREATE OR REPLACE VIEW ninja.ninja_datasets (
   dataset_name,
   datafield_name,
   datafield_type,
   username,
   datafield_occurrance,
   datafield_value,
   datafield_ismandatory,
   datafield_islocked,
   in_use )
AS
SELECT dset.dataset_name,
       dfield.datafield_name,
       datafield_type,
       usr.username,
       datafield_occurrance,
       datafield_value,
       datafield_ismandatory,
       datafield_islocked,
       dfield.in_use
FROM   ninja_dataset dset,
       ninja_datafield dfield,
       ninja_datafield_value dfieldv,
       ninja_user usr
WHERE  dset.in_use = 1
AND    dfield.in_use = 1
AND    dset.dataset_name = dfield.dataset_name
AND    dfield.dataset_name = dfieldv.dataset_name
AND    dfield.datafield_name = dfieldv.datafield_name
AND    dfieldv.username = usr.username
/

-- End of DDL script for NINJA_DATASETS

-- Start of DDL script for NINJA_DATASET_NAME_PK
-- Generated 19-Jun-00  1:28:19 pm
-- from wh-INTERF:1

-- Index NINJA_DATASET_NAME_PK

CREATE  UNIQUE INDEX ninja.ninja_dataset_name_pk
 ON ninja.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATASET_NAME_PK

-- Start of DDL script for NINJA_FIELD_DEFS
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Table NINJA_FIELD_DEFS

CREATE TABLE ninja.ninja_field_defs
 (
  ninja_dataset_id           VARCHAR2(30),
  ninja_tux_param            VARCHAR2(80),
  ninja_occurance            NUMBER,
  ninja_mandatory            VARCHAR2(1),
  ninja_lock_state           VARCHAR2(1),
  ninja_tux_type             VARCHAR2(10),
  ninja_default              VARCHAR2(2000)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_FIELD_DEFS

COMMENT ON TABLE ninja.ninja_field_defs IS 'Contains the Tux Service Field descriptions by user of the Ninja access to Fokus.'
/

-- End of DDL script for NINJA_FIELD_DEFS

-- Start of DDL script for NINJA_INTERFACE
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package NINJA_INTERFACE

CREATE OR REPLACE
Package ninja.NINJA_INTERFACE
  IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, initial revision.
-- SAH         000406  Added set_dataset and set_datafield

  -- Create a cursortype for the ninja_datasets view
  TYPE dataset_list IS REF CURSOR RETURN ninja_datasets%ROWTYPE;

  -- Get
  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%type )
    RETURN dataset_list;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER;

  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER;

END; -- Package Specification NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE

-- Start of DDL script for NINJA_INTERFACE
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package body NINJA_INTERFACE

CREATE OR REPLACE
Package Body ninja.NINJA_INTERFACE
IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, Initial revision

  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%TYPE )
    RETURN dataset_list
    AS
  BEGIN
    DECLARE dataset_list_c dataset_list;
    BEGIN
      OPEN dataset_list_c FOR
        SELECT * FROM ninja_datasets
        WHERE ninja_datasets.username = username
        AND ninja_datasets.dataset_name = datasetname
        ORDER BY dataset_name, datafield_name;
      RETURN dataset_list_c;
    END;
  END get_datasets;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_dataset;


  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_datafield;

END; -- Package Body NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE

-- Start of DDL script for NINJA_MIDAS
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package NINJA_MIDAS

CREATE OR REPLACE
Package ninja.NINJA_MIDAS
  IS

  FUNCTION add_charge_record
     ( p_phone_no       IN VARCHAR2,
       p_charge_date    IN VARCHAR2,
       p_charge_code    IN VARCHAR2,
       p_charge_desc    IN VARCHAR2,
       p_charge_amt     IN INTEGER,
       p_memo_text      IN VARCHAR2)
     RETURN  INTEGER;

END; -- Package Specification NINJA_MIDAS
/

-- End of DDL script for NINJA_MIDAS

-- Start of DDL script for NINJA_MIDAS
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package body NINJA_MIDAS

CREATE OR REPLACE
Package Body ninja.NINJA_MIDAS
IS
   FUNCTION add_charge_record
    ( p_phone_no       IN VARCHAR2,
       p_charge_date    IN VARCHAR2,
       p_charge_code    IN VARCHAR2,
       p_charge_desc    IN VARCHAR2,
       p_charge_amt     IN INTEGER,
       p_memo_text      IN VARCHAR2)
       RETURN INTEGER
    IS
        v_charge_date   DATE;
        v_charge_amt    NUMBER;
   BEGIN
        v_charge_date := TO_DATE(p_charge_date, 'YYYYMMDD');
        v_charge_amt := (p_charge_amt / 100);

        INSERT INTO ninja.MIDAS_QUEUE
                (PHONE_NO,
                 CHARGE_DATE,
                 CHARGE_CODE,
                 CHARGE_DESC,
                 CHARGE_AMT,
                 PROC_STATUS,
                 PROC_DATE,
                 MEMO_TEXT)
        VALUES (p_phone_no,
                v_charge_date,
                p_charge_code,
                p_charge_desc,
                v_charge_amt,
                null,
                null,
                p_memo_text);
                COMMIT;
        RETURN 0;
   EXCEPTION
      WHEN OTHERS THEN
          RETURN 1;
   END;

   -- Enter further code below as specified in the Package spec.
END; -- Package Body NINJA_MIDAS
/

-- End of DDL script for NINJA_MIDAS

-- Start of DDL script for NINJA_TELENOR
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package NINJA_TELENOR

CREATE OR REPLACE
Package ninja.NINJA_TELENOR
  IS
  FUNCTION add_charge_record
     ( p_referans_nr    IN VARCHAR2,
       p_charge_text    IN VARCHAR2)
     RETURN  INTEGER;

END;
/

-- End of DDL script for NINJA_TELENOR

-- Start of DDL script for NINJA_TELENOR
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Package body NINJA_TELENOR

CREATE OR REPLACE
Package Body ninja.NINJA_TELENOR
IS
--
   FUNCTION add_charge_record
      (p_referans_nr    IN VARCHAR2,
       p_charge_text    IN VARCHAR2)
       RETURN INTEGER
    IS

    CURSOR cur_sel_exist ( p_ref_nr IN VARCHAR2 )
    IS
        SELECT  *
        FROM    NINJA_TNOR_TRANS
        WHERE   REFERASN_NR = p_ref_nr;

        v_tnor_rec  cur_sel_exist%ROWTYPE;

   BEGIN
       OPEN     cur_sel_exist ( p_referans_nr );
       FETCH    cur_sel_exist INTO v_tnor_rec;
       IF cur_sel_exist%NOTFOUND
       THEN
            INSERT INTO NINJA_TNOR_TRANS
                (REFERASN_NR,
                 RECORD_TEXT)
            VALUES (p_referans_nr,
                    p_charge_text);
            COMMIT;
            CLOSE cur_sel_exist;
            RETURN 0;
       ELSE
            CLOSE cur_sel_exist;
            RETURN 1;
       END IF;
   EXCEPTION
      WHEN OTHERS THEN
          RETURN 1;
   END;

   -- Enter further code below as specified in the Package spec.
END; -- Package Body NINJA_MIDAS
/

-- End of DDL script for NINJA_TELENOR

-- Start of DDL script for NINJA_TNOR_TRANS
-- Generated 19-Jun-00  1:28:20 pm
-- from wh-INTERF:1

-- Table NINJA_TNOR_TRANS

CREATE TABLE ninja.ninja_tnor_trans
 (
  referasn_nr                VARCHAR2(25),
  record_text                VARCHAR2(255)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        147456
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_TNOR_TRANS

COMMENT ON TABLE ninja.ninja_tnor_trans IS 'Transaction list of applied telenor charges'
/

-- Indexes for NINJA_TNOR_TRANS

CREATE  INDEX ninja.ntt_idx1
 ON ninja.ninja_tnor_trans
  ( referasn_nr  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_TNOR_TRANS

-- Start of DDL script for NINJA_USER
-- Generated 19-Jun-00  1:28:21 pm
-- from wh-INTERF:1

-- Table NINJA_USER

CREATE TABLE ninja.ninja_user
 (
  username                   VARCHAR2(32) NOT NULL,
  dataset_name               VARCHAR2(32)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_USER

COMMENT ON TABLE ninja.ninja_user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for NINJA_USER

CREATE  UNIQUE INDEX ninja.sys_c0056039
 ON ninja.ninja_user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_USER

ALTER TABLE ninja.ninja_user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for NINJA_USER

-- Start of DDL script for NTT_IDX1
-- Generated 19-Jun-00  1:28:21 pm
-- from wh-INTERF:1

-- Index NTT_IDX1

CREATE  INDEX ninja.ntt_idx1
 ON ninja.ninja_tnor_trans
  ( referasn_nr  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE data
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NTT_IDX1
