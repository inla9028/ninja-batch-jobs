CREATE TABLE master_processed_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_processed_features IS 'Holds features of successfully processed SOC''s'
/

COMMENT ON COLUMN master_processed_features.feature_code IS 'SOC feature'
/
COMMENT ON COLUMN master_processed_features.trans_number IS 'Foreign key column from MASTER_TRANSACTIONS table'
/

ALTER TABLE master_processed_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_processed_features
 ADD CONSTRAINT master_processed_features_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_TRANSACTIONS(trans_number)
/

CREATE TABLE master_procd_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_procd_feature_parms IS 'Holds feature parameter values'
/
COMMENT ON COLUMN master_procd_feature_parms.feature_code IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_procd_feature_parms.trans_number IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.value IS 'Value of parameter'
/

ALTER TABLE master_procd_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_procd_feature_parms
 ADD CONSTRAINT master_procd_feature_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_PROCESSED_FEATURES(trans_number,feature_code)
/

