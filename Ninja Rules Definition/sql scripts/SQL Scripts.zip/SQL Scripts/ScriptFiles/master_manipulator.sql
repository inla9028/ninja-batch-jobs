CREATE TABLE master_transactions
 (
  trans_number               NUMBER(9) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action_code                VARCHAR2(15) NOT NULL,
  new_soc		     VARCHAR2(9),
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(100),
  dealer_code                VARCHAR2(5),
  sales_agent                VARCHAR2(5),
  priority                   NUMBER(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_transactions IS 'Holds SOC transactions (add/modify/delete/replace) to be processed by the MasterManipulator'
/
COMMENT ON COLUMN master_transactions.action_code IS 'Code specifying the transaction type. Valid values: ADD, MODIFY and DELETE'
/
COMMENT ON COLUMN master_transactions.enter_time IS 'Time when row was inserted into this table. Automatically generated value'
/
COMMENT ON COLUMN master_transactions.priority IS 'Transaction priority. Value from 1 to 5 where 1 is highest priority.'
/
COMMENT ON COLUMN master_transactions.process_status IS 'Process status. Valid values: WAITING, IN_PROGRESS, PRSD_SUCCESS, PRSD_ERROR and PRSD_FATAL'
/
COMMENT ON COLUMN master_transactions.process_time IS 'Time when service request was processed'
/
COMMENT ON COLUMN master_transactions.request_time IS 'Time when transaction must be processed. Defaults to value in NETER_TIME column'
/
COMMENT ON COLUMN master_transactions.soc IS 'SOC which needs to be Added/modified/deleted'
/
COMMENT ON COLUMN master_transactions.status_desc IS 'Error message'
/
COMMENT ON COLUMN master_transactions.subscriber_no IS 'Subscriber where the transaction must be carried out'
/
COMMENT ON COLUMN master_transactions.trans_number IS 'Unique transaction number.'
/

CREATE  INDEX master_transactions_idx1
 ON master_transactions
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX master_transactions_idx2
 ON master_transactions
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_transactions
 ADD PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con1 CHECK ( action_code IN ('ADD', 'MODIFY', 'DELETE', 'REPLACE'))
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con2 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR', 'PRSD_FATAL'))
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con3 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for SERVICE_TRANSACTIONS

CREATE OR REPLACE TRIGGER master_transactions_trg1
BEFORE INSERT
ON master_transactions
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_success_count     NUMBER DEFAULT 0;
  v_error_count       NUMBER DEFAULT 0;

 BEGIN
  IF INSERTING
  THEN
            -- Set enter time. And if request time is not set, then set it to enter time
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

  END IF;
 END;
/


CREATE TABLE master_tran_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_tran_features IS 'Holds features for SOC''s to be processed by the MasterManipulator'
/
COMMENT ON COLUMN master_tran_features.feature_code IS 'Feature code of SOC to be processed'
/
COMMENT ON COLUMN master_tran_features.trans_number IS 'Foreign key from MASTER_TRANSACTIONS'
/

ALTER TABLE master_tran_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_tran_features
 ADD CONSTRAINT master_tran_features_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_TRANSACTIONS(trans_number)
/

CREATE TABLE master_tran_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_tran_feature_parms IS 'Holds feature parameter values'
/
COMMENT ON COLUMN master_tran_feature_parms.feature_code IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_tran_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_tran_feature_parms.trans_number IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_tran_feature_parms.value IS 'Value of parameter'
/

ALTER TABLE master_tran_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_tran_feature_parms
 ADD CONSTRAINT master_tran_feat_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_TRAN_FEATURES(trans_number,feature_code)
/

CREATE TABLE master_processed_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_processed_features IS 'Holds features of successfully processed SOC''s'
/

COMMENT ON COLUMN master_processed_features.feature_code IS 'SOC feature'
/
COMMENT ON COLUMN master_processed_features.trans_number IS 'Foreign key column from MASTER_TRANSACTIONS table'
/

ALTER TABLE master_processed_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_processed_features
 ADD CONSTRAINT master_processed_features_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_TRANSACTIONS(trans_number)
/

CREATE TABLE master_procd_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

COMMENT ON TABLE master_procd_feature_parms IS 'Holds feature parameter values'
/
COMMENT ON COLUMN master_procd_feature_parms.feature_code IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_procd_feature_parms.trans_number IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.value IS 'Value of parameter'
/

ALTER TABLE master_procd_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_procd_feature_parms
 ADD CONSTRAINT master_procd_feat_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_PROCESSED_FEATURES(trans_number,feature_code)
/

