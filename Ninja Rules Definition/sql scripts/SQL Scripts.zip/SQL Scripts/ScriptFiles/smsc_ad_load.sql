insert into fokus.smsc_ad_soc
select sub,soc,action,'1',sysdate,null
from mw_tmp_load_smsc_ad_socs;
commit;
