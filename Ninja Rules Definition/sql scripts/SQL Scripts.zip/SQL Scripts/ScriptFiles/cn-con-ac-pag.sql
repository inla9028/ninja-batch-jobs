select * from contract where c_cycle_code = '01' and c_cont_status = 'CN' and
exists
(select ' ' from pag_f where
pag_f.c_acct = contract.c_acct and
pag_f.c_contract = contract.c_contract and
pag_f.c_pag_phone_status != 'CN');
