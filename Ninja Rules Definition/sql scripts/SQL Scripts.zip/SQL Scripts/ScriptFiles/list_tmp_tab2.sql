INSERT INTO MW_TMP_ACT_PP
(select 'R', rtrim(act_type), rtrim(act_sub_type), rtrim(campaign), rtrim(pp)
from interf.mw_tmp_tab2@wh01
group by act_type, act_sub_type, campaign, pp);
commit;
