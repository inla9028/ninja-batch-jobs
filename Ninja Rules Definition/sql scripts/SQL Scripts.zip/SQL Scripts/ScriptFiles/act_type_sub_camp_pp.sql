select act_type, act_sub_type, campaign, pp, count(*)
from mw_tmp_tab1
group by act_type, act_sub_type, campaign, pp
