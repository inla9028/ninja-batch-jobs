SELECT a.bill_agr_types_sub_id, a.org_agreement_type,
       a.new_agreement_type, a.org_account_type, a.new_account_type,
       a.org_account_sub_type, a.new_account_sub_type, a.org_priceplan,
       a.new_priceplan, a.org_campaign_id, a.new_campaign_id,
       a.commitment_months, a.remaining_com_months,
       a.subscription_type_id, a.effective_date, a.expiration_date
  FROM bill_agr_types_sub_types a
  where org_account_type = 'B' 
  and new_account_type = 'B' 
  and org_account_sub_type = new_account_sub_type
  and org_priceplan in ('PPTA','PPTB','PPTC')
  and new_priceplan in ('PPTA','PPTB','PPTC')
  and commitment_months in (0,12)
--  and new_campaign_id = '000000000'
--  and sysdate between effective_date and expiration_date
