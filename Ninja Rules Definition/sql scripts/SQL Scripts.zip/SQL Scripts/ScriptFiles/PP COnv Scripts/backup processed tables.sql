create table main_pptbk_conv_procd_subs as
select * from pptbk_conv_procd_subs;
create table main_pptbk_conv_sub_socs as
select * from pptbk_conv_procd_sub_socs;

commit work;
