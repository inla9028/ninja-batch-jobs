update pptbk_conv_procd_subs
set process_stream = 1,
    --org_pp_dealer_code = null,
    --new_pp_dealer_code = null,
    --org_priceplan = null,
    --new_priceplan = null,
    --org_campaign = null,
    --rem_months_com = null,
    --sub_status = null,
    --sub_status_rsn = null,
    --socs_before = null,
    --socs_after = null,
    process_time = null,
    status_desc = null,
    --process_run_date = sysdate,
    process_status = 'WAITING'
where process_status = 'PRSD_ERROR';
--and status_desc like '%';
--and pre_sub_status <> 'S';
commit work;
