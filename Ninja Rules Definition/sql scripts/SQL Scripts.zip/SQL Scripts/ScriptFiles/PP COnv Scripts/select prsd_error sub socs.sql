--delete FROM NINJA.PPBK_CONV_PROCD_SUB_SOCS a
select * FROM NINJA.PPPK_CONV_PROCD_SUB_SOCS a
where exists (select ' '
              from NINJA.PPPK_CONV_PROCD_SUBS b
              where a.ban = b.ban
              and a.subscriber_no = b.subscriber_no
              and b.process_status = 'PRSD_ERROR')
order by subscriber_no,process_state desc,soc

