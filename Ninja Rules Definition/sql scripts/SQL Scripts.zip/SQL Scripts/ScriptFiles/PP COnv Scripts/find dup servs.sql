select subscriber_no, ban, count(*)
from mdcust.service_agreement
where nvl(expiration_date, sysdate+1) > sysdate
and soc in ('VMBED','VMDUO','VMFRA','VMFRA+','VMFREE','VMFREE+','VMFRO','VMJIA','VMJIA+','VMJIB','VMJIB+','VMKAMP01','VMKAMP01+','VMKAMP01P','VMKAMP02','VMKAMP02P','VMKON','VMORG','VMORG+','VMPOST','VMPOST01','VMPOST01P','VMPOSTF','VMPOSTF01','VMPOSTF1P','VMPOSTFP','VMPOSTP','VMPROM01','VMSDIV','VMSDIV+','VMSDIV01','VMSDIV02','VMSDIV03','VMSDIVP01','VMSDUO','VMSTD','VMSTD+','VMSTO','VMSTO+','VMVS','VMVS+','VMVSE','VMVSP','VMVSP+','VMVSPRE')
group by subscriber_no, ban
having count(*) > 1
