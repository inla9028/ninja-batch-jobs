create table mw_tmp_pppk_subs_remain as
SELECT a.ban, a.subscriber_no, rtrim(a.soc) as soc, a.sys_creation_date, a.sys_update_date, a.operator_id,
       a.campaign, a.commit_orig_no_month,a.soc_effective_date, a.customer_id, a.effective_date,
       a.service_type, a.expiration_date, a.soc_level_code,
       a.dealer_code, a.sales_agent, a.act_reason_code
  FROM service_agreement@prod.world a
  where a.soc in ('PFRA','PQFRA','PSTD','PQSTD','PGUF','PQGUF','PSTO','PQSTO','PNHE','PQNHE','PKOR')
  and a.expiration_date > sysdate;
commit;  
--//need to modify table
ALTER TABLE MW_TMP_PPPK_SUBS_REMAIN 
 ADD (    
    acct_type                      VARCHAR2(1),
    acct_sub_type                  VARCHAR2(2),
    ban_status                     VARCHAR2(1),
    bill_cycle                     NUMBER(2,0),
    status_actv_rsn_code           VARCHAR2(4),
    sub_status                     VARCHAR2(1),
    sub_status_last_act            VARCHAR2(3),
    sub_status_rsn_code            VARCHAR2(4),
    notified                       VARCHAR2(1)
    )
/
CREATE INDEX mw_tmp_prs_idx1 ON mw_tmp_pppk_subs_remain
  (
    ban                             ASC,
    subscriber_no                   ASC
  )
/
CREATE INDEX mw_tmp_s_rem_idx2 ON mw_tmp_pppk_subs_remain
  (
    subscriber_no                   ASC
  )
/




update mw_tmp_pppk_subs_remain a
set (a.acct_type, a.acct_sub_type, a.ban_status, a.bill_cycle, a.status_actv_rsn_code) =
(select b.account_type, b.account_sub_type, b.ban_status, b.bill_cycle, b.status_actv_rsn_code
from billing_account@prod.world b
where a.ban = b.ban);
commit;

update mw_tmp_pppk_subs_remain a
set (a.sub_status, a.sub_status_last_act, a.sub_status_rsn_code) =
(select b.sub_status, b.sub_status_last_act, b.sub_status_rsn_code
from subscriber@prod.world b
where a.ban = b.customer_id
and a.subscriber_no = b.subscriber_no);
commit;
