create table mw_disc_changes_cyc2 as
select a.* from ban_hierarchy_disc a, bus_pp_conv_mans b
where b.man = a.tree_root_ban
and b.bpp_cycle = 2
and a.operator_id in ('100832','200900')

