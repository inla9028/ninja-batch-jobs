update ppbk_conv_procd_subs
set process_stream = 1, conv_run_no = 1
where substr(to_char(ban),1,1) = 9
and process_stream is null;
commit work;
