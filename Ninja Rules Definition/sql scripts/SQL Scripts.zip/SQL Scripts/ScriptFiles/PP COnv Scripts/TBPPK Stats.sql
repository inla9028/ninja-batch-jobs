
 SELECT
    to_char(PROCESS_TIME,'YYYYMMDD HH24'),count(*)
 FROM PPTBK_CONV_PROCD_SUBS
 where process_status = 'PRSD_SUCCESS'
 group by to_char(PROCESS_TIME,'YYYYMMDD HH24')
 order by to_char(PROCESS_TIME,'YYYYMMDD HH24') desc
