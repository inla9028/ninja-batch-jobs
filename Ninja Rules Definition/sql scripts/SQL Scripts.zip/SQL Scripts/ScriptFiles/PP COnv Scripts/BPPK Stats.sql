
 SELECT
    to_char(PROCESS_TIME,'YYYYMMDD HH24MI'),count(*)
 FROM PPTBK_CONV_PROCD_SUBS
 where process_status = 'PRSD_SUCCESS'
 group by to_char(PROCESS_TIME,'YYYYMMDD HH24MI')
 order by to_char(PROCESS_TIME,'YYYYMMDD HH24MI') desc
