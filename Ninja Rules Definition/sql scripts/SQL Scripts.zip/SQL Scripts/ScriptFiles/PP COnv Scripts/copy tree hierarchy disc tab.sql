create table mw_hierarchy_disc_afterc5 as
select b.* from mw_tmp_bppk_man_list a,BAN_HIERARCHY_DISC@prod.world b
where a.tree_root_ban = b.tree_root_ban;

commit work;
