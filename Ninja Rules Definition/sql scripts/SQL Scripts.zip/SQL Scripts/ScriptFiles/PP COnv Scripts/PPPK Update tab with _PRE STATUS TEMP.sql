update pppk_conv_procd_subs a
set a.pre_sub_status = (select b.sub_status
             from subscriber@prod.world b
             where a.subscriber_no = b.subscriber_no
             and a.ban = b.customer_id);

commit work;
