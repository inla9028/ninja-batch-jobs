select process_stream,count(*)
from pptbk_conv_procd_subs
where process_status = 'WAITING'
group by process_stream
