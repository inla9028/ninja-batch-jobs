update pppk_conv_procd_subs a
set a.ban = (select b.ban 
             from service_agreement@prod.world b
             where a.subscriber_no = b.subscriber_no
             and b.service_type = 'P'
             and b.expiration_date > sysdate);
             
commit work;             
