select soc,
       process_state,
       count(*)
from pptbk_conv_procd_sub_socs
group by soc,process_state
order by soc,process_state desc       
