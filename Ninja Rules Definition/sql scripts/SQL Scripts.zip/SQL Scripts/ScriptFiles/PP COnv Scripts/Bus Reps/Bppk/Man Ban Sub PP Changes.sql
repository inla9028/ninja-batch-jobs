select man,
       ban,
       subscriber_no,
       org_priceplan,
       new_priceplan
from ppbk_conv_procd_subs
where process_status = 'PRSD_SUCCESS'
order by man,
         ban,
         subscriber_no
       
