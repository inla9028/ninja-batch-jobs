update mw_tmp_fox03 a
set a.tree_count = (select count(*) as ban_count
                  from ntcappo.ban_hierarchy_tree b
                  where a.tree_root_ban = b.tree_root_ban
                  and b.expiration_date is null);
commit work;                  
