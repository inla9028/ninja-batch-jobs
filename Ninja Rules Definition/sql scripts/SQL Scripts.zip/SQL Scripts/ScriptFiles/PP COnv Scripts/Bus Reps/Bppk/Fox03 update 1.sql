update mw_tmp_fox03 a 
set (a.acct_type, a.acct_sub_type, a.ban_status, a.bill_cycle) = 
(select b.ACCOUNT_TYPE, b.account_sub_type, b.ban_status, b.bill_cycle from ntcappo.billing_account b where a.tree_root_ban = b.ban)

