update mw_tmp_fox03 a 
set a.control_name = 
(select b.control_name from ntcappo.address_name_link b where a.tree_root_ban = b.customer_id and b.link_type = 'L' and b.expiration_date is null);
commit work;

