select count(*)
from ppbk_conv_procd_sub_socs
--order by ban,
--         subscriber_no,
--         process_state desc,
--         soc
