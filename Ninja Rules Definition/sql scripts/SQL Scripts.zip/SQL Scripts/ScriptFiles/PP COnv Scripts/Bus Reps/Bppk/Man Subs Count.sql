
 SELECT
    MAN,
    count(*)
 FROM PPTBK_CONV_PROCD_SUBS
 where process_status = 'PRSD_SUCCESS'
 group by man
 order by man
