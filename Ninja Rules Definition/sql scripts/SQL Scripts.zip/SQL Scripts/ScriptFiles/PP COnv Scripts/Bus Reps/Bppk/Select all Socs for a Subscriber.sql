
 SELECT
    SUBSCRIBER_NO,
    BAN,
    PROCESS_STATE,
    SOC,
    SOC_FEATURES
 FROM PPTBK_CONV_PROCD_SUB_SOCS
where subscriber_no in ('GSM04798245709','GSM04795744608')
order by subscriber_no,process_state desc, soc
