select *
from ppbk_conv_procd_subs
order by process_status,
         man,
         ban,
         subscriber_no
