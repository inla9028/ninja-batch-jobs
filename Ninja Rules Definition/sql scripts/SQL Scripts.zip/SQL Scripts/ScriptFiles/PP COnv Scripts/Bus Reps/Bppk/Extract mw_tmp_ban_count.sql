create table mw_tmp_ban_count as
select distinct man,ban from ppbk_conv_procd_subs
where process_status = 'PRSD_SUCCESS'
