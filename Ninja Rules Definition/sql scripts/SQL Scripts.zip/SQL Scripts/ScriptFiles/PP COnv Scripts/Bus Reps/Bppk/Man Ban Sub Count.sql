select 
man,ban,count(*)
from ppbk_conv_procd_subs
where process_status = 'PRSD_SUCCESS'
group by man,ban
order by man,ban
