
 SELECT
    MAN,
    count(*)
 FROM NINJA.MW_TMP_BAN_COUNT
 where process_status = 'PRSD_SUCCESS'
 group by man
 order by man
