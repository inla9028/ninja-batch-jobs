
 SELECT
    a.SUBSCRIBER_NO,
    a.BAN,
    a.PROCESS_STATE,
    a.SOC
 FROM PPBK_CONV_PROCD_SUB_SOCS a
 where a.process_state = 'B' and a.soc = 'CALLSPFRI'
 and not exists (select ' '
                 from PPBK_CONV_PROCD_SUB_SOCS b
                 where a.ban = b.ban
                 and a.subscriber_no = b.subscriber_no
                 and b.soc = 'CALLSPFRI'
                 and b.process_state = 'A')
