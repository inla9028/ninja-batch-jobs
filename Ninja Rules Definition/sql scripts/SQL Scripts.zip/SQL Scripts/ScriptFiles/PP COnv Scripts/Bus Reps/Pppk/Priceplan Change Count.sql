
 SELECT
    ORG_PRICEPLAN,
    NEW_PRICEPLAN,
    count(*)
 FROM PPPK_CONV_PROCD_SUBS
 where procesS_status = 'PRSD_SUCCESS'
 group by ORG_PRICEPLAN,
          NEW_PRICEPLAN
order by org_priceplan


