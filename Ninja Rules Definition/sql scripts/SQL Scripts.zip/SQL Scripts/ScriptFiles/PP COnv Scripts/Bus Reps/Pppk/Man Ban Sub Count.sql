select
ban,count(*)
from pppk_conv_procd_subs
where process_status = 'PRSD_SUCCESS'
group by ban
order by ban
