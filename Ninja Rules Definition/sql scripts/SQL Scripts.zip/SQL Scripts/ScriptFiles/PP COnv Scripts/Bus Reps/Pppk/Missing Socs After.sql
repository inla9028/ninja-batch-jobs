
 SELECT
    a.SUBSCRIBER_NO,
    a.BAN,
    a.PROCESS_STATE,
    a.SOC
 FROM PPPK_CONV_PROCD_SUB_SOCS a
 where a.process_state = 'B' and a.soc = 'VMFREE'
 and not exists (select ' '
                 from PPPK_CONV_PROCD_SUB_SOCS b
                 where a.ban = b.ban
                 and a.subscriber_no = b.subscriber_no
                 and b.soc = 'VMFREE'
                 and b.process_state = 'A')
