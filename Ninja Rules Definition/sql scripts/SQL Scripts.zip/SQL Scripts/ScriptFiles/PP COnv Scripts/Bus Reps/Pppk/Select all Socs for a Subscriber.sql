
 SELECT
    SUBSCRIBER_NO,
    BAN,
    PROCESS_STATE,
    SOC,
    SOC_FEATURES
 FROM NINJA.PPPK_CONV_PROCD_SUB_SOCS
where subscriber_no in ('GSM04792844115')
order by subscriber_no,process_state desc, soc
