select *
from pppk_conv_procd_subs
where process_status = 'PRSD_PASSED_MAN'
order by process_status,
         ban,
         subscriber_no
