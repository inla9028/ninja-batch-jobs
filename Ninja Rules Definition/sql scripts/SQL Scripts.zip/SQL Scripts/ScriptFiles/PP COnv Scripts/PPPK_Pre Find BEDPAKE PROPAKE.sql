
SELECT a.*
FROM PPPK_CONV_PROCD_SUBS a
where a.ban is not null 
and a.org_priceplan not in ('PPTA','PPTB','PPTC','PSFA','PSKV','PSFB','PPOA','PPOB','PPOC')
and exists (select ' '
            from service_agreement@prod.world b
            where a.subscriber_no = b.subscriber_no
            and a.ban = b.ban
            and b.soc = 'PROPAKE'
            and b.expiration_date > sysdate)
and exists (select ' '
            from service_agreement@prod.world c
            where a.subscriber_no = c.subscriber_no
            and a.ban = c.ban
            and c.soc like 'IN%'
            and c.expiration_date > sysdate)

