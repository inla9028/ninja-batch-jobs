update mw_disc_changes_cyc2
set sys_update_date = sys_update_date -10, expiration_date = expiration_date -10
where expiration_date = to_date('11072003','DDMMYYYY');

update mw_disc_changes_cyc2
set sys_creation_date = sys_creation_date -10, effective_date = effective_date -10
where effective_date = to_date('11072003','DDMMYYYY') and expiration_date is null;
commit;
