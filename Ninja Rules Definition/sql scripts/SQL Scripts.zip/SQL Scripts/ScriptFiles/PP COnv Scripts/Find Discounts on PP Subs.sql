select a.subscriber_no,a.org_priceplan,b.*
from pppk_conv_procd_subs a, ban_discount@prod.world b
where a.subscriber_no = b.subscriber_no
and a.org_priceplan not in ('PPTA','PPTB','PPTC','PSFA','PSKV','PSFB','PPOA','PPOB','PPOC')
and a.ban = b.ban
and a.ban is not null
and b.expiration_date > sysdate
