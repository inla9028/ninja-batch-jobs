update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_BC'
where process_status = 'PRSD_PASSED'
and status_desc = 'Skipping Subscriber - because of Ban Status [N].';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_KD'
where process_status = 'PRSD_PASSED'
and status_desc = 'Skipping Subscriber - KONDEAD - Manually Process';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_PPC'
where process_status = 'PRSD_PASSED'
and status_desc like 'Skipping Subscriber - because of Price Plan. - %';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_SC'
where process_status = 'PRSD_PASSED'
and status_desc = 'Skipping Subscriber - because of Cancelled Status ';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_SC'
where process_status = 'PRSD_PASSED'
and pre_sub_status = 'C';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_SB'
where process_status = 'PRSD_PASSED'
and status_desc = 'Skipping Suspended Ban - For Reason Code - COLH';
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_PPC'
where process_status = 'PRSD_PASSED'
and org_priceplan in ('PPTA','PPTB','PPTC','PSKV','PSFB','PSFA','PKOC','PKOM','PKON','PPOA','PPOB','PPOC');
commit;

update pppk_conv_procd_subs
set process_status = 'PRSD_PASSED_PPC'
where process_status = 'PRSD_PASSED'
and org_priceplan like 'PV%';
commit;








