
create table mw_tmp_pptbk_sub_socs as
--insert into mw_tmp_pptbk_sub_socs
select *
from PPTBK_CONV_PROCD_SUB_SOCS a
where not exists (select ' '
              from PPTBK_CONV_PROCD_SUBS b
              where a.ban = b.ban
              and a.subscriber_no = b.subscriber_no
              and b.process_status = 'PRSD_SUCCESS');
commit;

delete FROM PPTBK_CONV_PROCD_SUB_SOCS a
where not exists (select ' '
              from PPTBK_CONV_PROCD_SUBS b
              where a.ban = b.ban
              and a.subscriber_no = b.subscriber_no
              and b.process_status = 'PRSD_SUCCESS');
commit work;
*/
