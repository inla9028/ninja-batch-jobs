insert into ninja_sub_change_status (subscriber_no,action_code,memo_text,reason_code,request_reference_id)
select subscriber_no,'SUSPEND','Re-Suspend BPPK',pre_sub_status_rsn,'BPPK-2' from PPBK_CONV_PROCD_SUBS
where process_status = 'PRSD_ERROR'
and pre_sub_status = 'S';
commit work;
