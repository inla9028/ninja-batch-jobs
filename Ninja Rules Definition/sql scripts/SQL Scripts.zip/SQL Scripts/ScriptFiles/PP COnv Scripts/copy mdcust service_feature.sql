create table bppk_tmp_service_feature as
select b.* from bppk_tmp_service_agreement a, mdcust.service_feature@CP01.world b
where b.ban = a.ban
and b.subscriber_no = a.subscriber_no
and b.soc = a.soc
and b.soc_seq_no = a.soc_seq_no
