insert into ppbk_conv_procd_subs
select * from cyc1_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc2_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc3_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc4_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc5_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc7_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from cyc8_ppbk_conv_procd_subs;
commit;
insert into ppbk_conv_procd_subs
select * from oslot_ppbk_conv_procd_subs;
commit;

insert into ppbk_conv_procd_sub_socs
select * from cyc1_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc2_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc3_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc4_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc5_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc7_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from cyc8_ppbk_conv_procd_sub_socs;
commit;
insert into ppbk_conv_procd_sub_socs
select * from oslot_ppbk_conv_procd_sub_socs;
commit;

