update ninja_jobs set job_status = 'STOPPING' where job_id > 30;
commit work;
