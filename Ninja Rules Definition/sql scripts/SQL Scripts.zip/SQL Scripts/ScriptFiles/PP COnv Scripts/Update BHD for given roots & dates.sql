--- Set the expiration date back 2 days
update ntcappo.ban_hierarchy_disc
set expiration_date = expiration_date - 2, sys_update_date = sys_update_date -3
  where tree_root_ban in (546694209)
and expiration_date in (to_date('11102003','DDMMYYYY'));
--- Set the effective date back 2 days
update ntcappo.ban_hierarchy_disc
set effective_date = effective_date - 2,sys_creation_date = sys_creation_date -3
  where tree_root_ban in (546694209)
and effective_date in (to_date('11102003','DDMMYYYY'));
commit work;

