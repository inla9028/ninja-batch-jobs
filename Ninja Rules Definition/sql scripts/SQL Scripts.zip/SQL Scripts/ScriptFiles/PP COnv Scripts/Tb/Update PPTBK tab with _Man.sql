update pptbk_conv_procd_subs a
set a.man = (select b.tree_root_ban 
             from ntcappo.ban_hierarchy_tree@prod.world b
             where a.ban = b.ban
             and nvl(b.expiration_date, sysdate +1) > sysdate);
             
commit work;             
