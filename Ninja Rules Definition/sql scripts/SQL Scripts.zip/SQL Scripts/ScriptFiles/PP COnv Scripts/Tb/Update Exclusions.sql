insert into tbppk_exclusions tbke
(select bht.ban 
from ntcappo.ban_hierarchy_tree@prod.world bht,tbppk_exclusions tbke
where tbke.ban = bht.tree_root_ban
and nvl(bht.expiration_date, sysdate +1) > sysdate
and not exists (select ' ' 
                from tbppk_exclusions c
                where bht.ban = c.ban))
