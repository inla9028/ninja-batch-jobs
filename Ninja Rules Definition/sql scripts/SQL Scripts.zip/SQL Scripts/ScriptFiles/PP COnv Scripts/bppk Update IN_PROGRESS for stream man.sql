update ppbk_conv_procd_subs
set process_stream = 1,process_status = 'WAITING', conv_run_no = 2
where substr(to_char(man),9,1) = 4;
commit work;
