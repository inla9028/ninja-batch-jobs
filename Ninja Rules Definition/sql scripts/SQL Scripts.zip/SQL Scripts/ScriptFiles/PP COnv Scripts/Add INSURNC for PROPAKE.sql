insert into mw_tmp_trans
select a.subscriber_no,
       'INSURNC',
       'ADD',
       null,
       null,
       null,
       'BPPK 5',
       'Added INSURNC for Propake Removal.'
from  ppbk_conv_procd_sub_socs a
where a.process_state = 'B'
and a.soc = 'PROPAKE'
and not exists (select ' '
                from ppbk_conv_procd_sub_socs b
                where a.ban = b.ban
                and a.subscriber_no = b.subscriber_no
                and b.process_state = 'A'
                and b.soc like 'INSURN%');
commit;


