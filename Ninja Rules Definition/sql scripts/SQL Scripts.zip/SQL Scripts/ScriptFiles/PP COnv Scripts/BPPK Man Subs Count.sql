select man, count(distinct ban)
from ppbk_conv_procd_subs
where process_status = 'PRSD_SUCCESS'
group by man
order by man
