create table cyc3_pppk_conv_procd_subs as
select * from pppk_conv_procd_subs;
create table cyc3_pppk_conv_procd_sub_socs as
select * from pppk_conv_procd_sub_socs;

commit work;
