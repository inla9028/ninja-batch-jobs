
 --SELECT 'insert into pppk_conv_procd_subs (process_cycle, ban, subscriber_no, process_status) values (''03'','  ||
 SELECT 'insert into ppbk_conv_procd_subs (process_cycle, ban, subscriber_no, process_status) values (''07'','  ||
   a.ban  || ', ''' || a.SUBSCRIBER_NO || ''',''' || 'IN_PROGRESS'');'
 FROM SERVICE_AGREEMENT a
 --where a.soc in ('PKOR','PGUF','PQGUF','PFRA','PQFRA','PSTD','PQSTD','PSTO','PQSTO') and a.expiration_date > sysdate
 where a.subscriber_no like 'GSM%' and a.soc in  ('PQSFA','PQSFB','PQSFIBM','PQSFS','PQSKA','PQSKB','PQSKC','PSFA','PSFS','PSFT','PSHB','PSKA','PSKB','PSKC','PSKE','PQSKS','PQSKT','PQSKV','PSKD','PSKS','PSKT','PSKZ','PSDA')  and a.expiration_date > sysdate
 and exists (select ' ' from billing_account b where a.ban = b.customer_id and b.bill_cycle = 7)
-- and exists (select ' ' from service_agreement c where a.ban = c.ban and a.subscriber_no = c.subscriber_no and c.soc = 'INSURE+' and c.expiration_date > sysdate)
