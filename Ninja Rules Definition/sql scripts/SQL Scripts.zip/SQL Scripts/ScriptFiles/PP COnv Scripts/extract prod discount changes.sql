insert into mw_disc_changes_cyc5
select a.* from ban_hierarchy_disc a, bus_pp_conv_mans b
where b.man = a.tree_root_ban
and b.bpp_cycle = 5
and a.operator_id in ('100832','200900');
insert into mw_disc_changes_cyc3
select a.* from ban_hierarchy_disc a, bus_pp_conv_mans b
where b.man = a.tree_root_ban
and b.bpp_cycle = 3
and a.operator_id in ('100832','200900');
commit work;
