update pppk_conv_procd_subs a
set a.process_status = 'WAITING'
where exists (select ' ' 
              from mw_tmp_proc_list b
              where a.subscriber_no = b.subscriber_no
              and a.ban = b.ban);
              
                
