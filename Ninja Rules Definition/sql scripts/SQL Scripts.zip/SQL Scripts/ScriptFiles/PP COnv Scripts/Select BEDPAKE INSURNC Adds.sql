select a.*
from ppbk_conv_procd_sub_socs a
where a.process_state = 'B'
and a.soc = 'BEDPAKE'
and not exists (select ' '
                from ppbk_conv_procd_sub_socs b
                where a.ban = b.ban
                and a.subscriber_no = b.subscriber_no
                and b.process_state = 'A'
                and b.soc like 'INSURN%')
                
