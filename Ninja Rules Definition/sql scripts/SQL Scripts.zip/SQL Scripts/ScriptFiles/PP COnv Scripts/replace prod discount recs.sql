delete from ntcappo.BAN_HIERARCHY_DISC a
where exists (select ' ' from mw_disc_changes_cyc3 b where a.bhd_seq_no = b.bhd_seq_no);
insert into ntcappo.BAN_HIERARCHY_DISC
select * from mw_disc_changes_cyc3;
commit;
delete from ntcappo.BAN_HIERARCHY_DISC a
where exists (select ' ' from mw_disc_changes_cyc5 b where a.bhd_seq_no = b.bhd_seq_no);
insert into ntcappo.BAN_HIERARCHY_DISC
select * from mw_disc_changes_cyc5;
commit;
