select process_status,count(*)
from pptbk_conv_procd_subs
group by process_status
