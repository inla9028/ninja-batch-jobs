insert into pppk_conv_procd_subs (process_cycle,
                                  process_run_date,
                                  subscriber_no,
                                  process_status
                                  )
                                  select '03',to_date('01092003','DDMMYYYY'),subscriber_no,'IN_PROGRESS'
                                  from mw_tmp_subs;
                                  
                                  
                                  
commit work;                                  
