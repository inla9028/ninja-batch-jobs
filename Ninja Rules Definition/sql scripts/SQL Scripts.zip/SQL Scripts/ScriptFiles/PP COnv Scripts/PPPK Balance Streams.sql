update pppk_conv_procd_subs
set process_stream = 10, process_status = 'WAITING'
where process_status = 'IN_PROGRESS' and substr(to_char(ban),1,1) = 9;
commit;
