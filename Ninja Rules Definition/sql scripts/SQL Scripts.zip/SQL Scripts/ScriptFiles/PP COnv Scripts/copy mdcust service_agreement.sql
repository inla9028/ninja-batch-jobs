create table bppk_tmp_service_agreement as
select b.* from ppbk_conv_procd_subs a, mdcust.service_agreement@CP01.world b
where b.ban = a.ban
and b.subscriber_no = a.subscriber_no
and b.expiration_date > sysdate
--and rownum < 50
