


CREATE  INDEX mw_tmp_subs1
 ON mw_tmp_tab1
  ( act_type,
    act_sub_type,
    sub,
    campaign,
    pp  )
/

