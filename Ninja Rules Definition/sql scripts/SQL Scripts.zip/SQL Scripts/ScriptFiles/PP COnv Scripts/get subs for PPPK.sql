 SELECT
    a.SUBSCRIBER_NO
 FROM SERVICE_AGREEMENT a
 where a.soc in ('PKOR','PFRA','PQFRA','PSTD','PQSTD','PSTO','PQSTO') and a.expiration_date > sysdate
 and exists (select ' ' from billing_account b where a.ban = b.customer_id and b.bill_cycle = 4)
-- and exists (select ' ' from service_agreement c where a.ban = c.ban and a.subscriber_no = c.subscriber_no and c.soc = 'INSURE+' and c.expiration_date > sysdate)
 and exists (select ' ' from subscriber d where a.ban = d.customer_id and a.subscriber_no = d.subscriber_no and d.sub_status <> 'A')
