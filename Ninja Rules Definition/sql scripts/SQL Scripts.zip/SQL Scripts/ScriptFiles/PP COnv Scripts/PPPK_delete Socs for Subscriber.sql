delete from pppk_conv_procd_sub_socs
where subscriber_no in ('GSM04792447302');
commit work;
