
-- Start of DDL script for PPBK_CONV_PROCD_SUBS
-- Generated 18-jun-03  5:14:52 am
-- from ernst-NINJA:1

-- Table PPBK_CONV_PROCD_SUBS

CREATE TABLE ppbk_conv_procd_subs
 (
  process_stream             VARCHAR2(2),
  process_cycle              VARCHAR2(2),
  process_run_date           DATE,
  ban                        NUMBER(9),
  subscriber_no              VARCHAR2(20) NOT NULL,
  org_pp_dealer_code         VARCHAR2(5),
  new_pp_dealer_code         VARCHAR2(5),
  org_priceplan              VARCHAR2(9),
  new_priceplan              VARCHAR2(9),
  org_campaign               VARCHAR2(9),
  rem_months_com             NUMBER(3),
  pre_sub_status             VARCHAR2(1),
  pre_sub_status_rsn         VARCHAR2(4),
  pre_sub_resume_date        VARCHAR2(20),
  post_sub_status            VARCHAR2(1),
  post_sub_status_rsn        VARCHAR2(4),
  socs_before                NUMBER(2),
  socs_after                 NUMBER(2),
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(300),
  conv_run_no                NUMBER(2),
  man                        NUMBER(9)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for PPBK_CONV_PROCD_SUBS

CREATE  UNIQUE INDEX ppbk_cs_idx1
 ON ppbk_conv_procd_subs
  ( ban,
    subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

CREATE  INDEX ppbk_cs_idx2
 ON ppbk_conv_procd_subs
  ( process_stream,
    process_status  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for PPBK_CONV_PROCD_SUBS
