create table mw_tmp_cyc7_from_tree as
select a.tree_root_ban,
       a.ban,
       a.effective_date,
       a.tree_level,
       a.parent_ban,
       a.expiration_date,
       b.account_type,
       b.account_sub_type,
       b.ban_status,
       b.bill_cycle,
       b.bl_next_cycle
from  ban_hierarchy_tree a, billing_account b
where a.ban = b.customer_id
and (b.bill_cycle = 7  or b.bl_next_cycle = 7)    
and b.ban_status in ('O','S')
