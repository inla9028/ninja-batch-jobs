select process_stream,substr(to_char(ban),9,1), count(*)
from pptbk_conv_procd_subs
where process_status = 'WAITING'
group by process_stream,substr(to_char(ban),9,1)
