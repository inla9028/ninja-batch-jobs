update pppk_conv_procd_subs a
set a.process_status = 'ON_HOLD'
where a.org_priceplan = 'PKOR' and exists
    (select ' ' from service_agreement@prod.world b
                where a.subscriber_no = b.subscriber_no
                and a.ban = b.ban
                and b.soc = 'KONDEAD'
                and b.expiration_date > sysdate);

commit work;
