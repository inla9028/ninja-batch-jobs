select c_pag_phone_status,c_phone_lvl,c_primary_prod,count(*) from pag_f where
(pag_f.c_acct,pag_f.c_contract)
in
(select contract.c_acct,contract.c_contract from contract
where contract.c_acct = pag_f.c_acct
and contract.c_contract = pag_f.c_contract
and contract.c_cont_status in ('AC','SU')
and contract.c_cycle_code = '10')
group by c_pag_phone_status ,c_phone_lvl,c_primary_prod
