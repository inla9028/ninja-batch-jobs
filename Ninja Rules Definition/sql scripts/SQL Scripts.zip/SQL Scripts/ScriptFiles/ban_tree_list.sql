select tree_root_ban, count(*)
from ban_hierarchy_tree
where (expiration_date is null) or (expiration_date > sysdate)
group by tree_root_ban
