select 'delete from mw_tmp_tab2 where act_type = ''' || act_type
                           || ''' and act_sub_type = ''' || act_sub_type
                           || ''' and campaign = ''' || campaign
                           || ''' and pp = ''' || pp || ''';'
                           
from mw_tmp_tab2
group by act_type,act_sub_type,campaign,pp
having count(*) < 5
