INSERT
INTO    ext_driver
SELECT  uf0010_old_id
FROM    uf_customer_uf0010;

DELETE
FROM    ext_driver
WHERE   (ext_driver.old_id)
IN      (SELECT ext_cross_excl.old_id
         FROM   ext_cross_excl
         WHERE  ext_cross_excl.old_id = ext_driver.old_id);
         
         
COMMIT;   
