PROMPT Creating index: CNVRT_EXT_IDX1
CREATE INDEX	cnvrt_ext_idx1
ON		cnvrt_ext( cnvrt_srt_key ASC )
TABLESPACE	cnvrt_index;

PROMPT Creating index: CNVRT_EXT1_IDX1
CREATE INDEX    cnvrt_ext1_idx1
ON              cnvrt_ext1( cnvrt_srt_key ASC )
TABLESPACE      cnvrt_index;

PROMPT Creating index: CNVRT_EXT2_IDX1
CREATE INDEX    cnvrt_ext2_idx1
ON              cnvrt_ext2( cnvrt_srt_key ASC )
TABLESPACE      cnvrt_index;

PROMPT Creating index: CNVRT_EXT3_IDX1
CREATE INDEX    cnvrt_ext3_idx1
ON              cnvrt_ext3( cnvrt_srt_key ASC )
TABLESPACE      cnvrt_index;

