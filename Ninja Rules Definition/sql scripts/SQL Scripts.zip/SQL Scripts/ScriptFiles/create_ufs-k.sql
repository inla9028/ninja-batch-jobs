
-- Start of DDL script for UF_CHARGE_UF0100
-- Generated 14-Aug-99  1:02:15 pm
-- from wh-CNVRTD:1

-- Table UF_CHARGE_UF0100
--DROP TABLE uf_charge_uf0100
--/
CREATE TABLE uf_charge_uf0100
 (
  uf0100_record_type         VARCHAR2(4),
  uf0100_old_id              VARCHAR2(14),
  uf0100_old_root_id         VARCHAR2(14),
  uf0100_subscriber_no       VARCHAR2(20),
  uf0100_department          VARCHAR2(4),
  uf0100_conv_chg_type       VARCHAR2(1),
  uf0100_sub_market_cd       VARCHAR2(3),
  uf0100_priod_cvrg_st_date  VARCHAR2(8),
  uf0100_priod_cvrg_nd_date  VARCHAR2(8),
  uf0100_chg_creation_date   VARCHAR2(8),
  uf0100_effective_date      VARCHAR2(8),
  uf0100_due_date            VARCHAR2(8),
  uf0100_actv_code           VARCHAR2(4),
  uf0100_actv_reason_code    VARCHAR2(6),
  uf0100_actv_amt            VARCHAR2(9),
  uf0100_feature_code        VARCHAR2(6),
  uf0100_ftr_revenue_code    VARCHAR2(3),
  uf0100_balance_impact_code  VARCHAR2(1),
  uf0100_soc                 VARCHAR2(9),
  uf0100_vat_amt             VARCHAR2(9),
  uf0100_vat_percent_rate    VARCHAR2(5),
  uf0100_vat_exmp_amt        VARCHAR2(9),
  uf0100_tax_code            VARCHAR2(1),
  uf0100_credit_level        VARCHAR2(1),
  uf0100_pymnt_remain_credit  VARCHAR2(9),
  uf0100_payment_amount      VARCHAR2(9),
  uf0100_payment_date        VARCHAR2(14)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     70M
      NEXT        35M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_CHARGE_UF0100

-- Start of DDL script for UF_CUSTOMER_UF0010
-- Generated 14-Aug-99  1:03:33 pm
-- from wh-CNVRTD:1

-- Table UF_CUSTOMER_UF0010
--DROP TABLE uf_customer_uf0010
--/
CREATE TABLE uf_customer_uf0010
 (
  uf0010_record_type         VARCHAR2(4),
  uf0010_old_id              VARCHAR2(14),
  uf0010_old_root_id         VARCHAR2(14),
  uf0010_customer_telno      VARCHAR2(20),
  uf0010_customer_fax        VARCHAR2(20),
  uf0010_business_entity     VARCHAR2(3),
  uf0010_account_type        VARCHAR2(1),
  uf0010_account_sub_type    VARCHAR2(2),
  uf0010_ar_balance          VARCHAR2(9),
  uf0010_billed_account_balance  VARCHAR2(9),
  uf0010_unbilled_charges    VARCHAR2(9),
  uf0010_unbilled_payments   VARCHAR2(9),
  uf0010_billed_due          VARCHAR2(9),
  uf0010_bucket_0_30         VARCHAR2(9),
  uf0010_bucket_31_60        VARCHAR2(9),
  uf0010_bucket_61_90        VARCHAR2(9),
  uf0010_bucket_91_120       VARCHAR2(9),
  uf0010_bucket_over_120     VARCHAR2(9),
  uf0010_ban_status          VARCHAR2(1),
  uf0010_start_service_date  VARCHAR2(8),
  uf0010_default_sub_market  VARCHAR2(3),
  uf0010_default_department  VARCHAR2(4),
  uf0010_col_delinq_status   VARCHAR2(1),
  uf0010_col_delinq_sts_date  VARCHAR2(8),
  uf0010_col_waiver_ind      VARCHAR2(1),
  uf0010_col_waiver_date     VARCHAR2(8),
  uf0010_col_waiver_uid      VARCHAR2(8),
  uf0010_col_category_no     VARCHAR2(4),
  uf0010_col_path_code       VARCHAR2(3),
  uf0010_col_next_step_no    VARCHAR2(2),
  uf0010_col_next_step_date  VARCHAR2(8),
  uf0010_col_next_stp_apr_cod  VARCHAR2(1),
  uf0010_col_next_stp_apr_col  VARCHAR2(8),
  uf0010_col_assigned_coll   VARCHAR2(8),
  uf0010_col_colct_asd_date  VARCHAR2(8),
  uf0010_col_agncy_code      VARCHAR2(8),
  uf0010_col_agncy_asd_date  VARCHAR2(8),
  uf0010_col_agncy_asd_amt   VARCHAR2(9),
  uf0010_col_first_cntct_date  VARCHAR2(8),
  uf0010_col_code            VARCHAR2(1),
  uf0010_col_fixed_path      VARCHAR2(3),
  uf0010_bill_cycle          VARCHAR2(2),
  uf0010_bl_last_prod_date   VARCHAR2(8),
  uf0010_bl_vat_exempt_ind   VARCHAR2(1),
  uf0010_bl_last_cyc_run_year  VARCHAR2(4),
  uf0010_bl_last_cyc_run_mnth  VARCHAR2(2),
  uf0010_bl_prt_category     VARCHAR2(2),
  uf0010_bl_zero_balanc_ind  VARCHAR2(1),
  uf0010_bl_susp_rc_rate_type  VARCHAR2(1),
  uf0010_bl_due_day          VARCHAR2(2),
  uf0010_org_code            VARCHAR2(5),
  uf0010_cycle_frequency     VARCHAR2(2),
  uf0010_cycle_first_bill_month  VARCHAR2(2),
  uf0010_cs_com_start_date   VARCHAR2(8),
  uf0010_cs_com_end_date     VARCHAR2(8),
  uf0010_cs_handle_by_ctn_ind  VARCHAR2(1),
  uf0010_carry_over_bill     VARCHAR2(1),
  uf0010_cs_def_product_type  VARCHAR2(3),
  uf0010_sec_department      VARCHAR2(4),
  uf0010_credit_date         VARCHAR2(14),
  uf0010_hide_phone_digits_ind  VARCHAR2(1),
  uf0010_credit_class        VARCHAR2(1),
  uf0010_col_status_reason   VARCHAR2(2),
  uf0010_credit_score        VARCHAR2(9),
  uf0010_credit_limit        VARCHAR2(9),
  uf0010_credit_class_cng_tp  VARCHAR2(1),
  uf0010_credit_change_tp    VARCHAR2(1),
  uf0010_crd_lmt_col_id      VARCHAR2(9),
  uf0010_crd_lmt_date        VARCHAR2(8),
  uf0010_payment_method      VARCHAR2(2),
  uf0010_payment_sub_method  VARCHAR2(2),
  uf0010_dd_contract_no      VARCHAR2(9),
  uf0010_bank_code           VARCHAR2(10),
  uf0010_bank_branch_code    VARCHAR2(10),
  uf0010_bank_acct_no        VARCHAR2(20),
  uf0010_invoice_sec_no      VARCHAR2(12),
  uf0010_direct_debit_date   VARCHAR2(8),
  uf0010_agency_ref_no       VARCHAR2(8),
  uf0010_col_agency_conf_dt  VARCHAR2(8)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     100M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_CUSTOMER_UF0010

-- Start of DDL script for UF_FANDF_UF0150
-- Generated 14-Aug-99  1:05:31 pm
-- from wh-CNVRTD:1

-- Table UF_FANDF_UF0150
--DROP TABLE uf_fandf_uf0150
--/
CREATE TABLE uf_fandf_uf0150
 (
  uf0150_record_type         VARCHAR2(4),
  uf0150_old_id              VARCHAR2(14),
  uf0150_old_root_id         VARCHAR2(14),
  uf0150_subscriber_no       VARCHAR2(20),
  uf0150_effective_date      VARCHAR2(14),
  uf0150_personal_tel        VARCHAR2(20),
  uf0150_plan_code           VARCHAR2(9)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     70M
      NEXT        35M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_FANDF_UF0150

-- Start of DDL script for UF_INVENTORY_UF0120
-- Generated 14-Aug-99  1:06:05 pm
-- from wh-CNVRTD:1

-- Table UF_INVENTORY_UF0120
--DROP TABLE uf_inventory_uf0120
--/
CREATE TABLE uf_inventory_uf0120
 (
  uf0120_record_type         VARCHAR2(4),
  uf0120_serial_number       VARCHAR2(20),
  uf0120_item_id             VARCHAR2(15),
  uf0120_pool                VARCHAR2(2),
  uf0120_location_id         VARCHAR2(4),
  uf0120_item_ownership      VARCHAR2(1),
  uf0120_curr_possession     VARCHAR2(1),
  uf0120_puk                 VARCHAR2(8),
  uf0120_package_msisdn      VARCHAR2(20),
  uf0120_puk2                VARCHAR2(8),
  uf0120_imsi                VARCHAR2(15),
  uf0120_ki                  VARCHAR2(32),
  uf0120_first_used_date     VARCHAR2(8),
  uf0120_sim_status          VARCHAR2(1),
  uf0120_suspend_ind         VARCHAR2(1),
  uf0120_suspend_date        VARCHAR2(8),
  uf0120_initial_pin         VARCHAR2(4),
  uf0120_serial_type         VARCHAR2(1)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     200M
      NEXT        100M
      PCTINCREASE 0
   )
/


-- Table UF_LOAN_UF0190
--DROP TABLE uf_loan_uf0190
--/
CREATE TABLE uf_loan_uf0190
 (
  uf0190_record_type         VARCHAR2(4),
  uf0190_old_id              VARCHAR2(14),
  uf0190_subscriber_no       VARCHAR2(20),
  uf0190_soc                 VARCHAR2(9),
  uf0190_loan_effective_date  VARCHAR2(8),
  uf0190_full_amt            VARCHAR2(9),
  uf0190_charged_amt         VARCHAR2(9),
  uf0190_charged_fee_amt     VARCHAR2(9),
  uf0190_last_date_of_crg    VARCHAR2(8),
  uf0190_no_charged_instl    VARCHAR2(2),
  uf0190_handle_ind          VARCHAR2(1),
  uf0190_loan_expiration_date  VARCHAR2(8)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     50M
      NEXT        20M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_LOAN_UF0190

-- Start of DDL script for UF_MEMO_UF0090
-- Generated 14-Aug-99  1:06:53 pm
-- from wh-CNVRTD:1

-- Table UF_MEMO_UF0090
--DROP TABLE uf_memo_uf0090
--/
CREATE TABLE uf_memo_uf0090
 (
  uf0090_record_type         VARCHAR2(4),
  uf0090_old_id              VARCHAR2(14),
  uf0090_old_root_id         VARCHAR2(14),
  uf0090_memo_date           VARCHAR2(8),
  uf0090_memo_type           VARCHAR2(4),
  uf0090_memo_subscriber     VARCHAR2(20),
  uf0090_memo_manual_txt     VARCHAR2(2000),
  uf0090_memo_amt            VARCHAR2(9)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     50M
      NEXT        20M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_MEMO_UF0090

-- Start of DDL script for UF_NAMEADDRESS_UF0040
-- Generated 14-Aug-99  1:07:34 pm
-- from wh-CNVRTD:1

-- Table UF_NAMEADDRESS_UF0040
--DROP TABLE uf_nameaddress_uf0040
--/
CREATE TABLE uf_nameaddress_uf0040
 (
  uf0040_record_type         VARCHAR2(4),
  uf0040_old_id              VARCHAR2(14),
  uf0040_old_root_id         VARCHAR2(14),
  uf0040_subscriber_no       VARCHAR2(20),
  uf0040_adr_level           VARCHAR2(1),
  uf0040_last_business_name  VARCHAR2(60),
  uf0040_first_name          VARCHAR2(32),
  uf0040_additional_title    VARCHAR2(60),
  uf0040_name_format         VARCHAR2(1),
  uf0040_birth_date          VARCHAR2(8),
  uf0040_identify            VARCHAR2(20),
  uf0040_id_type             VARCHAR2(4),
  uf0040_comp_reg_num        VARCHAR2(20),
  uf0040_adr_type            VARCHAR2(1),
  uf0040_adr_city            VARCHAR2(39),
  uf0040_adr_zip             VARCHAR2(9),
  uf0040_adr_house_no        VARCHAR2(20),
  uf0040_adr_street_name     VARCHAR2(60),
  uf0040_adr_pob             VARCHAR2(10),
  uf0040_adr_country         VARCHAR2(3),
  uf0040_adr_house_letter    VARCHAR2(2),
  uf0040_adr_story           VARCHAR2(2),
  uf0040_adr_door_no         VARCHAR2(4),
  uf0040_adr_district        VARCHAR2(40),
  uf0040_co_ind              VARCHAR2(1),
  uf0040_link_type           VARCHAR2(1),
  uf0040_bp_media_category   VARCHAR2(2),
  uf0040_bp_bill_format      VARCHAR2(2),
  uf0040_bp_call_details_media  VARCHAR2(1),
  uf0040_bp_language         VARCHAR2(2),
  uf0040_adr_co_name         VARCHAR2(60)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     200M
      NEXT        100M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_NAMEADDRESS_UF0040

-- Start of DDL script for UF_NUMBER_UF0130
-- Generated 14-Aug-99  1:07:52 pm
-- from wh-CNVRTD:1

-- Table UF_NUMBER_UF0130
--DROP TABLE uf_number_uf0130
--/
CREATE TABLE uf_number_uf0130
 (
  uf0130_record_type         VARCHAR2(4),
  uf0130_ctn                 VARCHAR2(20),
  uf0130_last_trx_date       VARCHAR2(14),
  uf0130_last_trx_code       VARCHAR2(3),
  uf0130_ctn_status          VARCHAR2(2),
  uf0130_pni                 VARCHAR2(5),
  uf0130_nl                  VARCHAR2(3),
  uf0130_ngp                 VARCHAR2(3)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     100M
      NEXT        50M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_NUMBER_UF0130

-- Start of DDL script for UF_SOC_UF0070
-- Generated 14-Aug-99  1:08:33 pm
-- from wh-CNVRTD:1

-- Table UF_SOC_UF0070
--DROP TABLE uf_soc_uf0070
--/
CREATE TABLE uf_soc_uf0070
 (
  uf0070_record_type         VARCHAR2(4),
  uf0070_old_id              VARCHAR2(14),
  uf0070_old_root_id         VARCHAR2(14),
  uf0070_subscriber_no       VARCHAR2(20),
  uf0070_soc                 VARCHAR2(9),
  uf0070_soc_effective_date  VARCHAR2(8),
  uf0070_service_type        VARCHAR2(1),
  uf0070_expiration_date     VARCHAR2(8),
  uf0070_soc_level_code      VARCHAR2(1),
  uf0070_dealer_code         VARCHAR2(5),
  uf0070_sales_agent         VARCHAR2(5),
  uf0070_feature_code        VARCHAR2(6),
  uf0070_ftr_special_telno   VARCHAR2(20),
  uf0070_ftr_add_sw_prm      VARCHAR2(256)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     999M
      NEXT        500M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_SOC_UF0070

-- Start of DDL script for UF_SUBSCRIBER_UF0050
-- Generated 14-Aug-99  1:09:06 pm
-- from wh-CNVRTD:1

-- Table UF_SUBSCRIBER_UF0050
--DROP TABLE uf_subscriber_uf0050
--/
CREATE TABLE uf_subscriber_uf0050
 (
  uf0050_record_type         VARCHAR2(4),
  uf0050_old_id              VARCHAR2(14),
  uf0050_old_root_id         VARCHAR2(14),
  uf0050_subscriber_no       VARCHAR2(20),
  uf0050_init_activation_date  VARCHAR2(8),
  uf0050_sub_status          VARCHAR2(1),
  uf0050_sub_status_rsn_code  VARCHAR2(4),
  uf0050_sub_status_date     VARCHAR2(8),
  uf0050_commit_start_date   VARCHAR2(8),
  uf0050_commit_end_date     VARCHAR2(8),
  uf0050_susp_rc_rate_type   VARCHAR2(1),
  uf0050_dealer_code         VARCHAR2(5),
  uf0050_sales_agent         VARCHAR2(5),
  uf0050_leading_number      VARCHAR2(20),
  uf0050_pabx_ind            VARCHAR2(1),
  uf0050_sub_actv_location   VARCHAR2(4),
  uf0050_sub_market_code     VARCHAR2(3),
  uf0050_limit_reserved_days  VARCHAR2(4),
  uf0050_flex_ind            VARCHAR2(1),
  uf0050_duo_ind             VARCHAR2(1),
  uf0050_listed_ind          VARCHAR2(1),
  uf0050_sub_department_cd   VARCHAR2(4),
  uf0050_sim_1               VARCHAR2(20),
  uf0050_sim_2               VARCHAR2(20),
  uf0050_imsi_1              VARCHAR2(15),
  uf0050_imsi_2              VARCHAR2(15),
  uf0050_imei                VARCHAR2(20),
  uf0050_original_init_date  VARCHAR2(8),
  uf0050_allow_advertising_ind  VARCHAR2(1)
 )
 TABLESPACE cnvrt_data
 STORAGE   (
      INITIAL     150M
      NEXT        75M
      PCTINCREASE 0
   )
/

-- End of DDL script for UF_SUBSCRIBER_UF0050
