SELECT a.serial_number, 
	   a.item_id, 
	   a.pool,
       a.location_id, 
	   a.document_loc_id, 
	   a.document_type,
       a.document_oid, 
	   a.activity_code, 
	   a.activity_date,
       a.operation_status, 
	   a.item_ownership, 
	   a.item_ownership_dt,
       a.curr_possession, 
	   a.curr_possession_dt, 
	   a.comited_to_pos_ind,
       a.comited_date, 
       a.msn, 
	   a.puk, 
	   a.package_id, 
	   a.package_msisdn, 
	   a.puk2, 
	   a.imsi,
       a.ki, 
	   a.sim_status, 
	   a.suspend_ind,
       a.suspend_date, 
	   a.initial_pin, 
	   a.sent_to_auc_ind, 
	   a.hlr_cd,
       a.initial_pin2, a.k4id
  FROM serial_item_inv a
   WHERE a.item_ownership = 'C' 
   AND a.item_id NOT LIKE 'DUAL%'
   AND a.curr_possession = 'A' 
   AND a.comited_to_pos_ind = 'N' 
   AND a.missing_ind = 'N'
   AND a.in_transit_ind = 'N'
   AND a.location_id = 'NCLO'
   AND a.sim_status = 'R' 
   AND a.hlr_cd = '01'
   AND ROWNUM < 10
