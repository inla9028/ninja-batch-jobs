select to_char(date_stamp,'dd/mm/yyyy'),count(*)
from wrk_nmt_add
group by to_char(date_stamp,'dd/mm/yyyy')
