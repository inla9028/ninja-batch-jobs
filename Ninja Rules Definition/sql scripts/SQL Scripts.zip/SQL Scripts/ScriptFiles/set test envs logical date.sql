update ntctapp6.logical_date
set logical_date = to_date(to_char(sysdate, 'YYYYMMDD'),'YYYYMMDD');
commit;
select * from ntctapp6.logical_date;
update ntctapp8.logical_date
set logical_date = to_date(to_char(sysdate, 'YYYYMMDD'),'YYYYMMDD');
commit;
select * from ntctapp8.logical_date;
update ntctapp9.logical_date
set logical_date = to_date(to_char(sysdate, 'YYYYMMDD'),'YYYYMMDD');
commit;
select * from ntctapp9.logical_date;
update ntcrapp2.logical_date
set logical_date = to_date(to_char(sysdate, 'YYYYMMDD'),'YYYYMMDD');
commit;
select * from ntcrapp2.logical_date;
