select 'INSERT INTO KMBN_DEALER VALUES (''' || rtrim(dealer) || ''',''' || dlr_name || ''',''' || dlr_tp_cd || ''');' from dealer_profile where end_date is null
