select uf,error_no,severity,count(*),description
from cnvrt_error
group by
uf,error_no,severity,description;
