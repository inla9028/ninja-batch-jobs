CREATE TABLE mw_tmp_banUser_dets AS
SELECT a.ban,
b.control_name,
b.first_name,
b.last_business_name,
b.additional_title,
b.name_format,
c.adr_type,
c.adr_city,
c.adr_zip,
c.adr_house_no,
c.adr_street_name,
c.adr_direction,
c.adr_pob,
c.adr_country,
c.adr_house_letter,
c.adr_story,
c.adr_door_no,
c.adr_email,
c.since_date,
c.adr_district,
c.county_code,
c.co_ind,
c.adr_co_name,
c.adr_house_name
FROM mw_tmp_bnameadd a, ntcappo.name_data b, ntcappo.address_data c
WHERE a.name_id = b.name_id
AND a.address_id = c.address_id;
COMMIT WORK;
 
