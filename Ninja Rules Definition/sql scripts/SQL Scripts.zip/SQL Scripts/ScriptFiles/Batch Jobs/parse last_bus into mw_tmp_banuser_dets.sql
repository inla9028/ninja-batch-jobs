UPDATE mw_tmp_banuser_dets a
SET a.tmp_parsed_lb = rtrim(substr(a.last_business_name, 1, INSTR(a.last_business_name, ', TB') -1))
WHERE a.first_name IS NULL
AND LENGTH(rtrim(substr(a.last_business_name, 1, INSTR(a.last_business_name, ', TB') -1))) > 1;
COMMIT;

