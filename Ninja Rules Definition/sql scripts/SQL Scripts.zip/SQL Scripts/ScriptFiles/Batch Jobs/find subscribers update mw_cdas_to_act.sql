UPDATE mw_cdas_to_act a
SET (a.fokus_sub,a.fokus_ban,a.fokus_sub_status) = (SELECT RTRIM(b.subscriber_no), b.customer_id, b.sub_status
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'PBX' || a.fixed_sub
                               AND b.sub_status IN ('A','S','R'))
WHERE a.fokus_sub IS null;
COMMIT;                               
UPDATE mw_cdas_to_act a
SET (a.fokus_sub,a.fokus_ban,a.fokus_sub_status) = (SELECT RTRIM(b.subscriber_no), b.customer_id, b.sub_status
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'CDA' || a.fixed_sub
                               AND b.sub_status IN ('A','S','R'))
WHERE a.fokus_sub IS null;
COMMIT;  
UPDATE mw_cdas_to_act a
SET (a.fokus_sub,a.fokus_ban,a.fokus_sub_status) = (SELECT RTRIM(b.subscriber_no), b.customer_id, b.sub_status
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'GSM' || a.fixed_sub
                               AND b.sub_status IN ('A','S','R'))
WHERE a.fokus_sub IS null;
COMMIT;                             
