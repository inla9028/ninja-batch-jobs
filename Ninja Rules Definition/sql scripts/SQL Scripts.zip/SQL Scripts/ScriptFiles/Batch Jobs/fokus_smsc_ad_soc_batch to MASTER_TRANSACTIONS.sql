INSERT INTO master_transactions
SELECT null, a.subscriber_no, a.soc, a.action, null,
       a.timestamp, a.timestamp, null, 'WAITING',
       null, null, null, '3',
       a.request_seq_no, null, null, '1'
  FROM fokus.smsc_ad_soc_batch a
  WHERE a.processed IS null;
  COMMIT;
