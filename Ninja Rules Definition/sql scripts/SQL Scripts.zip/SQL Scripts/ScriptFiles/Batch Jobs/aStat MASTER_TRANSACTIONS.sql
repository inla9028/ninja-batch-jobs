SELECT a.process_status, COUNT(*)
  FROM master_transactions a
  GROUP BY a.process_status
