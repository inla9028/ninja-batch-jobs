SELECT a.ban, 'CDA047' || a.fixed_line, 'PBTB',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'X',b.user_first, b.user_last,NULL,
'N',NULL,c.adr_type,c.adr_city,c.adr_zip, c.adr_country, c.adr_street_name, c.adr_house_no, c.adr_house_letter, c.adr_story, 
c.adr_door_no, c.adr_pob, c.adr_district, c.adr_email, c.adr_co_name,'GSC 23.01.2006'
  FROM mw_tmp_cda_gsm a, mw_tmp_buser_names b, mw_tmp_bnameaddress c
  WHERE a.cda_to_act = 'Y'
  ORDER BY a.ban, a.fixed_line
  
