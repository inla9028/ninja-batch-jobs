SELECT a.ban, 'CDA' || a.ctn, 'PBTB',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y',b.tmp_first, b.tmp_last,NULL,
'N',NULL,b.adr_type,b.adr_city,b.adr_zip, b.adr_country, b.adr_street_name, b.adr_house_no, b.adr_house_letter, b.adr_story, 
b.adr_door_no, b.adr_pob, b.adr_district, b.adr_email, b.adr_co_name,'GSC 27.01.2006'
  FROM mw_tmp_cdas_for_prod a, mw_tmp_banuser_dets b
  WHERE a.ban = b.ban
  AND a.ban_type = 'BKG'
  ORDER BY a.ban,a.ctn
