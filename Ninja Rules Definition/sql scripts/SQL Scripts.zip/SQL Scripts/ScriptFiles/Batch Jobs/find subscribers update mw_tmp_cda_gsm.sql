UPDATE mw_tmp_cda_gsm a
SET a.associated_subscriber = (SELECT RTRIM(b.subscriber_no)
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'PBX' || a.fixed_line
                               AND b.sub_status IN ('A','S','R'))
WHERE a.associated_subscriber IS null;
COMMIT;                               
UPDATE mw_tmp_cda_gsm a
SET a.associated_subscriber = (SELECT RTRIM(b.subscriber_no)
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'CDA' || a.fixed_line
                               AND b.sub_status IN ('A','S','R'))
WHERE a.associated_subscriber IS null;
COMMIT;  
UPDATE mw_tmp_cda_gsm a
SET a.associated_subscriber = (SELECT RTRIM(b.subscriber_no)
                               FROM ntcappo.subscriber b
                               WHERE b.subscriber_no = 'GSM' || a.fixed_line
                               AND b.sub_status IN ('A','S','R'))
WHERE a.associated_subscriber IS null;
COMMIT;                             
