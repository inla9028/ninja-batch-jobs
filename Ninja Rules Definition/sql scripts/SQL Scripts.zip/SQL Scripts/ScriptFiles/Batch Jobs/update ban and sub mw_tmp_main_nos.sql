UPDATE mw_tmp_main_nos a
SET (a.fokus_sub, a.fokus_ban) = (SELECT rtrim(b.subscriber_no), b.customer_id
                                  FROM ntcappo.subscriber b
                                  WHERE b.subscriber_no = 'PBX' || a.fixed_line_main_no
                                  AND b.sub_status IN ('A','R','S'))
WHERE a.fokus_sub IS null;
COMMIT;                                  
UPDATE mw_tmp_main_nos a
SET (a.fokus_sub, a.fokus_ban) = (SELECT rtrim(b.subscriber_no), b.customer_id
                                  FROM ntcappo.subscriber b
                                  WHERE b.subscriber_no = 'CDA' || a.fixed_line_main_no
                                  AND b.sub_status IN ('A','R','S'))
WHERE a.fokus_sub IS null;
COMMIT;                                  
                                  
UPDATE mw_tmp_main_nos a
SET (a.fokus_sub, a.fokus_ban) = (SELECT rtrim(b.subscriber_no), b.customer_id
                                  FROM ntcappo.subscriber b
                                  WHERE b.subscriber_no = 'GSM' || a.fixed_line_main_no
                                  AND b.sub_status IN ('A','R','S'))
WHERE a.fokus_sub IS null;
COMMIT;                                  
                                  
                                  

