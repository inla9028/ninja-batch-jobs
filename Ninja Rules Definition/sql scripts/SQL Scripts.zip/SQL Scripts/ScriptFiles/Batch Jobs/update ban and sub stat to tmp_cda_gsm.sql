UPDATE mw_tmp_cda_gsm a
SET (a.ban,a.sub_status) = (SELECT b.customer_id, b.sub_status
             FROM ntcappo.subscriber b
             WHERE b.subscriber_no = a.associated_subscriber
             AND b.sub_status IN ('A','R','S'))
WHERE a.associated_subscriber IS NOT NULL;
COMMIT;
