CREATE TABLE mw_tmp_ban_user as
SELECT a.ban, rtrim(substr(a.last_business_name, 1, INSTR(a.last_business_name, ', TB') -1)) AS user_first
FROM mw_tmp_bnameaddress a
WHERE a.first_name IS NULL
AND LENGTH(rtrim(substr(a.last_business_name, 1, INSTR(a.last_business_name, ', TB') -1))) > 1
