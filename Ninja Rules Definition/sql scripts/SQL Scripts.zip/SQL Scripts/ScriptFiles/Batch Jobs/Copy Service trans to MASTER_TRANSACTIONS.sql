INSERT INTO master_transactions (trans_number, 
       subscriber_no, 
       soc, 
       action_code, 
       new_soc,
       enter_time, 
       request_time, 
       process_time, 
       process_status,
       status_desc, 
       dealer_code, 
       sales_agent, 
       priority,
       request_id, 
       memo_text, 
       waive_act_fee, 
       stream)
SELECT null, 
       a.subscriber_no, 
       a.soc, 
       a.action_code,
       NULL,
       a.enter_time, 
       a.request_time, 
       a.process_time, 
       a.process_status,
       a.status_desc, 
       a.dealer_code, 
       a.sales_agent, 
       a.priority,
       'SMSCADSOC_L1',
       NULL,
       NULL,
       SUBSTR(a.subscriber_no,14)+1
  FROM service_transactions a
  WHERE a.process_status = 'WAITING'
  AND a.trans_number < 263412
  ORDER BY a.subscriber_no,a.enter_time;
  COMMIT;
  UPDATE service_transactions 
  SET process_status = 'REC_TRANS'
  WHERE process_status = 'WAITING'
    AND trans_number < 263412;
  COMMIT WORK;
