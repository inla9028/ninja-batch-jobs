
UPDATE mw_tmp_banuser_dets a
SET a.tmp_first = rtrim(SUBSTR(a.tmp_parsed_lb, 1, INSTR(a.tmp_parsed_lb, ' ')));
COMMIT;

UPDATE mw_tmp_banuser_dets a
SET a.tmp_last = trim(SUBSTR(a.tmp_parsed_lb, LENGTH(a.tmp_first)+1));
COMMIT;


