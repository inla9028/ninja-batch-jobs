UPDATE mw_tmp_bnameadd a
SET (a.name_id, a.address_id) = (SELECT b.name_id, b.address_id
                                 FROM ntcappo.address_name_link b
                                 WHERE b.ban = a.ban
                                 AND b.link_type = 'L'
                                 AND b.link_seq_no = (SELECT MAX(c.link_seq_no)
                                                      FROM ntcappo.address_name_link c
                                                      WHERE c.ban = a.ban
                                                      AND c.link_type = 'L') 
                                                      );
COMMIT;                                                      

