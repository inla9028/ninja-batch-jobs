-- Start of DDL Script for Table NINJADEVDATA.CDA_BATCH_ACTIVATIONS
-- Generated 18.01.2006 12:18:03 from NINJADEVDATA@NINJA.WSRV1.NETCOM-GSM.NO
DROP SEQUENCE cda_activation_trans_seq1
/
CREATE SEQUENCE cda_activation_trans_seq1
  INCREMENT BY 1
  START WITH 1
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

DROP TABLE cda_batch_activations
/
CREATE TABLE cda_batch_activations
    (transaction_no                 NUMBER(9,0) NOT NULL,
    ban                            NUMBER(9,0) NOT NULL,
    subscriber_no                  VARCHAR2(14) NOT NULL,
    price_plan                     VARCHAR2(9) NOT NULL,
    tb_cug_code                    VARCHAR2(9),
    vpn_code                       VARCHAR2(5),
    cug_code                       VARCHAR2(5),
    adt_soc_1                      VARCHAR2(9),
    adt_soc_2                      VARCHAR2(9),
    adt_soc_3                      VARCHAR2(9),
    adt_soc_4                      VARCHAR2(9),
    dealer_code                    VARCHAR2(5),
    sales_agent                    VARCHAR2(5),
    publish_level                  VARCHAR2(1),
    user_first                     VARCHAR2(32),
    surname                        VARCHAR2(60),
    bill_info                      VARCHAR2(60),
    role_ind                       VARCHAR2(1),
    birth_date                     VARCHAR2(8),
    adr_type                       VARCHAR2(1),
    city                           VARCHAR2(39),
    zip_code                       VARCHAR2(9),
    country                        VARCHAR2(3),
    street_name                    VARCHAR2(60),
    house_no                       VARCHAR2(20),
    house_letter                   VARCHAR2(2),
    floor                          VARCHAR2(2),
    door_no                        VARCHAR2(4),
    p_o_box                        VARCHAR2(10),
    area_pob_name                  VARCHAR2(40),
    email                          VARCHAR2(150),
    co_name                        VARCHAR2(60),
    requestor_id                   VARCHAR2(30),
    process_time                   DATE,
    process_status                 VARCHAR2(25),
    status_desc                    VARCHAR2(2000))
/

-- Triggers for CDA_BATCH_ACTIVATIONS

CREATE OR REPLACE TRIGGER cda_batch_acts_trg1
 BEFORE
  INSERT
 ON cda_batch_activations
REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
BEGIN
	IF INSERTING
	THEN
	    -- Ensure that the unique id is updated correctly
		SELECT	CDA_ACTIVATION_TRANS_SEQ1.NEXTVAL	
		INTO	:new.transaction_no
		FROM	dual;	
        
        IF :new.dealer_code IS NULL THEN
        	:new.dealer_code := 'NET';
        END IF;
        
        IF :new.sales_agent IS NULL THEN
        	:new.sales_agent := 'A';
        END IF;
        
        IF :new.country IS NULL THEN
        	:new.country := 'NOR';
        END IF;
        
        IF :new.role_ind IS NULL THEN
        	:new.role_ind := 'N';
        END IF;
        
        IF :new.publish_level IS NULL THEN 
        	:new.publish_level := 'Y';
        END IF;
        
        
        -- If status of record is null, default it to 'WAITING'
        IF :new.process_status IS NULL THEN
            :new.process_status := 'WAITING';
        END IF;
        
        

    END IF;
END;
/


-- Comments for CDA_BATCH_ACTIVATIONS

COMMENT ON COLUMN cda_batch_activations.adr_type IS 'Defaulted to ''R''egualar,  ''P'' = Post Box'
/
COMMENT ON COLUMN cda_batch_activations.adt_soc_1 IS 'Additional Fokus Soc Code'
/
COMMENT ON COLUMN cda_batch_activations.adt_soc_2 IS 'Additional Fokus Soc Code'
/
COMMENT ON COLUMN cda_batch_activations.adt_soc_3 IS 'Additional Fokus Soc Code'
/
COMMENT ON COLUMN cda_batch_activations.adt_soc_4 IS 'Additional Fokus Soc Code'
/
COMMENT ON COLUMN cda_batch_activations.ban IS 'Fokus Billing Account number'
/
COMMENT ON COLUMN cda_batch_activations.bill_info IS 'Additional Text.'
/
COMMENT ON COLUMN cda_batch_activations.country IS 'Defaulted to ''NOR'', otherwise use a valid International Country Code.'
/
COMMENT ON COLUMN cda_batch_activations.cug_code IS 'CUG PNI Code if applicable'
/
COMMENT ON COLUMN cda_batch_activations.dealer_code IS 'Dealer Code - Defaulted to ''NET'''
/
COMMENT ON COLUMN cda_batch_activations.price_plan IS 'Fokus Priceplan Code'
/
COMMENT ON COLUMN cda_batch_activations.process_status IS 'Ninja Usage'
/
COMMENT ON COLUMN cda_batch_activations.process_time IS 'Ninja Usage'
/
COMMENT ON COLUMN cda_batch_activations.publish_level IS 'Publish Level - Defaulted to ''Y'' - Ingen Oppf�ring. (''X'' - Complete Oppf�ring.)'
/
COMMENT ON COLUMN cda_batch_activations.requestor_id IS 'Batch Requestor - Fomrat of XXX DD.MM.YYYY - Where XXX users initials Uppercase..'
/
COMMENT ON COLUMN cda_batch_activations.role_ind IS '''Y'' if this name/address should be a Role'
/
COMMENT ON COLUMN cda_batch_activations.sales_agent IS 'Sales Agent - Defaulted to ''A'''
/
COMMENT ON COLUMN cda_batch_activations.status_desc IS 'Ninja Usage'
/
COMMENT ON COLUMN cda_batch_activations.subscriber_no IS 'Subscriber Number - number prefixed with LOC Type (i.e. CDA04722222222)'
/
COMMENT ON COLUMN cda_batch_activations.surname IS 'Users Surname or in case of ROLE_IND = ''Y'', then free text describing the Role (Only field in a Role type name/address'
/
COMMENT ON COLUMN cda_batch_activations.tb_cug_code IS 'CUG/VPN Soc Code if any'
/
COMMENT ON COLUMN cda_batch_activations.transaction_no IS 'Unique Transaction Number (auto generated)'
/
COMMENT ON COLUMN cda_batch_activations.user_first IS 'Users First Name'
/
COMMENT ON COLUMN cda_batch_activations.vpn_code IS 'VPN PNI  Code if applicable'
/

-- End of DDL Script for Table NINJADEVDATA.CDA_BATCH_ACTIVATIONS

