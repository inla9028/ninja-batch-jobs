insert into ninja_acct_pp
select * from ninja.ninja_acct_pp;
commit;
insert into ninja_pp_prods
select * from ninja.ninja_pp_prods;
commit;
insert into ninja_prod_desc
select * from ninja.ninja_prod_desc;
commit;
