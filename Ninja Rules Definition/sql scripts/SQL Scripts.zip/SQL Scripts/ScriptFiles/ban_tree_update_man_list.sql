update tmp_man_list
set ban_count = (select count(*) from ban_hierarchy_tree@prod.world where tree_root_ban = man);
commit work;
