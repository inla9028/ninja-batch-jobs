
-- Start of DDL script for DATAFIELD
-- Generated 16-jun-00  9:29:17 am
-- from whouse-INTERF:1

-- Drop the old instance of DATAFIELD

DROP TABLE datafield
/

-- Table DATAFIELD

CREATE TABLE datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for DATAFIELD

CREATE  UNIQUE INDEX datafield_name_pk
 ON datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for DATAFIELD

ALTER TABLE datafield
 ADD CONSTRAINT datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
/

ALTER TABLE datafield
 ADD CONSTRAINT datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES dataset(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for DATAFIELD

-- Start of DDL script for DATAFIELD_NAME_PK
-- Generated 16-jun-00  9:29:21 am
-- from whouse-INTERF:1

-- Drop the old instance of DATAFIELD_NAME_PK

DROP INDEX datafield_name_pk
/

-- Index DATAFIELD_NAME_PK

CREATE  UNIQUE INDEX datafield_name_pk
 ON datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for DATAFIELD_NAME_PK

-- Start of DDL script for DATAFIELD_VALUE
-- Generated 16-jun-00  9:29:21 am
-- from whouse-INTERF:1

-- Drop the old instance of DATAFIELD_VALUE

DROP TABLE datafield_value
/

-- Table DATAFIELD_VALUE

CREATE TABLE datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0) DEFAULT -1,
  datafield_ismandatory      NUMBER(*,0) DEFAULT -1,
  datafield_occurrance       NUMBER(*,0) DEFAULT 0 NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        98304
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for DATAFIELD_VALUE

CREATE  UNIQUE INDEX datafield_value_pk
 ON datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        98304
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for DATAFIELD_VALUE

ALTER TABLE datafield_value
 ADD CONSTRAINT datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
/

ALTER TABLE datafield_value
 ADD CONSTRAINT datafieldv_ds_fk FOREIGN KEY (dataset_name,datafield_name)
      REFERENCES datafield(dataset_name,datafield_name) ON DELETE CASCADE
/

ALTER TABLE datafield_value
 ADD CONSTRAINT user_name_fk FOREIGN KEY (username)
      REFERENCES user(username) ON DELETE CASCADE
/


-- End of DDL script for DATAFIELD_VALUE

-- Start of DDL script for DATAFIELD_VALUE_PK
-- Generated 16-jun-00  9:29:25 am
-- from whouse-INTERF:1

-- Drop the old instance of DATAFIELD_VALUE_PK

DROP INDEX datafield_value_pk
/

-- Index DATAFIELD_VALUE_PK

CREATE  UNIQUE INDEX datafield_value_pk
 ON datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        98304
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for DATAFIELD_VALUE_PK

-- Start of DDL script for DATASET
-- Generated 16-jun-00  9:29:25 am
-- from whouse-INTERF:1

-- Drop the old instance of DATASET

DROP TABLE dataset
/

-- Table DATASET

CREATE TABLE dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1),
  dataset_comment            VARCHAR2(80)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        65536
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for DATASET

CREATE  UNIQUE INDEX dataset_name_pk
 ON dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for DATASET

ALTER TABLE dataset
 ADD CONSTRAINT dataset_name_pk PRIMARY KEY (dataset_name)
/


-- End of DDL script for DATASET

-- Start of DDL script for DATASETS
-- Generated 16-jun-00  9:29:26 am
-- from whouse-INTERF:1

-- Drop the old instance of DATASETS

DROP VIEW datasets
/

-- View DATASETS

CREATE OR REPLACE VIEW datasets (
   dataset_name,
   datafield_name,
   datafield_type,
   username,
   datafield_occurrance,
   datafield_value,
   datafield_ismandatory,
   datafield_islocked,
   in_use )
AS
SELECT dset.dataset_name,
       dfield.datafield_name,
       datafield_type,
       usr.username,
       datafield_occurrance,
       datafield_value,
       datafield_ismandatory,
       datafield_islocked,
       dfield.in_use
FROM   dataset dset,
       datafield dfield,
       datafield_value dfieldv,
       user usr
WHERE  dset.in_use = 1
AND    dfield.in_use = 1
AND    dset.dataset_name = dfield.dataset_name
AND    dfield.dataset_name = dfieldv.dataset_name
AND    dfield.datafield_name = dfieldv.datafield_name
AND    dfieldv.username = usr.username
/

-- End of DDL script for DATASETS

-- Start of DDL script for DATASET_NAME_PK
-- Generated 16-jun-00  9:29:27 am
-- from whouse-INTERF:1

-- Drop the old instance of DATASET_NAME_PK

DROP INDEX dataset_name_pk
/

-- Index DATASET_NAME_PK

CREATE  UNIQUE INDEX dataset_name_pk
 ON dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for DATASET_NAME_PK

-- Start of DDL script for INTERFACE
-- Generated 16-jun-00  9:29:27 am
-- from whouse-INTERF:1

-- Drop the old instance of INTERFACE

DROP PACKAGE interface
/

-- Package INTERFACE

CREATE OR REPLACE
Package INTERFACE
  IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, initial revision.
-- SAH         000406  Added set_dataset and set_datafield

  -- Create a cursortype for the datasets view
  TYPE dataset_list IS REF CURSOR RETURN datasets%ROWTYPE;

  -- Get
  FUNCTION get_datasets
    ( datasetname IN DATASET.DATASET_NAME%type ,
      username IN USER.USERNAME%type )
    RETURN dataset_list;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN DATASET.DATASET_NAME%type ,
      servicename IN DATASET.SERVICE_NAME%type ,
      datasettype IN DATASET.DATASET_TYPE%type )
    RETURN INTEGER;

  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN DATAFIELD.DATASET_NAME%type ,
      servicename IN DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER;

END; -- Package Specification INTERFACE
/

-- End of DDL script for INTERFACE

-- Start of DDL script for INTERFACE
-- Generated 16-jun-00  9:29:27 am
-- from whouse-INTERF:1

-- Drop the old instance of INTERFACE

DROP PACKAGE BODY interface
/

-- Package body INTERFACE

CREATE OR REPLACE
Package Body INTERFACE
IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, Initial revision

  FUNCTION get_datasets
    ( datasetname IN DATASET.DATASET_NAME%type ,
      username IN USER.USERNAME%TYPE )
    RETURN dataset_list
    AS
  BEGIN
    DECLARE dataset_list_c dataset_list;
    BEGIN
      OPEN dataset_list_c FOR
        SELECT * FROM datasets
        WHERE datasets.username = username
        AND datasets.dataset_name = datasetname
        ORDER BY dataset_name, datafield_name;
      RETURN dataset_list_c;
    END;
  END get_datasets;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN DATASET.DATASET_NAME%type ,
      servicename IN DATASET.SERVICE_NAME%type ,
      datasettype IN DATASET.DATASET_TYPE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_dataset;


  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN DATAFIELD.DATASET_NAME%type ,
      servicename IN DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_datafield;

END; -- Package Body INTERFACE
/

-- End of DDL script for INTERFACE

-- Start of DDL script for MIDAS
-- Generated 16-jun-00  9:29:28 am
-- from whouse-INTERF:1

-- Drop the old instance of MIDAS

DROP PACKAGE midas
/

-- Package MIDAS

CREATE OR REPLACE
Package MIDAS
  IS

  FUNCTION add_charge_record
     ( p_phone_no       IN VARCHAR2,
       p_charge_date    IN VARCHAR2,
       p_charge_code    IN VARCHAR2,
       p_charge_desc    IN VARCHAR2,
       p_charge_amt     IN INTEGER,
       p_memo_text      IN VARCHAR2)
     RETURN  INTEGER;

END; -- Package Specification MIDAS
/

-- End of DDL script for MIDAS

-- Start of DDL script for MIDAS
-- Generated 16-jun-00  9:29:29 am
-- from whouse-INTERF:1

-- Drop the old instance of MIDAS

DROP PACKAGE BODY midas
/

-- Package body MIDAS

CREATE OR REPLACE
Package Body MIDAS
IS
   FUNCTION add_charge_record
    ( p_phone_no       IN VARCHAR2,
       p_charge_date    IN VARCHAR2,
       p_charge_code    IN VARCHAR2,
       p_charge_desc    IN VARCHAR2,
       p_charge_amt     IN INTEGER,
       p_memo_text      IN VARCHAR2)
       RETURN INTEGER
    IS
        v_charge_date   DATE;
        v_charge_amt    NUMBER;
   BEGIN
        v_charge_date := TO_DATE(p_charge_date, 'YYYYMMDD');
        v_charge_amt := (p_charge_amt / 100);

        INSERT INTO MIDAS_QUEUE
                (PHONE_NO,
                 CHARGE_DATE,
                 CHARGE_CODE,
                 CHARGE_DESC,
                 CHARGE_AMT,
                 PROC_STATUS,
                 PROC_DATE,
                 MEMO_TEXT)
        VALUES (p_phone_no,
                v_charge_date,
                p_charge_code,
                p_charge_desc,
                v_charge_amt,
                null,
                null,
                p_memo_text);
                COMMIT;
        RETURN 0;
   EXCEPTION
      WHEN OTHERS THEN
          RETURN 1;
   END;

   -- Enter further code below as specified in the Package spec.
END; -- Package Body MIDAS
/

-- End of DDL script for MIDAS

-- Start of DDL script for TELENOR
-- Generated 16-jun-00  9:29:29 am
-- from whouse-INTERF:1

-- Drop the old instance of TELENOR

DROP PACKAGE telenor
/

-- Package TELENOR

CREATE OR REPLACE
Package TELENOR
  IS
  FUNCTION add_charge_record
     ( p_referans_nr    IN VARCHAR2,
       p_charge_text    IN VARCHAR2)
     RETURN  INTEGER;

END;
/

-- End of DDL script for TELENOR

-- Start of DDL script for TELENOR
-- Generated 16-jun-00  9:29:30 am
-- from whouse-INTERF:1

-- Drop the old instance of TELENOR

DROP PACKAGE BODY telenor
/

-- Package body TELENOR

CREATE OR REPLACE
Package Body TELENOR
IS
--
   FUNCTION add_charge_record
      (p_referans_nr    IN VARCHAR2,
       p_charge_text    IN VARCHAR2)
       RETURN INTEGER
    IS

    CURSOR cur_sel_exist ( p_ref_nr IN VARCHAR2 )
    IS
        SELECT  *
        FROM    TNOR_TRANS
        WHERE   REFERASN_NR = p_ref_nr;

        v_tnor_rec  cur_sel_exist%ROWTYPE;

   BEGIN
       OPEN     cur_sel_exist ( p_referans_nr );
       FETCH    cur_sel_exist INTO v_tnor_rec;
       IF cur_sel_exist%NOTFOUND
       THEN
            INSERT INTO TNOR_TRANS
                (REFERASN_NR,
                 RECORD_TEXT)
            VALUES (p_referans_nr,
                    p_charge_text);
            COMMIT;
            CLOSE cur_sel_exist;
            RETURN 0;
       ELSE
            CLOSE cur_sel_exist;
            RETURN 1;
       END IF;
   EXCEPTION
      WHEN OTHERS THEN
          RETURN 1;
   END;

   -- Enter further code below as specified in the Package spec.
END; -- Package Body MIDAS
/

-- End of DDL script for TELENOR

-- Start of DDL script for TNOR_TRANS
-- Generated 16-jun-00  9:29:30 am
-- from whouse-INTERF:1

-- Drop the old instance of TNOR_TRANS

DROP TABLE tnor_trans
/

-- Table TNOR_TRANS

CREATE TABLE tnor_trans
 (
  referasn_nr                VARCHAR2(25),
  record_text                VARCHAR2(255)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        147456
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for TNOR_TRANS

COMMENT ON TABLE tnor_trans IS 'Transaction list of applied telenor charges'
/

-- Indexes for TNOR_TRANS

CREATE  INDEX ntt_idx1
 ON tnor_trans
  ( referasn_nr  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for TNOR_TRANS

-- Start of DDL script for USER
-- Generated 16-jun-00  9:29:35 am
-- from whouse-INTERF:1

-- Drop the old instance of USER

DROP TABLE user
/

-- Table USER

CREATE TABLE user
 (
  username                   VARCHAR2(32) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for USER

COMMENT ON TABLE user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for USER

CREATE  UNIQUE INDEX sys_c0056039
 ON user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for USER

ALTER TABLE user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for USER
