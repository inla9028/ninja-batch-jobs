select  friends_and_family.subscriber_no,friends_and_family.personal_tel,
        friends_and_family.plan_code,service_agreement.soc
from    friends_and_family,service_agreement
where   (friends_and_family.expiration_date is null OR
         friends_and_family.expiration_date > sysdate)
and     friends_and_family.subscriber_no = service_agreement.subscriber_no
and     service_agreement.service_type = 'P'
and     (service_agreement.expiration_date is null OR
         service_agreement.expiration_date > sysdate)
