SELECT a.begin_line_range, a.end_line_range, a.ngp, a.range_type
  FROM tn_grouping a, msisdn_hlr_relation b
  where b.phy_hlr = '47'
  and a.begin_line_range between b.msisdn_begin_range and b.msisdn_end_range
  and a.end_line_range between b.msisdn_begin_range and b.msisdn_end_range
