update serial_item_inv
set activity_code = 'VNRC', item_ownership = 'C', CURR_POSSESSION = 'A', comited_to_pos_ind = 'N'
where serial_number in ('08947080073000001929');
commit work;



SELECT * FROM serial_item_inv WHERE serial_number = ('08947080073000001929')
