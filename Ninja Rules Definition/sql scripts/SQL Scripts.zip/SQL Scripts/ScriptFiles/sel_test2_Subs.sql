select subscriber.subscriber_no,subscriber.sub_status,
        service_agreement.soc,billing_account.ban,billing_account.account_type,
        billing_account.account_sub_type
from subscriber,service_agreement,billing_account
where subscriber.subscriber_no = service_agreement.subscriber_no and
    subscriber.customer_id = service_agreement.ban and
    service_agreement.service_type = 'P' and
    billing_account.ban = service_agreement.ban
