
-- Start of DDL script for MW_TMP_MMS_SMS
-- Generated 27-jun-03  9:57:44 am
-- from cp01-MDCUST:8

-- Trigger MW_TMP_MMS_SMS

CREATE OR REPLACE TRIGGER mw_tmp_mms_sms
BEFORE INSERT
ON service_agreement
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
    v_exist NUMBER;
BEGIN
    IF SUBSTR(:new.soc,1,3) LIKE 'MMS0%'
    THEN
        SELECT COUNT(SUB_CTN)
        INTO v_exist
        FROM MW_TMP_MMS_SUBS
        WHERE SUB_CTN = :new.SUBSCRIBER_NO;
        IF v_exist = 0
        THEN
            INSERT
            INTO MW_TMP_MMS_SUBS VALUES (:new.SUBSCRIBER_NO);

          IF :new.OPERATOR_ID != '200912'
          THEN
            INSERT
            INTO SMSSEND.SMS_SEND@KONTANT.WORLD
            (SMS_MSISDN,
             SMS_TEXT,
             SMS_CREATED,
             SMS_PRIORITY)
            VALUES
             ('1989',
              'MMSREG SU NOKIA 7650 ' || substr(:new.SUBSCRIBER_NO, 7),
              sysdate,
              '1');
          END IF;
          COMMIT;
        END IF;
    END IF;
EXCEPTION WHEN OTHERS THEN
	  NULL;
END;
/

-- End of DDL script for MW_TMP_MMS_SMS
