
-- Start of DDL script for IMD_IDX1
-- Generated 9-Sep-99  5:38:44 am
-- from wh-CNVRTB:1

-- Index IMD_IDX1

CREATE  INDEX imd_idx1
 ON imsi_dups
  ( imsi_1  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE cnvrt_index
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for IMD_IDX1

-- Start of DDL script for IMD_IDX2
-- Generated 9-Sep-99  5:38:44 am
-- from wh-CNVRTB:1

-- Index IMD_IDX2

CREATE  INDEX imd_idx2
 ON imsi_dups
  ( imsi_2  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE cnvrt_index
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for IMD_IDX2

-- Start of DDL script for IMD_IDX3
-- Generated 9-Sep-99  5:38:44 am
-- from wh-CNVRTB:1

-- Index IMD_IDX3

CREATE  INDEX imd_idx3
 ON imsi_dups
  ( phone  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE cnvrt_index
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for IMD_IDX3
