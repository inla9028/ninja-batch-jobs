select c_cnv_ar_bal - (c_cnv_billed_due + c_cnv_bal_0_30 + c_cnv_bal_31_60 +
c_cnv_bal_61_90 + c_cnv_bal_91_120 + c_cnv_bal_121_999)
 from cvfined1
where c_cnv_ar_bal !=
(c_cnv_billed_due + c_cnv_bal_0_30 + c_cnv_bal_31_60 +
c_cnv_bal_61_90 + c_cnv_bal_91_120 + c_cnv_bal_121_999)
