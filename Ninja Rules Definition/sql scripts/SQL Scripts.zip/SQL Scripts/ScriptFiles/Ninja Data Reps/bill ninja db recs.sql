INSERT INTO ban_tree_member_removal (ban,request_id) SELECT ban,'INIT BATCH' FROM mw_tmp_can_bans@NINJAPROD;
COMMIT WORK;
