create table mw_tmp_can_bans as SELECT a.tree_root_ban, a.ban, a.effective_date, a.sys_creation_date,
       a.sys_update_date, a.operator_id, a.application_id,
       a.dl_service_code, a.dl_update_stamp, a.tree_level, a.parent_ban,
       a.expiration_date, b.ban_status
  FROM ntcappo.ban_hierarchy_tree a, ntcappo.billing_account b
  WHERE a.ban = b.customer_id
  AND a.expiration_date IS null
  AND b.ban_status IN ('C','N')
