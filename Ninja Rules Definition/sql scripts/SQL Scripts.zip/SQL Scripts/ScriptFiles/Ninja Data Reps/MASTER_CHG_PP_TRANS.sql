SELECT a.process_status, COUNT(*)
  FROM ninjadata.master_chg_pp_trans a
  GROUP BY a.process_status
