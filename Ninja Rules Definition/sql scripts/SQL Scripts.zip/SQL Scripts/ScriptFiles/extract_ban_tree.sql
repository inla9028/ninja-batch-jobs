SELECT 
       bht.tree_root_ban,
       bht.parent_ban,
       anl.ban,
       bht.tree_level,
       ban.account_type,
       ban.account_sub_type,
       ban.ban_status,
       nm.last_business_name,
       nm.first_name,
       ad.adr_pob,
       ad.adr_street_name,
       ad.adr_zip,
       ad.adr_city,
       to_char(bht.effective_date, 'YYYYMMDD'),
       to_char(bht.expiration_date, 'YYYYMMDD')
FROM ban_hierarchy_tree bht,
     billing_account ban,
     address_name_link anl,
     address_data ad,
     name_data nm
WHERE bht.tree_root_ban = 742754203
AND   bht.effective_date > to_date('19000101','YYYYMMDD')  -- force use of an index....
AND   bht.ban = ban.customer_id
AND   bht.ban = anl.customer_id
AND   anl.link_type = 'L'
AND   nvl(anl.expiration_date, to_date('30001231','YYYYMMDD')) > sysdate
AND   nm.name_id = anl.name_id
AND   ad.address_id = anl.address_id
