
-- Start of DDL script for NP_TIME_PORT
-- Generated 25-okt-01  4:57:42 pm
-- from ninjaProd-NINJATEST:2

-- Table NP_TIME_PORT

CREATE TABLE np_time_port
 (
  np_ref                     NUMBER NOT NULL,
  np_nrdb_ref_id             VARCHAR2(20) NOT NULL,
  np_user                    VARCHAR2(16) NOT NULL,
  np_ctn                     VARCHAR2(11) NOT NULL,
  np_original_donor_code     VARCHAR2(10) NOT NULL,
  np_donor_code              VARCHAR2(10) NOT NULL,
  np_recipient_code          VARCHAR2(10) NOT NULL,
  np_date_time_created       VARCHAR2(14) NOT NULL,
  np_date_time_modified      VARCHAR2(14) NOT NULL,
  np_date_time_port          VARCHAR2(14) NOT NULL,
  np_description             VARCHAR2(60),
  np_action                  VARCHAR2(4) NOT NULL,
  np_status                  VARCHAR2(4) NOT NULL,
  np_ids_blob                BLOB DEFAULT empty_blob()
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     16384
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Constraints for NP_TIME_PORT

ALTER TABLE np_time_port
 ADD CHECK ("NP_REF" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_NRDB_REF_ID" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_USER" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_CTN" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_ORIGINAL_DONOR_CODE" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_DONOR_CODE" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_RECIPIENT_CODE" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_DATE_TIME_CREATED" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_DATE_TIME_MODIFIED" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_DATE_TIME_PORT" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_ACTION" IS NOT NULL)
/

ALTER TABLE np_time_port
 ADD CHECK ("NP_STATUS" IS NOT NULL)
/


-- End of DDL script for NP_TIME_PORT
