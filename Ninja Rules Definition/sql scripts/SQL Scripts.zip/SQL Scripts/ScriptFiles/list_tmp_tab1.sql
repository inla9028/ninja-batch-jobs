INSERT INTO MW_TMP_PP
(select 'R', rtrim(act_type), rtrim(act_sub_type), rtrim(campaign), rtrim(pp), rtrim(ads)
from interf.mw_tmp_tab1@wh01
group by act_type, act_sub_type, campaign, pp, ads)
commit;
