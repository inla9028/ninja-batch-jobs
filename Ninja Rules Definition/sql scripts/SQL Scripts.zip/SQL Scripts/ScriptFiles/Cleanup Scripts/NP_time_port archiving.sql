INSERT INTO arch_np_time_port
SELECT a.ninja_ref_id, a.nrdb_ref_id, a.user_id, a.ctn,
       a.number_owner_code, a.donor_code, a.recipient_code,
       a.date_time_created, a.date_time_modified, a.date_time_port,
       a.description, a.action, a.proc_attempts, a.status
FROM np_time_port a 
WHERE a.status <> 'WAITING';
COMMIT;
DELETE FROM np_time_port a
WHERE a.status <> 'WAITING';
COMMIT;      
