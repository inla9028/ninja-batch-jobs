insert into ninja_datafield_value
            (dataset_name,
            datafield_name,
            username,
            datafield_value,
            datafield_islocked,
            datafield_ismandatory,
            datafield_occurrance)
select  dataset_name,
        datafield_name,
        'MAING1',
        datafield_value,
        datafield_islocked,
        datafield_ismandatory,
        datafield_occurrance
from ninja_datafield_value
where username = 'TestUser1';
--and dataset_name in ('CsLsSrvAgr_in_DSet', 'CsLsSrvFtr_in_DSet');

commit;
