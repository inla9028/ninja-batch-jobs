insert into reason_severity 
select rtrim(csa_activity_code),rtrim(csa_activity_rsn_code),'N',null,null from csm_status_activity@prod.world
where not exists
    (select ' '
     from reason_severity
     where rtrim(csa_activity_code) = status_avt_code
     and rtrim(csa_activity_rsn_code) = status_avt_rsn_code)
