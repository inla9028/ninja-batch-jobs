SELECT method_name, COUNT(*) "Count", round(MAX(used_time)/1000,2) "Max", round(MIN(used_time)/1000,2) "Min", round(AVG(used_time)/1000,2) "Average"
FROM BRAWE.NINJA_RESPONSETIME_LOG
WHERE to_char(TIMESTAMP, 'DDMMYYYY') = '06022003' -- > to_date('09072002','ddmmyyyy')
--AND TIMESTAMP < to_date('05042002','ddmmyyyy')
GROUP BY method_name

