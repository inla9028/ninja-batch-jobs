select 'insert into ninja_datafield values (''' || dataset_name || ''',''ACTION'',''CHAR'',1,null,1);'  from ninja_datafield
where dataset_name like 'Cv%_in_DSet' group by dataset_name
