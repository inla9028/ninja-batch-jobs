update master_chg_pp_trans
set process_status = 'WAITING'
where process_status = 'IN_PROGRESS';
commit;
