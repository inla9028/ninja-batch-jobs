
-- Start of DDL script for NINJA_INTERFACE
-- Generated 15-mai-00  5:22:12 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_INTERFACE

DROP PACKAGE BODY interf.ninja_interface
/

-- Package body NINJA_INTERFACE

CREATE OR REPLACE
Package Body INTERF.NINJA_INTERFACE
IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, Initial revision

  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%TYPE )
    RETURN dataset_list
    AS
  BEGIN
    DECLARE dataset_list_c dataset_list;
    BEGIN
      OPEN dataset_list_c FOR
        SELECT * FROM ninja_datasets
        WHERE ninja_datasets.username = username
        AND ninja_datasets.dataset_name = datasetname
        ORDER BY dataset_name, datafield_name;
      RETURN dataset_list_c;
    END;
  END get_datasets;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_dataset;


  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_datafield;

END; -- Package Body NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE
