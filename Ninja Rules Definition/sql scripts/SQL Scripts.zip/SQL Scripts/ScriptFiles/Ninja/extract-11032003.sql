
-- Start of DDL script for ARCH_NP_TIME_PORT
-- Generated 11-mar-03  10:53:40 am
-- from ernst-NINJA:6

-- Table ARCH_NP_TIME_PORT

CREATE TABLE arch_np_time_port
 (
  np_ref                     NUMBER(8) NOT NULL,
  np_nrdb_ref_id             VARCHAR2(20) NOT NULL,
  np_user                    VARCHAR2(16) NOT NULL,
  np_ctn                     VARCHAR2(11) NOT NULL,
  np_original_donor_code     VARCHAR2(10) NOT NULL,
  np_donor_code              VARCHAR2(10) NOT NULL,
  np_recipient_code          VARCHAR2(10) NOT NULL,
  np_date_time_created       VARCHAR2(14) NOT NULL,
  np_date_time_modified      VARCHAR2(14) NOT NULL,
  np_date_time_port          VARCHAR2(14) NOT NULL,
  np_description             VARCHAR2(150),
  np_action                  VARCHAR2(4) NOT NULL,
  np_status                  VARCHAR2(4) NOT NULL,
  np_ids_blob                BLOB DEFAULT empty_blob(),
  np_retries                 NUMBER(*,0) DEFAULT 0 NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     209715200
      NEXT        104857600
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Column Comments for ARCH_NP_TIME_PORT

COMMENT ON COLUMN arch_np_time_port.np_action IS 'Ninja Action to Perform when Retrieving the Request.'
/
COMMENT ON COLUMN arch_np_time_port.np_ctn IS 'Main CTN for the Porting Request.'
/
COMMENT ON COLUMN arch_np_time_port.np_date_time_created IS 'Date/Time YYYYMMDDHHMMSS of the entry into the Table.'
/
COMMENT ON COLUMN arch_np_time_port.np_date_time_modified IS 'Date/Time YYYYMMDDHHMMSS of the last update of the Request.'
/
COMMENT ON COLUMN arch_np_time_port.np_date_time_port IS 'Date/Time YYYYMMDDHHMMSS the Port should take place.'
/
COMMENT ON COLUMN arch_np_time_port.np_description IS 'Description of the Result of the Latest Processing.'
/
COMMENT ON COLUMN arch_np_time_port.np_donor_code IS 'NRDB Current Donor holding the CTN.'
/
COMMENT ON COLUMN arch_np_time_port.np_ids_blob IS 'BLOB containing the NPactionIDS containing all the required details for Processing by Ninja.'
/
COMMENT ON COLUMN arch_np_time_port.np_nrdb_ref_id IS 'NRDB Reference ID.'
/
COMMENT ON COLUMN arch_np_time_port.np_original_donor_code IS 'NRDB Original Donor Code of the CTN.'
/
COMMENT ON COLUMN arch_np_time_port.np_recipient_code IS 'NRDB Donor Code for the Requester of the CTN.'
/
COMMENT ON COLUMN arch_np_time_port.np_ref IS 'Unique key. Automatically generated upon insert.'
/
COMMENT ON COLUMN arch_np_time_port.np_retries IS 'Number of times the transaction has been attempted.'
/
COMMENT ON COLUMN arch_np_time_port.np_status IS 'Status of the Request.'
/
COMMENT ON COLUMN arch_np_time_port.np_user IS 'User Entering the Request.'
/

-- Constraints for ARCH_NP_TIME_PORT

ALTER TABLE arch_np_time_port
 ADD PRIMARY KEY (np_ref)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     52428800
   NEXT        26214400
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/


-- End of DDL script for ARCH_NP_TIME_PORT

-- Start of DDL script for BANSTATUS
-- Generated 11-mar-03  10:53:40 am
-- from ernst-NINJA:6

-- Table BANSTATUS

CREATE TABLE banstatus
 (
  status_avt_code            VARCHAR2(20) NOT NULL,
  status_avt_rsn_code        VARCHAR2(20) NOT NULL,
  neg                        VARCHAR2(10) NOT NULL,
  csa                        VARCHAR2(20),
  description                VARCHAR2(50)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for BANSTATUS

-- Start of DDL script for BAN_ACCT_TYPE_CHANGE
-- Generated 11-mar-03  10:53:41 am
-- from ernst-NINJA:6

-- Table BAN_ACCT_TYPE_CHANGE

CREATE TABLE ban_acct_type_change
 (
  trans_number               NUMBER(9) NOT NULL,
  ban                        NUMBER(9) NOT NULL,
  account_type               VARCHAR2(1) NOT NULL,
  account_sub_type           VARCHAR2(2) NOT NULL,
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(300),
  priority                   NUMBER(1) NOT NULL,
  request_id                 VARCHAR2(15)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for BAN_ACCT_TYPE_CHANGE

COMMENT ON TABLE ban_acct_type_change IS 'Ban Account Type/Sub Type Change Requests'
/

-- Column Comments for BAN_ACCT_TYPE_CHANGE

COMMENT ON COLUMN ban_acct_type_change.account_sub_type IS 'New Account Sub Type'
/
COMMENT ON COLUMN ban_acct_type_change.account_type IS 'New Account Type'
/
COMMENT ON COLUMN ban_acct_type_change.ban IS 'Ban Number'
/
COMMENT ON COLUMN ban_acct_type_change.enter_time IS 'Time when row was inserted into this table. Automatically generated value'
/
COMMENT ON COLUMN ban_acct_type_change.priority IS 'Transaction priority. Value from 1 to 5 where 1 is highest priority.'
/
COMMENT ON COLUMN ban_acct_type_change.process_status IS 'Process status. Valid values: WAITING, IN_PROGRESS, PRSD_SUCCESS, PRSD_ERROR and PRSD_FATAL'
/
COMMENT ON COLUMN ban_acct_type_change.process_time IS 'Time when service request was processed'
/
COMMENT ON COLUMN ban_acct_type_change.request_id IS 'Requestor Specified ID code for retrieval from Webrep..'
/
COMMENT ON COLUMN ban_acct_type_change.request_time IS 'Time when transaction must be processed. Defaults to value in NETER_TIME column'
/
COMMENT ON COLUMN ban_acct_type_change.status_desc IS 'Error message'
/
COMMENT ON COLUMN ban_acct_type_change.trans_number IS 'Unique transaction number.'
/

-- Indexes for BAN_ACCT_TYPE_CHANGE

CREATE  INDEX ban_acct_type_change_idx1
 ON ban_acct_type_change
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        1720320
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for BAN_ACCT_TYPE_CHANGE

ALTER TABLE ban_acct_type_change
 ADD CONSTRAINT ban_acct_type_change_pk1 PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        335872
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE ban_acct_type_change
  ADD CONSTRAINT ban_acct_type_change_con2 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR', 'PRSD_FATAL'))
/

ALTER TABLE ban_acct_type_change
  ADD CONSTRAINT ban_acct_type_change_con3 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for BAN_ACCT_TYPE_CHANGE

CREATE OR REPLACE TRIGGER ban_acct_type_change_trg1
BEFORE INSERT
ON ban_acct_type_change
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_success_count     NUMBER DEFAULT 0;
  v_error_count       NUMBER DEFAULT 0;

 BEGIN
  IF INSERTING
  THEN
            -- Set enter time. And if request time is not set, then set it to enter time
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

  END IF;
 END;
/

-- End of DDL script for BAN_ACCT_TYPE_CHANGE

-- Start of DDL script for BBS_FILES
-- Generated 11-mar-03  10:53:41 am
-- from ernst-NINJA:6

-- Table BBS_FILES

CREATE TABLE bbs_files
 (
  file_id                    NUMBER(6) NOT NULL,
  status                     VARCHAR2(15) NOT NULL,
  status_date                DATE,
  status_desc                VARCHAR2(100),
  filename                   VARCHAR2(100) NOT NULL,
  response_filename          VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     2129920
      NEXT        1048576
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BBS_FILES

COMMENT ON TABLE bbs_files IS 'Holds information about all BBS eFaktura request files which have been processed.'
/

-- Column Comments for BBS_FILES

COMMENT ON COLUMN bbs_files.filename IS 'Name of file (excloding path).'
/
COMMENT ON COLUMN bbs_files.file_id IS 'Unique file ID. Must be explicitely obtained from sequence FILE_ID_SEQ before insert.'
/
COMMENT ON COLUMN bbs_files.response_filename IS 'Name of response file generated for this BBS file (excluding path).'
/
COMMENT ON COLUMN bbs_files.status IS 'File status. Valid values: ''IN_PROGRESS'', ''PROCESSED'' and ''ERROR'''
/
COMMENT ON COLUMN bbs_files.status_date IS 'Time when the current status was set. Automatically set when STATUS column is updated.'
/

-- Indexes for BBS_FILES

CREATE  INDEX bbs_files_idx1
 ON bbs_files
  ( filename  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_files_idx2
 ON bbs_files
  ( status  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_files_idx3
 ON bbs_files
  ( response_filename  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BBS_FILES

ALTER TABLE bbs_files
 ADD PRIMARY KEY (file_id)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE bbs_files
  ADD CONSTRAINT bbs_files_con100 CHECK (status IN ('IN_PROGRESS', 'PROCESSED', 'ERROR'))
/


-- Triggers for BBS_FILES

CREATE OR REPLACE TRIGGER bbs_files_trg1
BEFORE INSERT  OR UPDATE
ON bbs_files
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		IF INSERTING OR :new.status!=:old.status
		THEN
			SELECT	sysdate
			INTO	:new.status_date
			FROM	dual;
		END IF;
	END;
/

-- End of DDL script for BBS_FILES

-- Start of DDL script for BBS_RECORDS
-- Generated 11-mar-03  10:53:42 am
-- from ernst-NINJA:6

-- Table BBS_RECORDS

CREATE TABLE bbs_records
 (
  request_id                 NUMBER(9) NOT NULL,
  file_id                    NUMBER(6) NOT NULL,
  request_type               VARCHAR2(15) NOT NULL,
  enrollment_status          VARCHAR2(1) NOT NULL,
  biller_account_no          VARCHAR2(200) NOT NULL,
  thor_user_id               VARCHAR2(30) NOT NULL,
  process_status             VARCHAR2(15) NOT NULL,
  process_status_desc        VARCHAR2(100),
  request_status             VARCHAR2(15),
  was_closed_by              NUMBER(9),
  has_closed                 NUMBER(9),
  dup_request_id             NUMBER(9),
  thor_user_key              VARCHAR2(2048)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     52428800
      NEXT        26214400
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BBS_RECORDS

COMMENT ON TABLE bbs_records IS 'Holds request information contained in the BBS files.'
/

-- Column Comments for BBS_RECORDS

COMMENT ON COLUMN bbs_records.biller_account_no IS 'BAN involved in request.'
/
COMMENT ON COLUMN bbs_records.dup_request_id IS 'Request ID of previous request which matches this request.'
/
COMMENT ON COLUMN bbs_records.enrollment_status IS 'Together with the request_type, this columns determines the nature of the request. Valid values: ''A'', ''D'', ''N'' and ''P''.'
/
COMMENT ON COLUMN bbs_records.file_id IS 'Foreign key column from table BBS_FILES.'
/
COMMENT ON COLUMN bbs_records.has_closed IS 'ID of request which which this request closed.'
/
COMMENT ON COLUMN bbs_records.process_status IS 'Request processing status. Valid values: ''WAITING'', ''SUCCESS'',''ERROR'' AND ''DUPLICATE''.'
/
COMMENT ON COLUMN bbs_records.process_status_desc IS 'Free text describing the processing status.'
/
COMMENT ON COLUMN bbs_records.request_id IS 'Unique ID identifying the reqquest. Automatically generated upon insert.'
/
COMMENT ON COLUMN bbs_records.request_status IS 'Request status. Valid values: ''PENDING_ADD'', ''PENDING_CHG'', ''PENDING_ERR'' and ''CLOSED''.'
/
COMMENT ON COLUMN bbs_records.request_type IS 'Request type. Valid values ''ADD'', ''CHANGE'' and ''DELETE''.'
/
COMMENT ON COLUMN bbs_records.thor_user_id IS 'Unique customer ID supplied by BBS.'
/
COMMENT ON COLUMN bbs_records.thor_user_key IS 'Customer signature supplied by BBS.'
/
COMMENT ON COLUMN bbs_records.was_closed_by IS 'ID of request which closed this transaction.'
/

-- Indexes for BBS_RECORDS

CREATE  INDEX bbs_records_idx1
 ON bbs_records
  ( request_type,
    enrollment_status,
    biller_account_no,
    thor_user_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     655360
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx2
 ON bbs_records
  ( thor_user_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     475136
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx3
 ON bbs_records
  ( biller_account_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     278528
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx4
 ON bbs_records
  ( request_id,
    biller_account_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     229376
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx5
 ON bbs_records
  ( was_closed_by  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     65536
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx6
 ON bbs_records
  ( has_closed  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     98304
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_records_idx7
 ON bbs_records
  ( file_id,
    request_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     180224
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BBS_RECORDS

ALTER TABLE bbs_records
 ADD PRIMARY KEY (request_id)
/

ALTER TABLE bbs_records
 ADD CONSTRAINT bbs_records_con1 FOREIGN KEY (file_id)
      REFERENCES BBS_FILES(file_id)
/

ALTER TABLE bbs_records
  ADD CONSTRAINT bbs_records_con100 CHECK (request_type IN ('ADD', 'CHANGE', 'DELETE'))
/

ALTER TABLE bbs_records
  ADD CONSTRAINT bbs_records_con101 CHECK (enrollment_status IN ('A', 'D', 'N', 'P'))
/

ALTER TABLE bbs_records
  ADD CONSTRAINT bbs_records_con102 CHECK (request_status IN ('PENDING_ADD', 'PENDING_CHG', 'PENDING_ERR', 'CLOSED'))
/

ALTER TABLE bbs_records
  ADD CONSTRAINT bbs_records_con103 CHECK (process_status IN ('WAITING', 'SUCCESS', 'DUPLICATE', 'ERROR'))
/


-- Triggers for BBS_RECORDS

CREATE OR REPLACE TRIGGER bbs_records_trg1
BEFORE INSERT
ON bbs_records
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	request_id_seq.NEXTVAL
		INTO	:new.request_id
		FROM	dual;
	END;
/

-- End of DDL script for BBS_RECORDS

-- Start of DDL script for BBS_STATUS
-- Generated 11-mar-03  10:53:43 am
-- from ernst-NINJA:6

-- Table BBS_STATUS

CREATE TABLE bbs_status
 (
  ban                        NUMBER(9) NOT NULL,
  status                     VARCHAR2(1),
  status_date                DATE,
  thor_user_id               VARCHAR2(40)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for BBS_STATUS

CREATE  UNIQUE INDEX sys_c001073
 ON bbs_status
  ( ban  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     147456
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BBS_STATUS

ALTER TABLE bbs_status
 ADD PRIMARY KEY (ban)
/


-- Triggers for BBS_STATUS

CREATE OR REPLACE TRIGGER bbs_status_trg1
BEFORE INSERT
ON bbs_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
 INSERT
 INTO bbs_status_history
  (action_time,
  action,
  ban,
  status,
  status_date)
 VALUES (sysdate,
  'I',
  :new.ban,
  :new.status,
  :new.status_date);
END;
/

CREATE OR REPLACE TRIGGER bbs_status_trg2
BEFORE UPDATE
ON bbs_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
 INSERT
 INTO bbs_status_history
  (action_time,
  action,
  ban,
  status,
  status_date)
 VALUES (sysdate,
  'U',
  :new.ban,
  :new.status,
  :new.status_date);
END;
/

CREATE OR REPLACE TRIGGER bbs_status_trg3
BEFORE  DELETE
ON bbs_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
 INSERT
 INTO bbs_status_history
  (action_time,
  action,
  ban,
  status,
  status_date)
 VALUES (sysdate,
  'D',
  :old.ban,
  :old.status,
  :old.status_date);
END;
/

-- End of DDL script for BBS_STATUS

-- Start of DDL script for BBS_STATUS_HISTORY
-- Generated 11-mar-03  10:53:44 am
-- from ernst-NINJA:6

-- Table BBS_STATUS_HISTORY

CREATE TABLE bbs_status_history
 (
  action_time                DATE,
  action                     VARCHAR2(1),
  ban                        NUMBER(9),
  status                     VARCHAR2(1),
  status_date                DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     770048
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for BBS_STATUS_HISTORY

CREATE  INDEX bbs_status_history_idx1
 ON bbs_status_history
  ( ban,
    action_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     851968
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bbs_status_history_idx2
 ON bbs_status_history
  ( action_time,
    ban  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     638976
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for BBS_STATUS_HISTORY

-- Start of DDL script for BBS_STATUS_TMP
-- Generated 11-mar-03  10:53:44 am
-- from ernst-NINJA:6

-- Table BBS_STATUS_TMP

CREATE TABLE bbs_status_tmp
 (
  ban                        NUMBER(9) NOT NULL,
  status                     VARCHAR2(1),
  status_date                DATE,
  thor_user_id               VARCHAR2(40)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- End of DDL script for BBS_STATUS_TMP

-- Start of DDL script for BILLING_AGREEMENT_TYPES
-- Generated 11-mar-03  10:53:45 am
-- from ernst-NINJA:6

-- Table BILLING_AGREEMENT_TYPES

CREATE TABLE billing_agreement_types
 (
  agreement_type             VARCHAR2(15) NOT NULL,
  account_type               VARCHAR2(1) NOT NULL,
  account_sub_type           VARCHAR2(2) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     5242880
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BILLING_AGREEMENT_TYPES

COMMENT ON TABLE billing_agreement_types IS 'Holds all valid billing agreement types'
/

-- Column Comments for BILLING_AGREEMENT_TYPES

COMMENT ON COLUMN billing_agreement_types.account_sub_type IS 'Account sub type'
/
COMMENT ON COLUMN billing_agreement_types.account_type IS 'Account type'
/
COMMENT ON COLUMN billing_agreement_types.agreement_type IS 'Agreement type'
/

-- Indexes for BILLING_AGREEMENT_TYPES

CREATE  INDEX billing_agreement_types_idx1
 ON billing_agreement_types
  ( agreement_type,
    account_type,
    account_sub_type  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     5242880
   NEXT        5242880
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX billing_agreement_types_idx2
 ON billing_agreement_types
  ( account_type,
    account_sub_type  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BILLING_AGREEMENT_TYPES

ALTER TABLE billing_agreement_types
 ADD PRIMARY KEY (agreement_type,account_type,account_sub_type)
/


-- End of DDL script for BILLING_AGREEMENT_TYPES

-- Start of DDL script for BILL_AGR_TYPES_SUB_TYPES
-- Generated 11-mar-03  10:53:45 am
-- from ernst-NINJA:6

-- Table BILL_AGR_TYPES_SUB_TYPES

CREATE TABLE bill_agr_types_sub_types
 (
  bill_agr_types_sub_id      NUMBER(6) NOT NULL,
  org_agreement_type         VARCHAR2(15) NOT NULL,
  new_agreement_type         VARCHAR2(15) NOT NULL,
  org_account_type           VARCHAR2(1) NOT NULL,
  new_account_type           VARCHAR2(1) NOT NULL,
  org_account_sub_type       VARCHAR2(2) NOT NULL,
  new_account_sub_type       VARCHAR2(2) NOT NULL,
  org_priceplan              VARCHAR2(9) NOT NULL,
  new_priceplan              VARCHAR2(9) NOT NULL,
  org_campaign_id            VARCHAR2(9) NOT NULL,
  new_campaign_id            VARCHAR2(9) NOT NULL,
  commitment_months          NUMBER(2) NOT NULL,
  remaining_com_months       NUMBER(2) NOT NULL,
  subscription_type_id       VARCHAR2(15) NOT NULL,
  effective_date             DATE NOT NULL,
  expiration_date            DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     31457280
      NEXT        20971520
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BILL_AGR_TYPES_SUB_TYPES

COMMENT ON TABLE bill_agr_types_sub_types IS 'Holds relations between the billing agreement types and subscription types'
/

-- Column Comments for BILL_AGR_TYPES_SUB_TYPES

COMMENT ON COLUMN bill_agr_types_sub_types.bill_agr_types_sub_id IS 'Artificial primary key. Automatically generated by insertion.'
/
COMMENT ON COLUMN bill_agr_types_sub_types.commitment_months IS 'Number of commitment months for new priceplan'
/
COMMENT ON COLUMN bill_agr_types_sub_types.effective_date IS 'First day when the relation is active'
/
COMMENT ON COLUMN bill_agr_types_sub_types.expiration_date IS 'Last day when the relation is active'
/
COMMENT ON COLUMN bill_agr_types_sub_types.new_account_sub_type IS 'New account sub type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.new_account_type IS 'New account type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.new_agreement_type IS 'New agreement type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.new_campaign_id IS 'Campaign ID for new priceplan/commitment months'
/
COMMENT ON COLUMN bill_agr_types_sub_types.new_priceplan IS 'New priceplan to be added to subscription'
/
COMMENT ON COLUMN bill_agr_types_sub_types.org_account_sub_type IS 'Original account sub type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.org_account_type IS 'Origainal account type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.org_agreement_type IS 'Original agreement type'
/
COMMENT ON COLUMN bill_agr_types_sub_types.org_campaign_id IS 'Campaign ID for original priceplan/commitment months'
/
COMMENT ON COLUMN bill_agr_types_sub_types.org_priceplan IS 'Priceplan already on subsciption'
/
COMMENT ON COLUMN bill_agr_types_sub_types.remaining_com_months IS 'Remaining number of commitment months on original priceplan'
/
COMMENT ON COLUMN bill_agr_types_sub_types.subscription_type_id IS 'Foreign key column from SUBSCRIPTION_TYPES'
/

-- Indexes for BILL_AGR_TYPES_SUB_TYPES

CREATE  UNIQUE INDEX bill_agr_types_sub_types_idx2
 ON bill_agr_types_sub_types
  ( org_agreement_type,
    new_agreement_type,
    org_account_type,
    new_account_type,
    org_account_sub_type,
    new_account_sub_type,
    org_priceplan,
    new_priceplan,
    org_campaign_id,
    new_campaign_id,
    commitment_months,
    remaining_com_months  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     20971520
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  UNIQUE INDEX bill_agr_types_sub_types_idx3
 ON bill_agr_types_sub_types
  ( org_agreement_type,
    new_agreement_type,
    org_account_type,
    new_account_type,
    org_account_sub_type,
    new_account_sub_type,
    org_priceplan,
    org_campaign_id,
    remaining_com_months,
    commitment_months,
    new_campaign_id,
    new_priceplan  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     20971520
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BILL_AGR_TYPES_SUB_TYPES

ALTER TABLE bill_agr_types_sub_types
 ADD PRIMARY KEY (bill_agr_types_sub_id)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     20971520
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE bill_agr_types_sub_types
 ADD CONSTRAINT bill_agr_types_sub_types_con1 FOREIGN KEY (org_agreement_type,
 org_account_type,org_account_sub_type)
      REFERENCES BILLING_AGREEMENT_TYPES(agreement_type,account_type,account_sub_type)
/

ALTER TABLE bill_agr_types_sub_types
 ADD CONSTRAINT bill_agr_types_sub_types_con2 FOREIGN KEY (new_agreement_type,
 new_account_type,new_account_sub_type)
      REFERENCES BILLING_AGREEMENT_TYPES(agreement_type,account_type,account_sub_type)
/

ALTER TABLE bill_agr_types_sub_types
 ADD CONSTRAINT bill_agr_types_sub_types_con3 FOREIGN KEY (subscription_type_id)
      REFERENCES SUBSCRIPTION_TYPES(subscription_type_id)
/

ALTER TABLE bill_agr_types_sub_types
 ADD CONSTRAINT bill_agr_types_sub_types_con4 FOREIGN KEY (org_priceplan)
      REFERENCES PRICEPLANS(priceplan_code)
/

ALTER TABLE bill_agr_types_sub_types
 ADD CONSTRAINT bill_agr_types_sub_types_con5 FOREIGN KEY (new_priceplan)
      REFERENCES PRICEPLANS(priceplan_code)
/


-- Triggers for BILL_AGR_TYPES_SUB_TYPES

CREATE OR REPLACE TRIGGER bill_agr_types_sub_types_trg1
BEFORE INSERT  OR UPDATE
ON bill_agr_types_sub_types
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		IF INSERTING
		THEN
			SELECT	bill_agr_types_sub_id_seq.nextval
			INTO	:new.bill_agr_types_sub_id
			FROM	dual;
		END IF;

		IF :new.effective_date IS NOT NULL
		THEN
			:new.effective_date := TRUNC(:new.effective_date);
		END IF;

		IF :new.expiration_date IS NOT NULL
		THEN
			:new.expiration_date := TRUNC(:new.expiration_date);
		END IF;
	END;
/

-- End of DDL script for BILL_AGR_TYPES_SUB_TYPES

-- Start of DDL script for BILL_AGR_TYPES_SUB_TYPES_DESC
-- Generated 11-mar-03  10:53:46 am
-- from ernst-NINJA:6

-- Table BILL_AGR_TYPES_SUB_TYPES_DESC

CREATE TABLE bill_agr_types_sub_types_desc
 (
  bill_agr_name_id           NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BILL_AGR_TYPES_SUB_TYPES_DESC

COMMENT ON TABLE bill_agr_types_sub_types_desc IS 'Holds descriptions of relations between the billing agreement types and subscription types'
/

-- Column Comments for BILL_AGR_TYPES_SUB_TYPES_DESC

COMMENT ON COLUMN bill_agr_types_sub_types_desc.bill_agr_name_id IS 'Unique description ID'
/
COMMENT ON COLUMN bill_agr_types_sub_types_desc.description IS 'Description text'
/
COMMENT ON COLUMN bill_agr_types_sub_types_desc.language_code IS 'Foreign key column from LANGUAGES'
/

-- Indexes for BILL_AGR_TYPES_SUB_TYPES_DESC

CREATE  INDEX bill_agr_desc_idx1
 ON bill_agr_types_sub_types_desc
  ( bill_agr_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     5242880
   NEXT        5242880
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BILL_AGR_TYPES_SUB_TYPES_DESC

ALTER TABLE bill_agr_types_sub_types_desc
 ADD PRIMARY KEY (bill_agr_name_id,language_code)
/

ALTER TABLE bill_agr_types_sub_types_desc
 ADD CONSTRAINT bill_agr_desc_con1 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- Triggers for BILL_AGR_TYPES_SUB_TYPES_DESC

CREATE OR REPLACE TRIGGER bill_agr_desc_trg1
BEFORE INSERT
ON bill_agr_types_sub_types_desc
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	bill_agr_name_id_seq.nextval
		INTO	:new.bill_agr_name_id
		FROM	dual;
	END;
/

-- End of DDL script for BILL_AGR_TYPES_SUB_TYPES_DESC

-- Start of DDL script for BILL_AGR_TYPES_SUB_TYPES_SP
-- Generated 11-mar-03  10:53:47 am
-- from ernst-NINJA:6

-- Table BILL_AGR_TYPES_SUB_TYPES_SP

CREATE TABLE bill_agr_types_sub_types_sp
 (
  bill_agr_types_sub_id      NUMBER(6) NOT NULL,
  service_provider_code      VARCHAR2(15) NOT NULL,
  effective_date             DATE NOT NULL,
  expiration_date            DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BILL_AGR_TYPES_SUB_TYPES_SP

COMMENT ON TABLE bill_agr_types_sub_types_sp IS 'Holds the subscription types available for each service provider'
/

-- Column Comments for BILL_AGR_TYPES_SUB_TYPES_SP

COMMENT ON COLUMN bill_agr_types_sub_types_sp.bill_agr_types_sub_id IS 'Foreign key column from BILL_AGR_TYPES_SUB_TYPES'
/
COMMENT ON COLUMN bill_agr_types_sub_types_sp.effective_date IS 'First day when relation is active'
/
COMMENT ON COLUMN bill_agr_types_sub_types_sp.expiration_date IS 'Last day when relation is active'
/
COMMENT ON COLUMN bill_agr_types_sub_types_sp.service_provider_code IS 'Foreign key column from SERVICE_PROVIDERS'
/

-- Indexes for BILL_AGR_TYPES_SUB_TYPES_SP

CREATE  INDEX bill_agr_types_sp_idx1
 ON bill_agr_types_sub_types_sp
  ( bill_agr_types_sub_id,
    service_provider_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX bill_agr_types_sp_idx2
 ON bill_agr_types_sub_types_sp
  ( service_provider_code,
    bill_agr_types_sub_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BILL_AGR_TYPES_SUB_TYPES_SP

ALTER TABLE bill_agr_types_sub_types_sp
 ADD PRIMARY KEY (bill_agr_types_sub_id,service_provider_code)
/


-- Triggers for BILL_AGR_TYPES_SUB_TYPES_SP

CREATE OR REPLACE TRIGGER bill_agr_types_sub_typ_sp_trg1
BEFORE INSERT  OR UPDATE
ON bill_agr_types_sub_types_sp
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN

		IF :new.effective_date IS NOT NULL
		THEN
			:new.effective_date := TRUNC(:new.effective_date);
		END IF;

		IF :new.expiration_date IS NOT NULL
		THEN
			:new.expiration_date := TRUNC(:new.expiration_date);
		END IF;
	END;
/

-- End of DDL script for BILL_AGR_TYPES_SUB_TYPES_SP

-- Start of DDL script for BILL_AGR_TYP_SUB_X_DESC
-- Generated 11-mar-03  10:53:48 am
-- from ernst-NINJA:6

-- Table BILL_AGR_TYP_SUB_X_DESC

CREATE TABLE bill_agr_typ_sub_x_desc
 (
  bill_agr_types_sub_id      NUMBER(6) NOT NULL,
  bill_agr_name_id           NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        20971520
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BILL_AGR_TYP_SUB_X_DESC

COMMENT ON TABLE bill_agr_typ_sub_x_desc IS 'Holds links to descriptions of relations between the billing agreement types and subscription types'
/

-- Column Comments for BILL_AGR_TYP_SUB_X_DESC

COMMENT ON COLUMN bill_agr_typ_sub_x_desc.bill_agr_name_id IS 'Foreign key column from BILL_AGR_TYPES_SUB_TYPES_DESC'
/
COMMENT ON COLUMN bill_agr_typ_sub_x_desc.bill_agr_types_sub_id IS 'Foreign key column from BILL_AGR_TYPES_SUB_TYPES'
/
COMMENT ON COLUMN bill_agr_typ_sub_x_desc.language_code IS 'Foreign key column from BILL_AGR_TYPES_SUB_TYPES_DESC'
/

-- Indexes for BILL_AGR_TYP_SUB_X_DESC

CREATE  INDEX bill_agr_typ_sub_x_desc_idx1
 ON bill_agr_typ_sub_x_desc
  ( bill_agr_types_sub_id,
    bill_agr_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     15728640
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for BILL_AGR_TYP_SUB_X_DESC

ALTER TABLE bill_agr_typ_sub_x_desc
 ADD PRIMARY KEY (bill_agr_types_sub_id,bill_agr_name_id,language_code)
/

ALTER TABLE bill_agr_typ_sub_x_desc
 ADD CONSTRAINT bill_agr_typ_sub_x_desc_con2 FOREIGN KEY (bill_agr_name_id,language_code)
      REFERENCES BILL_AGR_TYPES_SUB_TYPES_DESC(bill_agr_name_id,language_code)
/


-- End of DDL script for BILL_AGR_TYP_SUB_X_DESC

-- Start of DDL script for BRAWE_AGREEMENT_MANS
-- Generated 11-mar-03  10:53:48 am
-- from ernst-NINJA:6

-- Table BRAWE_AGREEMENT_MANS

CREATE TABLE brawe_agreement_mans
 (
  root_ban                   NUMBER(9) NOT NULL,
  agreement_code             VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     16384
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Column Comments for BRAWE_AGREEMENT_MANS

COMMENT ON COLUMN brawe_agreement_mans.agreement_code IS 'Contains the Agreement Type Code..'
/
COMMENT ON COLUMN brawe_agreement_mans.root_ban IS 'Contains the Root Ban for an Agreement within BRAWE.'
/

-- Indexes for BRAWE_AGREEMENT_MANS

CREATE  UNIQUE INDEX bman_agr_idx1
 ON brawe_agreement_mans
  ( root_ban  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     16384
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for BRAWE_AGREEMENT_MANS

-- Start of DDL script for BRAWE_BAN_TREES
-- Generated 11-mar-03  10:53:48 am
-- from ernst-NINJA:6

-- Table BRAWE_BAN_TREES

CREATE TABLE brawe_ban_trees
 (
  tree_root_ban              NUMBER(9),
  parent_ban                 NUMBER(9) DEFAULT 0,
  ban                        NUMBER(9),
  tree_level                 NUMBER(3),
  account_type               VARCHAR2(1),
  account_sub_type           VARCHAR2(2),
  ban_status                 VARCHAR2(1),
  compname1                  VARCHAR2(61),
  compname2                  VARCHAR2(61),
  adr_pob                    VARCHAR2(10),
  adr_street_name            VARCHAR2(60),
  adr_zip                    VARCHAR2(9),
  adr_city                   VARCHAR2(39),
  effective_date             DATE,
  expiration_date            DATE,
  control_name               VARCHAR2(120)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BRAWE_BAN_TREES

COMMENT ON TABLE brawe_ban_trees IS 'Contains the Ban Tree Information for BRAWE'
/

-- Indexes for BRAWE_BAN_TREES

CREATE  INDEX bbt_idx1
 ON brawe_ban_trees
  ( tree_root_ban  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     999424
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for BRAWE_BAN_TREES

-- Start of DDL script for BRAWE_MAN_LIST
-- Generated 11-mar-03  10:53:49 am
-- from ernst-NINJA:6

-- Table BRAWE_MAN_LIST

CREATE TABLE brawe_man_list
 (
  man                        NUMBER(9),
  ban_count                  NUMBER(6)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BRAWE_MAN_LIST

COMMENT ON TABLE brawe_man_list IS 'MAN List Used by Brawe'
/

-- End of DDL script for BRAWE_MAN_LIST

-- Start of DDL script for BRAWE_PERF_PROBS_MANS
-- Generated 11-mar-03  10:53:49 am
-- from ernst-NINJA:6

-- Table BRAWE_PERF_PROBS_MANS

CREATE TABLE brawe_perf_probs_mans
 (
  man_ban                    NUMBER(9)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for BRAWE_PERF_PROBS_MANS

COMMENT ON TABLE brawe_perf_probs_mans IS 'Mans used in BRAWE where there are performance problems'
/

-- Indexes for BRAWE_PERF_PROBS_MANS

CREATE  UNIQUE INDEX bppm_idx1
 ON brawe_perf_probs_mans
  ( man_ban  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for BRAWE_PERF_PROBS_MANS

-- Start of DDL script for CHG_PRICEPLAN_TRANS
-- Generated 11-mar-03  10:53:49 am
-- from ernst-NINJA:6

-- Table CHG_PRICEPLAN_TRANS

CREATE TABLE chg_priceplan_trans
 (
  subscriber_no              VARCHAR2(20) NOT NULL,
  new_priceplan              VARCHAR2(9) NOT NULL,
  new_campaign_code          VARCHAR2(9) NOT NULL,
  effective_date             DATE,
  dealer                     VARCHAR2(6),
  sales_agent                VARCHAR2(6),
  reason_code                VARCHAR2(5) NOT NULL,
  memo_text                  VARCHAR2(200),
  waive_fees                 VARCHAR2(1) NOT NULL,
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(100),
  priority                   NUMBER(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for CHG_PRICEPLAN_TRANS

COMMENT ON TABLE chg_priceplan_trans IS 'Holds transactions for priceplan changes to be processed by the priceplan changer demon'
/

-- Column Comments for CHG_PRICEPLAN_TRANS

COMMENT ON COLUMN chg_priceplan_trans.dealer IS 'Dealer who performed the change. If left blank, the original dealer code on the subscription is used'
/
COMMENT ON COLUMN chg_priceplan_trans.effective_date IS 'Date when the change must be effective from'
/
COMMENT ON COLUMN chg_priceplan_trans.enter_time IS 'Time when row was inserted into this table. Automatically set on insert operation'
/
COMMENT ON COLUMN chg_priceplan_trans.memo_text IS 'Text in memo to be created on subscription'
/
COMMENT ON COLUMN chg_priceplan_trans.new_campaign_code IS 'The new campaign code'
/
COMMENT ON COLUMN chg_priceplan_trans.new_priceplan IS 'The new priceplan code'
/
COMMENT ON COLUMN chg_priceplan_trans.priority IS 'Transaction priority. Lowest value=highest priority. Valid values: 1 to 5'
/
COMMENT ON COLUMN chg_priceplan_trans.process_status IS 'Status of transaction. Valid values: ''WAITING'', ''IN_PROGRESS'', ''PRSD_SUCCESS'' and ''PRSD_ERROR'''
/
COMMENT ON COLUMN chg_priceplan_trans.process_time IS 'Time when this transaction was actually processed'
/
COMMENT ON COLUMN chg_priceplan_trans.reason_code IS 'Reason code for PP change'
/
COMMENT ON COLUMN chg_priceplan_trans.request_time IS 'Time when PP change is supposed to take place'
/
COMMENT ON COLUMN chg_priceplan_trans.sales_agent IS 'Sales agent who performed the change. If left blank, the original sales agent code on the subscription is used'
/
COMMENT ON COLUMN chg_priceplan_trans.status_desc IS 'Status description'
/
COMMENT ON COLUMN chg_priceplan_trans.subscriber_no IS 'Subscriber number of subscriber who is going to get his priceplan changed'
/
COMMENT ON COLUMN chg_priceplan_trans.waive_fees IS 'Waive fees relating to the PP change Valud values: ''Y'' and ''N'''
/

-- Indexes for CHG_PRICEPLAN_TRANS

CREATE  INDEX chg_priceplan_trans_idx1
 ON chg_priceplan_trans
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for CHG_PRICEPLAN_TRANS

ALTER TABLE chg_priceplan_trans
 ADD PRIMARY KEY (subscriber_no,new_priceplan,enter_time)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE chg_priceplan_trans
  ADD CONSTRAINT chg_priceplan_trans_100 CHECK ( waive_fees IN ('Y', 'N'))
/

ALTER TABLE chg_priceplan_trans
  ADD CONSTRAINT chg_priceplan_trans_101 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR'))
/

ALTER TABLE chg_priceplan_trans
  ADD CONSTRAINT chg_priceplan_trans_102 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for CHG_PRICEPLAN_TRANS

CREATE OR REPLACE TRIGGER chg_priceplan_trans_trg1
BEFORE INSERT
ON chg_priceplan_trans
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  IF INSERTING
  THEN
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;
  END IF;
 END;
/

-- End of DDL script for CHG_PRICEPLAN_TRANS

-- Start of DDL script for COEXISTING_SOCS
-- Generated 11-mar-03  10:53:51 am
-- from ernst-NINJA:6

-- Table COEXISTING_SOCS

CREATE TABLE coexisting_socs
 (
  soc                        VARCHAR2(9) NOT NULL,
  coexisting_soc             VARCHAR2(9) NOT NULL,
  coexisting_mode            VARCHAR2(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     90112
      NEXT        24576
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for COEXISTING_SOCS

COMMENT ON TABLE coexisting_socs IS 'Contains the rules for which SOC''s can exists simultaneously on a subscription'
/

-- Column Comments for COEXISTING_SOCS

COMMENT ON COLUMN coexisting_socs.coexisting_mode IS '''I''=Illegal co-existence, ''M''=Mandatory co-existence'
/
COMMENT ON COLUMN coexisting_socs.coexisting_soc IS 'SOC which can exists simultaneously on the subscription'
/
COMMENT ON COLUMN coexisting_socs.soc IS 'SOC on subscription'
/

-- Indexes for COEXISTING_SOCS

CREATE  INDEX coexisting_socs_idx1
 ON coexisting_socs
  ( soc,
    coexisting_soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     180224
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX coexisting_socs_idx2
 ON coexisting_socs
  ( coexisting_soc,
    soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     147456
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for COEXISTING_SOCS

ALTER TABLE coexisting_socs
 ADD PRIMARY KEY (soc,coexisting_soc)
/

ALTER TABLE coexisting_socs
 ADD CONSTRAINT coexisting_socs_con1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE coexisting_socs
 ADD CONSTRAINT coexisting_socs_con2 FOREIGN KEY (coexisting_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE coexisting_socs
  ADD CONSTRAINT coexisting_socs_con100 CHECK (coexisting_mode IN ('I', 'M'))
/


-- Triggers for COEXISTING_SOCS

CREATE OR REPLACE TRIGGER coexisting_socs_trg1
BEFORE INSERT  OR UPDATE
ON coexisting_socs
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
		v_cnt1	NUMBER;
		v_cnt2	NUMBER;
	BEGIN
		SELECT	COUNT(*)
		INTO	v_cnt1
		FROM	coexisting_socs
		WHERE	(soc = :new.soc AND coexisting_soc = :new.coexisting_soc) OR
				(soc = :new.coexisting_soc AND coexisting_soc = :new.soc);

		IF v_cnt1 != 0
		THEN
			RAISE_APPLICATION_ERROR( -20001, 'Rule already exists in table' );
		END IF;
	END;
/

-- End of DDL script for COEXISTING_SOCS

-- Start of DDL script for DEALERS
-- Generated 11-mar-03  10:53:52 am
-- from ernst-NINJA:6

-- Table DEALERS

CREATE TABLE dealers
 (
  dealer_code                VARCHAR2(5) NOT NULL,
  dealer_group               VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for DEALERS

COMMENT ON TABLE dealers IS 'Holds all valid delaer codes'
/

-- Column Comments for DEALERS

COMMENT ON COLUMN dealers.dealer_code IS 'Dealer code'
/
COMMENT ON COLUMN dealers.dealer_group IS 'Foreign key column from DEALER_GROUPS'
/

-- Indexes for DEALERS

CREATE  INDEX dealers_idx1
 ON dealers
  ( dealer_code,
    dealer_group  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     81920
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for DEALERS

ALTER TABLE dealers
 ADD PRIMARY KEY (dealer_code)
/

ALTER TABLE dealers
 ADD CONSTRAINT dealers_con1 FOREIGN KEY (dealer_group)
      REFERENCES DEALER_GROUPS(dealer_group)
/


-- End of DDL script for DEALERS

-- Start of DDL script for DEALER_GROUPS
-- Generated 11-mar-03  10:53:52 am
-- from ernst-NINJA:6

-- Table DEALER_GROUPS

CREATE TABLE dealer_groups
 (
  dealer_group               VARCHAR2(15) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for DEALER_GROUPS

COMMENT ON TABLE dealer_groups IS 'Holds all valid delear group codes'
/

-- Column Comments for DEALER_GROUPS

COMMENT ON COLUMN dealer_groups.dealer_group IS 'Dealer group code'
/
COMMENT ON COLUMN dealer_groups.description IS 'Description of dealer group code'
/

-- Indexes for DEALER_GROUPS

CREATE  INDEX dealer_groups_idx1
 ON dealer_groups
  ( dealer_group  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for DEALER_GROUPS

ALTER TABLE dealer_groups
 ADD PRIMARY KEY (dealer_group)
/


-- End of DDL script for DEALER_GROUPS

-- Start of DDL script for DEALER_IMEI_REGISTRATIONS
-- Generated 11-mar-03  10:53:53 am
-- from ernst-NINJA:6

-- Table DEALER_IMEI_REGISTRATIONS

CREATE TABLE dealer_imei_registrations
 (
  dealer_code                VARCHAR2(5) NOT NULL,
  ctn                        VARCHAR2(11) NOT NULL,
  item_id                    VARCHAR2(15) NOT NULL,
  sub_imei                   VARCHAR2(15) NOT NULL,
  registration_date          DATE NOT NULL,
  last_update_date           DATE NOT NULL,
  imei_register_status       VARCHAR2(1) NOT NULL,
  provisioning_soc           VARCHAR2(9) NOT NULL,
  manf_cd                    VARCHAR2(10),
  sub_last_name              VARCHAR2(60),
  sub_first_name             VARCHAR2(32),
  legal_last_name            VARCHAR2(60),
  legal_first_name           VARCHAR2(32),
  legal_id_type              VARCHAR2(4),
  legal_identify             VARCHAR2(20),
  comp_reg_id                VARCHAR2(20),
  birth_date                 DATE,
  np_ind                     VARCHAR2(1),
  np_date_time               DATE,
  status_description         VARCHAR2(300),
  np_operation               VARCHAR2(5)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        20971520
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for DEALER_IMEI_REGISTRATIONS

COMMENT ON TABLE dealer_imei_registrations IS 'Contains the IMEI registrations applicable for High Commision Handset sales'
/

-- Column Comments for DEALER_IMEI_REGISTRATIONS

COMMENT ON COLUMN dealer_imei_registrations.ctn IS 'The CTN that was registered for this Sale'
/
COMMENT ON COLUMN dealer_imei_registrations.dealer_code IS 'The Dealer Code'
/
COMMENT ON COLUMN dealer_imei_registrations.imei_register_status IS 'Indicates the Status of the Record (''I''n progress, ''C''omplete, ''R''ejected.)'
/
COMMENT ON COLUMN dealer_imei_registrations.item_id IS 'Valid Item ID as defined in the Fokus reftables ITEM_DEFINITION'
/
COMMENT ON COLUMN dealer_imei_registrations.last_update_date IS 'The Date the record was last updated'
/
COMMENT ON COLUMN dealer_imei_registrations.np_date_time IS 'The Porting Date if associated with a Porting'
/
COMMENT ON COLUMN dealer_imei_registrations.np_ind IS 'Indicates if this relates to a Porting.'
/
COMMENT ON COLUMN dealer_imei_registrations.np_operation IS 'Porting Operation.'
/
COMMENT ON COLUMN dealer_imei_registrations.provisioning_soc IS 'The Commisioning Soc requested for the Registration'
/
COMMENT ON COLUMN dealer_imei_registrations.registration_date IS 'The Date the Record was added'
/
COMMENT ON COLUMN dealer_imei_registrations.status_description IS 'General Descriptive text for the transaction.'
/
COMMENT ON COLUMN dealer_imei_registrations.sub_imei IS 'Will initially be 15 x 0''s for a late regisatration'
/

-- Indexes for DEALER_IMEI_REGISTRATIONS

CREATE  INDEX dealer_imei_reg_idx1
 ON dealer_imei_registrations
  ( dealer_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     10485760
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX dealer_imei_reg_idx2
 ON dealer_imei_registrations
  ( dealer_code,
    imei_register_status  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     10485760
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX dealer_imei_reg_idx3
 ON dealer_imei_registrations
  ( dealer_code,
    ctn  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     10485760
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for DEALER_IMEI_REGISTRATIONS

ALTER TABLE dealer_imei_registrations
 ADD CONSTRAINT dealer_imei_reg_conn1 FOREIGN KEY (dealer_code)
      REFERENCES DEALERS(dealer_code)
/


-- End of DDL script for DEALER_IMEI_REGISTRATIONS

-- Start of DDL script for DOWE_QUEUE
-- Generated 11-mar-03  10:53:54 am
-- from ernst-NINJA:6

-- Table DOWE_QUEUE

CREATE TABLE dowe_queue
 (
  dowe_order_id              VARCHAR2(10),
  dowe_request_dt            DATE,
  dowe_ban_id                VARCHAR2(9),
  dowe_sub_ctn               VARCHAR2(11),
  dowe_adr_status            VARCHAR2(1),
  dowe_proc_status           VARCHAR2(1),
  dowe_err_message           VARCHAR2(255),
  dowe_proc_dt               DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     4669440
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for DOWE_QUEUE

COMMENT ON TABLE dowe_queue IS 'Contains the Transaction received through the DOWE interface'
/

-- Column Comments for DOWE_QUEUE

COMMENT ON COLUMN dowe_queue.dowe_adr_status IS 'Set to ''V'' if all addresses passed Validation, Set to ''I'' if any are Invalid'
/
COMMENT ON COLUMN dowe_queue.dowe_ban_id IS 'Ban ID allocated in Fokus'
/
COMMENT ON COLUMN dowe_queue.dowe_err_message IS 'Set to the ClientException thrown from Ninja if an Error Occurred.'
/
COMMENT ON COLUMN dowe_queue.dowe_order_id IS 'Unique ID from the DOWE Interface'
/
COMMENT ON COLUMN dowe_queue.dowe_proc_dt IS 'Timestamp of the transaction completion'
/
COMMENT ON COLUMN dowe_queue.dowe_proc_status IS 'Set to ''Y'' if the request was processed okay, ''N'' if an error occured.'
/
COMMENT ON COLUMN dowe_queue.dowe_request_dt IS 'Timestamp when the Order was added'
/
COMMENT ON COLUMN dowe_queue.dowe_sub_ctn IS 'The Subscriber CTN assigend in Fokus'
/

-- Indexes for DOWE_QUEUE

CREATE  INDEX dq_idx1
 ON dowe_queue
  ( dowe_order_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     2342912
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for DOWE_QUEUE

-- Start of DDL script for EFAKTURA_ACTION_CODES
-- Generated 11-mar-03  10:53:54 am
-- from ernst-NINJA:6

-- Table EFAKTURA_ACTION_CODES

CREATE TABLE efaktura_action_codes
 (
  action_code                NUMBER(3) NOT NULL,
  action_desc                VARCHAR2(400)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for EFAKTURA_ACTION_CODES

CREATE  INDEX efaktura_action_codes_idx1
 ON efaktura_action_codes
  ( action_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for EFAKTURA_ACTION_CODES

ALTER TABLE efaktura_action_codes
 ADD PRIMARY KEY (action_code)
/


-- End of DDL script for EFAKTURA_ACTION_CODES

-- Start of DDL script for EFAKTURA_LOGS
-- Generated 11-mar-03  10:53:54 am
-- from ernst-NINJA:6

-- Table EFAKTURA_LOGS

CREATE TABLE efaktura_logs
 (
  ban                        NUMBER(9),
  action_date                DATE,
  action_code                NUMBER(3),
  action_comment             VARCHAR2(200)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     1327104
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for EFAKTURA_LOGS

CREATE  INDEX efaktura_logs_idx1
 ON efaktura_logs
  ( ban,
    action_date,
    action_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     1032192
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX efaktura_logs_idx2
 ON efaktura_logs
  ( action_date,
    ban,
    action_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     753664
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX efaktura_logs_idx3
 ON efaktura_logs
  ( action_code,
    ban,
    action_date  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     1081344
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for EFAKTURA_LOGS

ALTER TABLE efaktura_logs
 ADD CONSTRAINT efaktura_logs_con1 FOREIGN KEY (action_code)
      REFERENCES EFAKTURA_ACTION_CODES(action_code)
/


-- End of DDL script for EFAKTURA_LOGS

-- Start of DDL script for FEATURES
-- Generated 11-mar-03  10:53:55 am
-- from ernst-NINJA:6

-- Table FEATURES

CREATE TABLE features
 (
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for FEATURES

COMMENT ON TABLE features IS 'Holds all valid features'
/

-- Column Comments for FEATURES

COMMENT ON COLUMN features.feature_code IS 'Feature code'
/

-- Constraints for FEATURES

ALTER TABLE features
 ADD PRIMARY KEY (feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/


-- End of DDL script for FEATURES

-- Start of DDL script for FEATURE_EXPIRATION_RULES
-- Generated 11-mar-03  10:53:55 am
-- from ernst-NINJA:6

-- Table FEATURE_EXPIRATION_RULES

CREATE TABLE feature_expiration_rules
 (
  soc1                       VARCHAR2(9) NOT NULL,
  feature_code1              VARCHAR2(6) NOT NULL,
  soc2                       VARCHAR2(9) NOT NULL,
  feature_code2              VARCHAR2(6) NOT NULL,
  must_be_expired            NUMBER(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     57344
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for FEATURE_EXPIRATION_RULES

COMMENT ON TABLE feature_expiration_rules IS 'Holds the rules for which features codes must be expired, if two features are in conflict'
/

-- Column Comments for FEATURE_EXPIRATION_RULES

COMMENT ON COLUMN feature_expiration_rules.feature_code1 IS 'Foreign key column from FEATURE_CODES'
/
COMMENT ON COLUMN feature_expiration_rules.feature_code2 IS 'Foreign key column from FEATURE_CODES'
/
COMMENT ON COLUMN feature_expiration_rules.must_be_expired IS '1=The feature code on SOC1 muste be expired. 2=Feature code on SOC2 must be expired.'
/
COMMENT ON COLUMN feature_expiration_rules.soc1 IS 'Foreign key column from SOCS'
/
COMMENT ON COLUMN feature_expiration_rules.soc2 IS 'Foreign key column from SOCS'
/

-- Indexes for FEATURE_EXPIRATION_RULES

CREATE  INDEX feature_expiration_rules_idx1
 ON feature_expiration_rules
  ( soc1,
    feature_code1,
    soc2,
    feature_code2  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for FEATURE_EXPIRATION_RULES

ALTER TABLE feature_expiration_rules
 ADD PRIMARY KEY (soc1,feature_code1,soc2,feature_code2)
/

ALTER TABLE feature_expiration_rules
 ADD CONSTRAINT feature_expiration_rules_con1 FOREIGN KEY (soc1,feature_code1)
      REFERENCES SOCS_FEATURES(soc,feature_code)
/

ALTER TABLE feature_expiration_rules
 ADD CONSTRAINT feature_expiration_rules_con2 FOREIGN KEY (soc2,feature_code2)
      REFERENCES SOCS_FEATURES(soc,feature_code)
/

ALTER TABLE feature_expiration_rules
  ADD CONSTRAINT feature_exp_rules_con100 CHECK (	must_be_expired IN (1, 2))
/


-- End of DDL script for FEATURE_EXPIRATION_RULES

-- Start of DDL script for FEATURE_PARAMETERS
-- Generated 11-mar-03  10:53:56 am
-- from ernst-NINJA:6

-- Table FEATURE_PARAMETERS

CREATE TABLE feature_parameters
 (
  soc                        VARCHAR2(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(20) NOT NULL,
  parameter_type             VARCHAR2(15) NOT NULL,
  mandatory                  VARCHAR2(1) NOT NULL,
  displayable                VARCHAR2(1) NOT NULL,
  default_value              VARCHAR2(100),
  validation_id              VARCHAR2(15),
  is_cloneable               VARCHAR2(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for FEATURE_PARAMETERS

COMMENT ON TABLE feature_parameters IS 'Holds all valid parameters for the feature codes'
/

-- Column Comments for FEATURE_PARAMETERS

COMMENT ON COLUMN feature_parameters.default_value IS 'Default value for parameter'
/
COMMENT ON COLUMN feature_parameters.displayable IS '(Y/N) Indicates whether the parameter is displayed to the end-user'
/
COMMENT ON COLUMN feature_parameters.feature_code IS 'Foreign key column from SOCS_FEATURES'
/
COMMENT ON COLUMN feature_parameters.is_cloneable IS 'Specifies wether the Feature Parameter can be Cloned (N definitely Not..)'
/
COMMENT ON COLUMN feature_parameters.mandatory IS '(Y/N) Indicates whether the parameter is mandatory or not'
/
COMMENT ON COLUMN feature_parameters.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN feature_parameters.parameter_type IS 'Parameter type'
/
COMMENT ON COLUMN feature_parameters.soc IS 'Foreign key column from SOCS_FEATURES'
/
COMMENT ON COLUMN feature_parameters.validation_id IS 'Specifies the validation method for validating the value of the parameter'
/

-- Indexes for FEATURE_PARAMETERS

CREATE  INDEX feature_parameters_idx1
 ON feature_parameters
  ( soc,
    feature_code,
    parameter_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     49152
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for FEATURE_PARAMETERS

ALTER TABLE feature_parameters
 ADD PRIMARY KEY (soc,feature_code,parameter_code)
/

ALTER TABLE feature_parameters
 ADD CONSTRAINT feature_parameters_con1 FOREIGN KEY (soc,feature_code)
      REFERENCES SOCS_FEATURES(soc,feature_code)
/

ALTER TABLE feature_parameters
  ADD CONSTRAINT feature_parameters_con100 CHECK (mandatory IN ('Y', 'N'))
/

ALTER TABLE feature_parameters
  ADD CONSTRAINT feature_parameters_con101 CHECK (displayable IN ('Y', 'N'))
/


-- Triggers for FEATURE_PARAMETERS

CREATE OR REPLACE TRIGGER feature_parameters_trg1
BEFORE INSERT  OR UPDATE
ON feature_parameters
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
		v_cnt	NUMBER DEFAULT 0;

	BEGIN
		IF SUBSTR(:new.default_value, 0, 1 ) = ':'
		THEN
			SELECT	COUNT(*)
			INTO	v_cnt
			FROM	system_defaults
			WHERE	key = :new.default_value;

			IF v_cnt = 0
			THEN
				RAISE_APPLICATION_ERROR( -20001, 'Illegal bind variable' );
			END IF;
		END IF;
	END;
/

-- End of DDL script for FEATURE_PARAMETERS

-- Start of DDL script for FEATURE_PARAMETER_DESC
-- Generated 11-mar-03  10:53:56 am
-- from ernst-NINJA:6

-- Table FEATURE_PARAMETER_DESC

CREATE TABLE feature_parameter_desc
 (
  parameter_name_id          NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for FEATURE_PARAMETER_DESC

COMMENT ON TABLE feature_parameter_desc IS 'Holds descriptions of feature parameters codes'
/

-- Column Comments for FEATURE_PARAMETER_DESC

COMMENT ON COLUMN feature_parameter_desc.description IS 'Description of feaure parameter code'
/
COMMENT ON COLUMN feature_parameter_desc.language_code IS 'Foreign key column from LANGUAGES'
/
COMMENT ON COLUMN feature_parameter_desc.parameter_name_id IS 'Unique number identifying the description'
/

-- Indexes for FEATURE_PARAMETER_DESC

CREATE  INDEX feature_parameter_desc_idx1
 ON feature_parameter_desc
  ( parameter_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for FEATURE_PARAMETER_DESC

ALTER TABLE feature_parameter_desc
 ADD PRIMARY KEY (parameter_name_id,language_code)
/

ALTER TABLE feature_parameter_desc
 ADD CONSTRAINT feature_parameter_desc_con1 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- Triggers for FEATURE_PARAMETER_DESC

CREATE OR REPLACE TRIGGER feature_parameter_desc_trg1
BEFORE INSERT
ON feature_parameter_desc
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	parameter_name_id_seq.nextval
		INTO	:new.parameter_name_id
		FROM	dual;
	END;
/

-- End of DDL script for FEATURE_PARAMETER_DESC

-- Start of DDL script for FEAT_PARMS_PARM_DESC
-- Generated 11-mar-03  10:53:57 am
-- from ernst-NINJA:6

-- Table FEAT_PARMS_PARM_DESC

CREATE TABLE feat_parms_parm_desc
 (
  soc                        VARCHAR2(9) NOT NULL,
  feature_code               VARCHAR2(15) NOT NULL,
  parameter_code             VARCHAR2(20) NOT NULL,
  parameter_name_id          NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     57344
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for FEAT_PARMS_PARM_DESC

COMMENT ON TABLE feat_parms_parm_desc IS 'Holds relations between feature parameter codes and their descriptions'
/

-- Column Comments for FEAT_PARMS_PARM_DESC

COMMENT ON COLUMN feat_parms_parm_desc.feature_code IS 'Foreign key column from FEATURE_PARAMETERS'
/
COMMENT ON COLUMN feat_parms_parm_desc.language_code IS 'Foreign key column from FEATURE_PARAMETER_DESC'
/
COMMENT ON COLUMN feat_parms_parm_desc.parameter_code IS 'Foreign key column from FEATURE_PARAMETERS'
/
COMMENT ON COLUMN feat_parms_parm_desc.parameter_name_id IS 'Foreign key column from FEATURE_PARAMETER_DESC'
/
COMMENT ON COLUMN feat_parms_parm_desc.soc IS 'Foreign key column from FEATURE_PARAMETERS'
/

-- Indexes for FEAT_PARMS_PARM_DESC

CREATE  INDEX feat_parms_parm_desc_idx1
 ON feat_parms_parm_desc
  ( soc,
    feature_code,
    parameter_code,
    parameter_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     81920
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for FEAT_PARMS_PARM_DESC

ALTER TABLE feat_parms_parm_desc
 ADD PRIMARY KEY (soc,feature_code,parameter_code,parameter_name_id,language_code)
/

ALTER TABLE feat_parms_parm_desc
 ADD CONSTRAINT feat_parms_parm_desc_con1 FOREIGN KEY (soc,feature_code,parameter_code)
      REFERENCES FEATURE_PARAMETERS(soc,feature_code,parameter_code)
/

ALTER TABLE feat_parms_parm_desc
 ADD CONSTRAINT feat_parms_parm_desc_con2 FOREIGN KEY (parameter_name_id,language_code)
      REFERENCES FEATURE_PARAMETER_DESC(parameter_name_id,language_code)
/


-- End of DDL script for FEAT_PARMS_PARM_DESC

-- Start of DDL script for FOKUS_PHY_LGL_HLR
-- Generated 11-mar-03  10:53:58 am
-- from ernst-NINJA:6

-- Table FOKUS_PHY_LGL_HLR

CREATE TABLE fokus_phy_lgl_hlr
 (
  logical_hlr                VARCHAR2(2) NOT NULL,
  physical_hlr               NUMBER(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for FOKUS_PHY_LGL_HLR

COMMENT ON TABLE fokus_phy_lgl_hlr IS 'Cross Ref between Logical And Physical HLR'
/

-- Indexes for FOKUS_PHY_LGL_HLR

CREATE  UNIQUE INDEX fokus_hlr_ref_idx1
 ON fokus_phy_lgl_hlr
  ( logical_hlr,
    physical_hlr  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for FOKUS_PHY_LGL_HLR

ALTER TABLE fokus_phy_lgl_hlr
 ADD CONSTRAINT fokus_hlr_ref_pk PRIMARY KEY (logical_hlr,physical_hlr)
/


-- End of DDL script for FOKUS_PHY_LGL_HLR

-- Start of DDL script for HANDSETS_X_PROVISION_SOC
-- Generated 11-mar-03  10:53:58 am
-- from ernst-NINJA:6

-- Table HANDSETS_X_PROVISION_SOC

CREATE TABLE handsets_x_provision_soc
 (
  provisioning_code          NUMBER(5) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        20971520
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for HANDSETS_X_PROVISION_SOC

COMMENT ON TABLE handsets_x_provision_soc IS 'Contains the mapping between the TAC, ITEM_ID and the Provisioning Socs'
/

-- Column Comments for HANDSETS_X_PROVISION_SOC

COMMENT ON COLUMN handsets_x_provision_soc.provisioning_code IS 'Unique Code for the reference'
/
COMMENT ON COLUMN handsets_x_provision_soc.soc IS 'The Provisioning Soc'
/

-- Indexes for HANDSETS_X_PROVISION_SOC

CREATE  UNIQUE INDEX handsets_x_prov_soc_idx1
 ON handsets_x_provision_soc
  ( provisioning_code,
    soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     5242880
   NEXT        5242880
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for HANDSETS_X_PROVISION_SOC

ALTER TABLE handsets_x_provision_soc
 ADD CONSTRAINT handsets_x_prov_soc_conn1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/


-- End of DDL script for HANDSETS_X_PROVISION_SOC

-- Start of DDL script for HLR_DISTRIBUTION_SOCS
-- Generated 11-mar-03  10:53:58 am
-- from ernst-NINJA:6

-- Table HLR_DISTRIBUTION_SOCS

CREATE TABLE hlr_distribution_socs
 (
  soc                        VARCHAR2(9)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for HLR_DISTRIBUTION_SOCS

COMMENT ON TABLE hlr_distribution_socs IS 'Contains Socs that will be processed via HLR Distribution Flows'
/

-- Indexes for HLR_DISTRIBUTION_SOCS

CREATE  UNIQUE INDEX hlr_distrib_socs_idx1
 ON hlr_distribution_socs
  ( soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for HLR_DISTRIBUTION_SOCS

-- Start of DDL script for LANGUAGES
-- Generated 11-mar-03  10:53:59 am
-- from ernst-NINJA:6

-- Table LANGUAGES

CREATE TABLE languages
 (
  language_code              VARCHAR2(3) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for LANGUAGES

COMMENT ON TABLE languages IS 'Holds valid language codes'
/

-- Column Comments for LANGUAGES

COMMENT ON COLUMN languages.description IS 'Description of language code'
/
COMMENT ON COLUMN languages.language_code IS 'Language code'
/

-- Indexes for LANGUAGES

CREATE  INDEX languages_idx1
 ON languages
  ( language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for LANGUAGES

ALTER TABLE languages
 ADD PRIMARY KEY (language_code)
/


-- End of DDL script for LANGUAGES

-- Start of DDL script for MASTER_CHG_PP_TRANS
-- Generated 11-mar-03  10:53:59 am
-- from ernst-NINJA:6

-- Table MASTER_CHG_PP_TRANS

CREATE TABLE master_chg_pp_trans
 (
  subscriber_no              VARCHAR2(20) NOT NULL,
  new_priceplan              VARCHAR2(9) NOT NULL,
  new_campaign_code          VARCHAR2(9) NOT NULL,
  new_subscription_type      VARCHAR2(15) NOT NULL,
  handle_commitment          VARCHAR2(1) NOT NULL,
  effective_date             DATE,
  dealer                     VARCHAR2(6),
  sales_agent                VARCHAR2(6),
  reason_code                VARCHAR2(5) NOT NULL,
  memo_text                  VARCHAR2(200),
  waive_fees                 VARCHAR2(1) NOT NULL,
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) DEFAULT 'IN_PROGRESS' NOT NULL,
  status_desc                VARCHAR2(200),
  priority                   NUMBER(1) DEFAULT 3 NOT NULL,
  requestor_id               VARCHAR2(30)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_CHG_PP_TRANS

COMMENT ON TABLE master_chg_pp_trans IS 'Holds transactions for priceplan changes to be processed by the Master priceplan changer demon'
/

-- Column Comments for MASTER_CHG_PP_TRANS

COMMENT ON COLUMN master_chg_pp_trans.dealer IS 'Dealer who performed the change. If left blank, the original dealer code on the subscription is used'
/
COMMENT ON COLUMN master_chg_pp_trans.effective_date IS 'Date when the change must be effective from'
/
COMMENT ON COLUMN master_chg_pp_trans.enter_time IS 'Time when row was inserted into this table. Automatically set on insert operation'
/
COMMENT ON COLUMN master_chg_pp_trans.handle_commitment IS 'How to handle the existing commitment period. N, (NONE) R, (REPLACE OLD (default)) E, (EXTEND OLD) K, (KEEP OLD)'
/
COMMENT ON COLUMN master_chg_pp_trans.memo_text IS 'Foksu Memo Text for PP change'
/
COMMENT ON COLUMN master_chg_pp_trans.new_campaign_code IS 'The new campaign code'
/
COMMENT ON COLUMN master_chg_pp_trans.new_priceplan IS 'The new priceplan code'
/
COMMENT ON COLUMN master_chg_pp_trans.new_subscription_type IS 'The new Subscription Profile Type'
/
COMMENT ON COLUMN master_chg_pp_trans.priority IS 'Transaction priority. Lowest value=highest priority. Valid values: 1 to 5'
/
COMMENT ON COLUMN master_chg_pp_trans.process_status IS 'Status of transaction. Valid values: ''WAITING'', ''IN_PROGRESS'', ''PRSD_SUCCESS'' and ''PRSD_ERROR'''
/
COMMENT ON COLUMN master_chg_pp_trans.process_time IS 'Time when this transaction was actually processed'
/
COMMENT ON COLUMN master_chg_pp_trans.reason_code IS 'Reason code for PP change'
/
COMMENT ON COLUMN master_chg_pp_trans.requestor_id IS 'Free Text To identify who eneterd them'
/
COMMENT ON COLUMN master_chg_pp_trans.request_time IS 'Time when PP change is supposed to take place'
/
COMMENT ON COLUMN master_chg_pp_trans.sales_agent IS 'Sales agent who performed the change. If left blank, the original sales agent code on the subscription is used'
/
COMMENT ON COLUMN master_chg_pp_trans.status_desc IS 'Status description'
/
COMMENT ON COLUMN master_chg_pp_trans.subscriber_no IS 'Subscriber number of subscriber who is going to get his priceplan changed'
/
COMMENT ON COLUMN master_chg_pp_trans.waive_fees IS 'Waive fees relating to the PP change Valud values: ''Y'' and ''N'''
/

-- Indexes for MASTER_CHG_PP_TRANS

CREATE  INDEX master_chg_pp_trans_idx1
 ON master_chg_pp_trans
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for MASTER_CHG_PP_TRANS

ALTER TABLE master_chg_pp_trans
 ADD PRIMARY KEY (subscriber_no,new_priceplan,enter_time)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_100 CHECK ( waive_fees IN ('Y', 'N'))
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_101 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR'))
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_102 CHECK ( priority BETWEEN 1 AND 5 )
/

ALTER TABLE master_chg_pp_trans
  ADD CONSTRAINT master_chg_pp_trans_103 CHECK ( handle_commitment IN ('N','K','E','R' ) )
/


-- Triggers for MASTER_CHG_PP_TRANS

CREATE OR REPLACE TRIGGER master_chg_pp_trans_trg1
BEFORE INSERT
ON master_chg_pp_trans
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  IF INSERTING
  THEN
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

   IF :new.process_status IS NULL
   THEN
     :new.process_status := 'IN_PROGRESS';
   END IF;

   IF :new.priority IS NULL
   THEN
     :new.priority := 3;
   END IF;

  END IF;
 END;
/

-- End of DDL script for MASTER_CHG_PP_TRANS

-- Start of DDL script for MASTER_HLR_PROCD_FEAT_PARMS
-- Generated 11-mar-03  10:54:00 am
-- from ernst-NINJA:6

-- Table MASTER_HLR_PROCD_FEAT_PARMS

CREATE TABLE master_hlr_procd_feat_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_HLR_PROCD_FEAT_PARMS

COMMENT ON TABLE master_hlr_procd_feat_parms IS 'Holds feature parameter values'
/

-- Column Comments for MASTER_HLR_PROCD_FEAT_PARMS

COMMENT ON COLUMN master_hlr_procd_feat_parms.feature_code IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_hlr_procd_feat_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_hlr_procd_feat_parms.trans_number IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_hlr_procd_feat_parms.value IS 'Value of parameter'
/

-- Constraints for MASTER_HLR_PROCD_FEAT_PARMS

ALTER TABLE master_hlr_procd_feat_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_hlr_procd_feat_parms
 ADD CONSTRAINT master_hlr_procd_feat_p_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_HLR_PROCESSED_FEAT(trans_number,feature_code)
/


-- End of DDL script for MASTER_HLR_PROCD_FEAT_PARMS

-- Start of DDL script for MASTER_HLR_PROCESSED_FEAT
-- Generated 11-mar-03  10:54:00 am
-- from ernst-NINJA:6

-- Table MASTER_HLR_PROCESSED_FEAT

CREATE TABLE master_hlr_processed_feat
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_HLR_PROCESSED_FEAT

COMMENT ON TABLE master_hlr_processed_feat IS 'Holds features of successfully processed SOC''s'
/

-- Column Comments for MASTER_HLR_PROCESSED_FEAT

COMMENT ON COLUMN master_hlr_processed_feat.feature_code IS 'SOC feature'
/
COMMENT ON COLUMN master_hlr_processed_feat.trans_number IS 'Foreign key column from MASTER_TRANSACTIONS table'
/

-- Constraints for MASTER_HLR_PROCESSED_FEAT

ALTER TABLE master_hlr_processed_feat
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        19636224
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE master_hlr_processed_feat
 ADD CONSTRAINT master_hlr_processed_feat_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_HLR_TRANSACTIONS(trans_number)
/


-- End of DDL script for MASTER_HLR_PROCESSED_FEAT

-- Start of DDL script for MASTER_HLR_TRANSACTIONS
-- Generated 11-mar-03  10:54:01 am
-- from ernst-NINJA:6

-- Table MASTER_HLR_TRANSACTIONS

CREATE TABLE master_hlr_transactions
 (
  trans_number               NUMBER(9) NOT NULL,
  hlr                        NUMBER(1) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action_code                VARCHAR2(15) NOT NULL,
  new_soc                    VARCHAR2(9),
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(300),
  dealer_code                VARCHAR2(5),
  sales_agent                VARCHAR2(5),
  priority                   NUMBER(1) NOT NULL,
  request_id                 VARCHAR2(15),
  memo_text                  VARCHAR2(300)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for MASTER_HLR_TRANSACTIONS

CREATE  INDEX master_hlr_trans_idx1
 ON master_hlr_transactions
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2129920
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX master_hlr_trans_idx2
 ON master_hlr_transactions
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX mhlrtran_idx3
 ON master_hlr_transactions
  ( process_status,
    priority,
    hlr,
    request_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        19636224
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for MASTER_HLR_TRANSACTIONS

ALTER TABLE master_hlr_transactions
 ADD PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        5816320
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE master_hlr_transactions
  ADD CONSTRAINT master_hlr_trans_con1 CHECK ( action_code IN ('ADD', 'MODIFY', 'DELETE', 'REPLACE'))
/

ALTER TABLE master_hlr_transactions
  ADD CONSTRAINT master_hlr_trans_con2 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR', 'PRSD_FATAL'))
/

ALTER TABLE master_hlr_transactions
  ADD CONSTRAINT master__hlr_trans_con3 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for MASTER_HLR_TRANSACTIONS

CREATE OR REPLACE TRIGGER master_hlr_trans_trg1
BEFORE INSERT
ON master_hlr_transactions
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_success_count     NUMBER DEFAULT 0;
  v_error_count       NUMBER DEFAULT 0;

 BEGIN
  IF INSERTING
  THEN
            -- Set enter time. And if request time is not set, then set it to enter time
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

  END IF;
 END;
/

-- End of DDL script for MASTER_HLR_TRANSACTIONS

-- Start of DDL script for MASTER_HLR_TRAN_FEATURES
-- Generated 11-mar-03  10:54:02 am
-- from ernst-NINJA:6

-- Table MASTER_HLR_TRAN_FEATURES

CREATE TABLE master_hlr_tran_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_HLR_TRAN_FEATURES

COMMENT ON TABLE master_hlr_tran_features IS 'Holds features for SOC''s to be processed by the MasterManipulator'
/

-- Column Comments for MASTER_HLR_TRAN_FEATURES

COMMENT ON COLUMN master_hlr_tran_features.feature_code IS 'Feature code of SOC to be processed'
/
COMMENT ON COLUMN master_hlr_tran_features.trans_number IS 'Foreign key from MASTER_TRANSACTIONS'
/

-- Constraints for MASTER_HLR_TRAN_FEATURES

ALTER TABLE master_hlr_tran_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        507904
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE master_hlr_tran_features
 ADD CONSTRAINT master_hlr_tran_feat_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_HLR_TRANSACTIONS(trans_number)
/


-- End of DDL script for MASTER_HLR_TRAN_FEATURES

-- Start of DDL script for MASTER_HLR_TRAN_FEATURE_PARMS
-- Generated 11-mar-03  10:54:02 am
-- from ernst-NINJA:6

-- Table MASTER_HLR_TRAN_FEATURE_PARMS

CREATE TABLE master_hlr_tran_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_HLR_TRAN_FEATURE_PARMS

COMMENT ON TABLE master_hlr_tran_feature_parms IS 'Holds feature parameter values'
/

-- Column Comments for MASTER_HLR_TRAN_FEATURE_PARMS

COMMENT ON COLUMN master_hlr_tran_feature_parms.feature_code IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_hlr_tran_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_hlr_tran_feature_parms.trans_number IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_hlr_tran_feature_parms.value IS 'Value of parameter'
/

-- Constraints for MASTER_HLR_TRAN_FEATURE_PARMS

ALTER TABLE master_hlr_tran_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_hlr_tran_feature_parms
 ADD CONSTRAINT master_hlr_t_f_p_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_HLR_TRAN_FEATURES(trans_number,feature_code)
/


-- End of DDL script for MASTER_HLR_TRAN_FEATURE_PARMS

-- Start of DDL script for MASTER_MOVER
-- Generated 11-mar-03  10:54:02 am
-- from ernst-NINJA:6

-- Table MASTER_MOVER

CREATE TABLE master_mover
 (
  stream_no                  NUMBER(2),
  ban_from                   NUMBER(9),
  ban_to                     NUMBER(9),
  processed                  VARCHAR2(1),
  subs_moved                 NUMBER(4),
  subs_error                 NUMBER(4)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for MASTER_MOVER

COMMENT ON TABLE master_mover IS 'Contains the details for the Master Mover to process the SP moves'
/

-- End of DDL script for MASTER_MOVER

-- Start of DDL script for MASTER_PROCD_FEATURE_PARMS
-- Generated 11-mar-03  10:54:03 am
-- from ernst-NINJA:6

-- Table MASTER_PROCD_FEATURE_PARMS

CREATE TABLE master_procd_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_PROCD_FEATURE_PARMS

COMMENT ON TABLE master_procd_feature_parms IS 'Holds feature parameter values'
/

-- Column Comments for MASTER_PROCD_FEATURE_PARMS

COMMENT ON COLUMN master_procd_feature_parms.feature_code IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_procd_feature_parms.trans_number IS 'Foreign key column from MASTER_PROCESSED_FEATURES table'
/
COMMENT ON COLUMN master_procd_feature_parms.value IS 'Value of parameter'
/

-- Constraints for MASTER_PROCD_FEATURE_PARMS

ALTER TABLE master_procd_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_procd_feature_parms
 ADD CONSTRAINT master_procd_feat_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_PROCESSED_FEATURES(trans_number,feature_code)
/


-- End of DDL script for MASTER_PROCD_FEATURE_PARMS

-- Start of DDL script for MASTER_PROCESSED_FEATURES
-- Generated 11-mar-03  10:54:03 am
-- from ernst-NINJA:6

-- Table MASTER_PROCESSED_FEATURES

CREATE TABLE master_processed_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_PROCESSED_FEATURES

COMMENT ON TABLE master_processed_features IS 'Holds features of successfully processed SOC''s'
/

-- Column Comments for MASTER_PROCESSED_FEATURES

COMMENT ON COLUMN master_processed_features.feature_code IS 'SOC feature'
/
COMMENT ON COLUMN master_processed_features.trans_number IS 'Foreign key column from MASTER_TRANSACTIONS table'
/

-- Constraints for MASTER_PROCESSED_FEATURES

ALTER TABLE master_processed_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_processed_features
 ADD CONSTRAINT master_processed_features_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_TRANSACTIONS(trans_number)
/


-- End of DDL script for MASTER_PROCESSED_FEATURES

-- Start of DDL script for MASTER_TRANSACTIONS
-- Generated 11-mar-03  10:54:03 am
-- from ernst-NINJA:6

-- Table MASTER_TRANSACTIONS

CREATE TABLE master_transactions
 (
  trans_number               NUMBER(9) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action_code                VARCHAR2(15) NOT NULL,
  new_soc                    VARCHAR2(9),
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(300),
  dealer_code                VARCHAR2(5),
  sales_agent                VARCHAR2(5),
  priority                   NUMBER(1) NOT NULL,
  request_id                 VARCHAR2(15),
  memo_text                  VARCHAR2(300)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_TRANSACTIONS

COMMENT ON TABLE master_transactions IS 'Holds SOC transactions (add/modify/delete/replace) to be processed by the MasterManipulator'
/

-- Column Comments for MASTER_TRANSACTIONS

COMMENT ON COLUMN master_transactions.action_code IS 'Code specifying the transaction type. Valid values: ADD, MODIFY and DELETE'
/
COMMENT ON COLUMN master_transactions.enter_time IS 'Time when row was inserted into this table. Automatically generated value'
/
COMMENT ON COLUMN master_transactions.memo_text IS 'Memo Text'
/
COMMENT ON COLUMN master_transactions.priority IS 'Transaction priority. Value from 1 to 5 where 1 is highest priority.'
/
COMMENT ON COLUMN master_transactions.process_status IS 'Process status. Valid values: WAITING, IN_PROGRESS, PRSD_SUCCESS, PRSD_ERROR and PRSD_FATAL'
/
COMMENT ON COLUMN master_transactions.process_time IS 'Time when service request was processed'
/
COMMENT ON COLUMN master_transactions.request_id IS 'Requestor Specified ID code for retrieval from Webrep..'
/
COMMENT ON COLUMN master_transactions.request_time IS 'Time when transaction must be processed. Defaults to value in NETER_TIME column'
/
COMMENT ON COLUMN master_transactions.soc IS 'SOC which needs to be Added/modified/deleted'
/
COMMENT ON COLUMN master_transactions.status_desc IS 'Error message'
/
COMMENT ON COLUMN master_transactions.subscriber_no IS 'Subscriber where the transaction must be carried out'
/
COMMENT ON COLUMN master_transactions.trans_number IS 'Unique transaction number.'
/

-- Indexes for MASTER_TRANSACTIONS

CREATE  INDEX master_transactions_idx1
 ON master_transactions
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2129920
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX master_transactions_idx2
 ON master_transactions
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for MASTER_TRANSACTIONS

ALTER TABLE master_transactions
 ADD PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con1 CHECK ( action_code IN ('ADD', 'MODIFY', 'DELETE', 'REPLACE'))
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con2 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR', 'PRSD_FATAL'))
/

ALTER TABLE master_transactions
  ADD CONSTRAINT master_transactions_con3 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for MASTER_TRANSACTIONS

CREATE OR REPLACE TRIGGER master_transactions_trg1
BEFORE INSERT
ON master_transactions
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_success_count     NUMBER DEFAULT 0;
  v_error_count       NUMBER DEFAULT 0;

 BEGIN
  IF INSERTING
  THEN
            -- Set enter time. And if request time is not set, then set it to enter time
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

  END IF;
 END;
/

-- End of DDL script for MASTER_TRANSACTIONS

-- Start of DDL script for MASTER_TRAN_FEATURES
-- Generated 11-mar-03  10:54:04 am
-- from ernst-NINJA:6

-- Table MASTER_TRAN_FEATURES

CREATE TABLE master_tran_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_TRAN_FEATURES

COMMENT ON TABLE master_tran_features IS 'Holds features for SOC''s to be processed by the MasterManipulator'
/

-- Column Comments for MASTER_TRAN_FEATURES

COMMENT ON COLUMN master_tran_features.feature_code IS 'Feature code of SOC to be processed'
/
COMMENT ON COLUMN master_tran_features.trans_number IS 'Foreign key from MASTER_TRANSACTIONS'
/

-- Constraints for MASTER_TRAN_FEATURES

ALTER TABLE master_tran_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        507904
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE master_tran_features
 ADD CONSTRAINT master_tran_features_con1 FOREIGN KEY (trans_number)
      REFERENCES MASTER_TRANSACTIONS(trans_number)
/


-- End of DDL script for MASTER_TRAN_FEATURES

-- Start of DDL script for MASTER_TRAN_FEATURE_PARMS
-- Generated 11-mar-03  10:54:05 am
-- from ernst-NINJA:6

-- Table MASTER_TRAN_FEATURE_PARMS

CREATE TABLE master_tran_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for MASTER_TRAN_FEATURE_PARMS

COMMENT ON TABLE master_tran_feature_parms IS 'Holds feature parameter values'
/

-- Column Comments for MASTER_TRAN_FEATURE_PARMS

COMMENT ON COLUMN master_tran_feature_parms.feature_code IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_tran_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN master_tran_feature_parms.trans_number IS 'Foreign key column from MASTER_TRAN_FEATURES table'
/
COMMENT ON COLUMN master_tran_feature_parms.value IS 'Value of parameter'
/

-- Constraints for MASTER_TRAN_FEATURE_PARMS

ALTER TABLE master_tran_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE master_tran_feature_parms
 ADD CONSTRAINT master_tran_feat_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES MASTER_TRAN_FEATURES(trans_number,feature_code)
/


-- End of DDL script for MASTER_TRAN_FEATURE_PARMS

-- Start of DDL script for MIDAS_QUEUE
-- Generated 11-mar-03  10:54:05 am
-- from ernst-NINJA:6

-- Table MIDAS_QUEUE

CREATE TABLE midas_queue
 (
  phone_no                   VARCHAR2(12),
  charge_date                DATE,
  charge_code                VARCHAR2(9),
  charge_desc                VARCHAR2(25),
  charge_amt                 NUMBER,
  proc_status                VARCHAR2(1),
  proc_date                  DATE,
  memo_text                  VARCHAR2(255),
  voucher                    VARCHAR2(30)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for MIDAS_QUEUE

COMMENT ON TABLE midas_queue IS 'Contains the Transactions from the Midas Interface'
/

-- End of DDL script for MIDAS_QUEUE

-- Start of DDL script for MW_TMP_BAN_ACCT_CHGS
-- Generated 11-mar-03  10:54:05 am
-- from ernst-NINJA:6

-- Table MW_TMP_BAN_ACCT_CHGS

CREATE TABLE mw_tmp_ban_acct_chgs
 (
  ban                        NUMBER(*,0) NOT NULL,
  new_acct_type              VARCHAR2(1) NOT NULL,
  new_acct_sub_type          VARCHAR2(2) NOT NULL,
  request_id                 VARCHAR2(15)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        761856
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_BAN_ACCT_CHGS

-- Start of DDL script for MW_TMP_GPRSPPADD
-- Generated 11-mar-03  10:54:05 am
-- from ernst-NINJA:6

-- Table MW_TMP_GPRSPPADD

CREATE TABLE mw_tmp_gprsppadd
 (
  subscriber_no              VARCHAR2(20)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_GPRSPPADD

-- Start of DDL script for MW_TMP_HLR_TRANS
-- Generated 11-mar-03  10:54:06 am
-- from ernst-NINJA:6

-- Table MW_TMP_HLR_TRANS

CREATE TABLE mw_tmp_hlr_trans
 (
  subscriber_no              VARCHAR2(20),
  hlr                        NUMBER(1),
  soc                        VARCHAR2(9),
  action                     VARCHAR2(15),
  feature                    VARCHAR2(9),
  parameter                  VARCHAR2(9),
  parm_value                 VARCHAR2(15),
  request_id                 VARCHAR2(15),
  memo_text                  VARCHAR2(300)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        778240
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_HLR_TRANS

-- Start of DDL script for MW_TMP_NINJA_SUBS
-- Generated 11-mar-03  10:54:06 am
-- from ernst-NINJA:6

-- Table MW_TMP_NINJA_SUBS

CREATE TABLE mw_tmp_ninja_subs
 (
  sub_no                     VARCHAR2(20)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for MW_TMP_NINJA_SUBS

CREATE  INDEX tmp_ns_idx1
 ON mw_tmp_ninja_subs
  ( sub_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_NINJA_SUBS

-- Start of DDL script for MW_TMP_REPLACE_SOC_TRANS
-- Generated 11-mar-03  10:54:06 am
-- from ernst-NINJA:6

-- Table MW_TMP_REPLACE_SOC_TRANS

CREATE TABLE mw_tmp_replace_soc_trans
 (
  subscriber_no              VARCHAR2(20),
  soc                        VARCHAR2(9),
  new_soc                    VARCHAR2(9),
  request_id                 VARCHAR2(15),
  memo_text                  VARCHAR2(300)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        147456
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_REPLACE_SOC_TRANS

-- Start of DDL script for MW_TMP_TRANS
-- Generated 11-mar-03  10:54:06 am
-- from ernst-NINJA:6

-- Table MW_TMP_TRANS

CREATE TABLE mw_tmp_trans
 (
  subscriber_no              VARCHAR2(20),
  soc                        VARCHAR2(9),
  action                     VARCHAR2(15),
  feature                    VARCHAR2(9),
  parameter                  VARCHAR2(9),
  parm_value                 VARCHAR2(15),
  request_id                 VARCHAR2(15),
  memo_text                  VARCHAR2(300)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_TRANS

-- Start of DDL script for MW_TMP_VENTELO
-- Generated 11-mar-03  10:54:07 am
-- from ernst-NINJA:6

-- Table MW_TMP_VENTELO

CREATE TABLE mw_tmp_ventelo
 (
  subscriber                 VARCHAR2(17),
  effective_date             DATE NOT NULL,
  init_activation_date       DATE NOT NULL,
  sub_status                 CHAR(1) NOT NULL,
  sub_status_date            DATE NOT NULL,
  original_init_date         DATE NOT NULL,
  sub_status_last_act        CHAR(3),
  sub_status_rsn_code        CHAR(4),
  customer_ban               NUMBER(9),
  dealer_code                CHAR(5),
  org_dealer_code            CHAR(5),
  customer_id                NUMBER(9) NOT NULL,
  subscriber_id              NUMBER(9) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        1146880
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO

-- Start of DDL script for MW_TMP_VENTELO_PRODS
-- Generated 11-mar-03  10:54:07 am
-- from ernst-NINJA:6

-- Table MW_TMP_VENTELO_PRODS

CREATE TABLE mw_tmp_ventelo_prods
 (
  ban                        NUMBER(9) NOT NULL,
  subscriber                 VARCHAR2(17),
  soc                        CHAR(9) NOT NULL,
  soc_effective_date         DATE NOT NULL,
  feature_code               CHAR(6) NOT NULL,
  service_type               CHAR(1) NOT NULL,
  ftr_effective_date         DATE NOT NULL,
  ftr_expiration_date        DATE NOT NULL,
  additional_telno           VARCHAR2(17)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        8724480
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO_PRODS

-- Start of DDL script for MW_TMP_VENTELO_SIMS
-- Generated 11-mar-03  10:54:07 am
-- from ernst-NINJA:6

-- Table MW_TMP_VENTELO_SIMS

CREATE TABLE mw_tmp_ventelo_sims
 (
  customer_id                NUMBER(9) NOT NULL,
  subscriber                 VARCHAR2(17),
  equipment_no               VARCHAR2(20) NOT NULL,
  init_activation_date       DATE NOT NULL,
  expiration_date            DATE,
  imsi                       VARCHAR2(15),
  effective_date             DATE,
  sw_state_ind               CHAR(1),
  last_sw_actv_date          DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO_SIMS

-- Start of DDL script for NINJA_BAN_OWNERSHIP
-- Generated 11-mar-03  10:54:08 am
-- from ernst-NINJA:6

-- Table NINJA_BAN_OWNERSHIP

CREATE TABLE ninja_ban_ownership
 (
  acct_type                  VARCHAR2(1),
  acct_sub_type              VARCHAR2(2),
  ownership_type             VARCHAR2(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_BAN_OWNERSHIP

CREATE  UNIQUE INDEX ban_ownership_idx1
 ON ninja_ban_ownership
  ( acct_type,
    acct_sub_type  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_BAN_OWNERSHIP

-- Start of DDL script for NINJA_DATAFIELD
-- Generated 11-mar-03  10:54:08 am
-- from ernst-NINJA:6

-- Table NINJA_DATAFIELD

CREATE TABLE ninja_datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     3940352
      NEXT        5840896
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD

ALTER TABLE ninja_datafield
 ADD CONSTRAINT ninja_datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     1425408
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE ninja_datafield
 ADD CONSTRAINT ninja_datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES NINJA_DATASET(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD

-- Start of DDL script for NINJA_DATAFIELD_VALUE
-- Generated 11-mar-03  10:54:08 am
-- from ernst-NINJA:6

-- Table NINJA_DATAFIELD_VALUE

CREATE TABLE ninja_datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0) DEFAULT -1,
  datafield_ismandatory      NUMBER(*,0) DEFAULT -1,
  datafield_occurrance       NUMBER(*,0) DEFAULT 0 NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     15728640
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Constraints for NINJA_DATAFIELD_VALUE

ALTER TABLE ninja_datafield_value
 ADD CONSTRAINT ninja_datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     11567104
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/


-- End of DDL script for NINJA_DATAFIELD_VALUE

-- Start of DDL script for NINJA_DATASET
-- Generated 11-mar-03  10:54:09 am
-- from ernst-NINJA:6

-- Table NINJA_DATASET

CREATE TABLE ninja_dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1),
  dataset_comment            VARCHAR2(80)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     204800
      NEXT        245760
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATASET

ALTER TABLE ninja_dataset
 ADD CONSTRAINT ninja_dataset_name_pk PRIMARY KEY (dataset_name)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     49152
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/


-- End of DDL script for NINJA_DATASET

-- Start of DDL script for NINJA_JOBS
-- Generated 11-mar-03  10:54:09 am
-- from ernst-NINJA:6

-- Table NINJA_JOBS

CREATE TABLE ninja_jobs
 (
  job_id                     NUMBER(6) NOT NULL,
  job_status                 VARCHAR2(15) NOT NULL,
  was_running                VARCHAR2(1) NOT NULL,
  sleep_time                 NUMBER(10) NOT NULL,
  sleep_mode                 VARCHAR2(15) NOT NULL,
  next_exec_time             DATE,
  status_time                DATE NOT NULL,
  status_desc                VARCHAR2(100),
  bean                       VARCHAR2(50) NOT NULL,
  method                     VARCHAR2(50) NOT NULL,
  url                        VARCHAR2(100) NOT NULL,
  user_name                  VARCHAR2(15) NOT NULL,
  password                   VARCHAR2(15) NOT NULL,
  job_desc                   VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for NINJA_JOBS

COMMENT ON TABLE ninja_jobs IS 'Holds recurring Ninja jobs.'
/

-- Column Comments for NINJA_JOBS

COMMENT ON COLUMN ninja_jobs.bean IS 'EJB which is to execute job.'
/
COMMENT ON COLUMN ninja_jobs.job_id IS 'Unique job id. Valid values from 0 to 49.'
/
COMMENT ON COLUMN ninja_jobs.job_status IS 'Job status. Valid values: STOPPED, SLEEPING, RUNNING, CRASHED, STARTING and STOPPING.'
/
COMMENT ON COLUMN ninja_jobs.method IS 'Method in demon bean used to perform job.'
/
COMMENT ON COLUMN ninja_jobs.next_exec_time IS 'Next time when the job must run. Only populated when sleep_mode is FIXED_START.'
/
COMMENT ON COLUMN ninja_jobs.password IS 'Password used when logging on to server.'
/
COMMENT ON COLUMN ninja_jobs.sleep_mode IS 'Valid values: FIXED_START and FIXED_SLEEP'
/
COMMENT ON COLUMN ninja_jobs.sleep_time IS 'Time between job executions (in milliseconds).'
/
COMMENT ON COLUMN ninja_jobs.status_desc IS 'Text describing the status.'
/
COMMENT ON COLUMN ninja_jobs.status_time IS 'Time when job got current status.'
/
COMMENT ON COLUMN ninja_jobs.url IS 'Address of server containing bean.'
/
COMMENT ON COLUMN ninja_jobs.user_name IS 'Username used to log on to server.'
/
COMMENT ON COLUMN ninja_jobs.was_running IS 'Indicates if the job was running when the master wes terminated. Valid values: ''Y'' and ''N''.'
/

-- Constraints for NINJA_JOBS

ALTER TABLE ninja_jobs
 ADD PRIMARY KEY (job_id)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE ninja_jobs
  ADD CONSTRAINT ninja_jobs_con100 CHECK (job_status IN ('STOPPED', 'SLEEPING', 'RUNNING', 'CRASHED', 'STARTING', 'STOPPING', 'TERMINATING', 'TERMINATED'))
/

ALTER TABLE ninja_jobs
  ADD CONSTRAINT ninja_jobs_con101 CHECK (job_id BETWEEN 0 AND 49 )
/

ALTER TABLE ninja_jobs
  ADD CONSTRAINT ninja_jobs_con102 CHECK (sleep_mode IN ('FIXED_START', 'FIXED_SLEEP'))
/

ALTER TABLE ninja_jobs
  ADD CONSTRAINT ninja_jobs_con103 CHECK (was_running IN ('Y', 'N'))
/


-- End of DDL script for NINJA_JOBS

-- Start of DDL script for NINJA_SUB_CHANGE_STATUS
-- Generated 11-mar-03  10:54:10 am
-- from ernst-NINJA:6

-- Table NINJA_SUB_CHANGE_STATUS

CREATE TABLE ninja_sub_change_status
 (
  trans_number               NUMBER(9) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  action_code                VARCHAR2(7) NOT NULL,
  dealer_code                VARCHAR2(5),
  memo_text                  VARCHAR2(200),
  reason_code                VARCHAR2(15),
  fee_waiver_code            VARCHAR2(15),
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  priority                   NUMBER(1) DEFAULT 3 NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) DEFAULT 'WAITING' NOT NULL,
  status_desc                VARCHAR2(300),
  request_reference_id       VARCHAR2(6),
  release_ctn                VARCHAR2(1),
  prepaid_user               VARCHAR2(1) DEFAULT 'N',
  hlr_stream                 NUMBER(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        13090816
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_SUB_CHANGE_STATUS

COMMENT ON TABLE ninja_sub_change_status IS 'Table for Storing Requests for Subscriber Status Changes (Suspend/Resume or Cancel) to Ninja'
/

-- Column Comments for NINJA_SUB_CHANGE_STATUS

COMMENT ON COLUMN ninja_sub_change_status.action_code IS 'Action Code - ''CANCEL'',''SUSPEND'' or ''RESUME'' (note Subcription must be Active for SUSPEND, Active or Suspended for CANCEL and Suspended for RESUME)'
/
COMMENT ON COLUMN ninja_sub_change_status.dealer_code IS 'Dealer Performing the activity - null will allow all.  Expected usage is to limit Service Providers'
/
COMMENT ON COLUMN ninja_sub_change_status.enter_time IS 'Time of Entering the Request'
/
COMMENT ON COLUMN ninja_sub_change_status.fee_waiver_code IS 'Fee Waiver Code to be used - If none is specified will use the system defaults)'
/
COMMENT ON COLUMN ninja_sub_change_status.hlr_stream IS 'HLR Stream to Process The Request'
/
COMMENT ON COLUMN ninja_sub_change_status.memo_text IS 'Memo Text to be written into Fokus for the activity'
/
COMMENT ON COLUMN ninja_sub_change_status.prepaid_user IS 'Prepaid User Id required'
/
COMMENT ON COLUMN ninja_sub_change_status.priority IS 'Priority of the transaction. (values 1 thru 9), Default is 3'
/
COMMENT ON COLUMN ninja_sub_change_status.process_status IS 'Default Value ''WAITING'', (PRSD_SUCCESS or PRSD_ERROR - will be updated by Ninja)'
/
COMMENT ON COLUMN ninja_sub_change_status.process_time IS 'Time the request was processed by Ninja'
/
COMMENT ON COLUMN ninja_sub_change_status.reason_code IS 'Valid Fokus Reason Code to be used for the Activity.'
/
COMMENT ON COLUMN ninja_sub_change_status.release_ctn IS 'Indicator to be used in conjunction with ''CANCEL'', If ''Y''es Ninja will also overide the Aging of the Cancelled subscriptions CTN.'
/
COMMENT ON COLUMN ninja_sub_change_status.request_reference_id IS 'Free text to associate the requestor to the transactions'
/
COMMENT ON COLUMN ninja_sub_change_status.request_time IS 'Time the Request Should be processed (earliest activation date/time)'
/
COMMENT ON COLUMN ninja_sub_change_status.status_desc IS 'Dsecriptive text in case of PRSD_ERROR'
/
COMMENT ON COLUMN ninja_sub_change_status.subscriber_no IS 'Subscriber where the transaction must be carried out'
/
COMMENT ON COLUMN ninja_sub_change_status.trans_number IS 'Unique transaction number.'
/

-- Indexes for NINJA_SUB_CHANGE_STATUS

CREATE  INDEX ninja_sub_chg_stat_idx1
 ON ninja_sub_change_status
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        5816320
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

CREATE  INDEX ninja_sub_chg_stat_idx2
 ON ninja_sub_change_status
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        3874816
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_SUB_CHANGE_STATUS

ALTER TABLE ninja_sub_change_status
 ADD CONSTRAINT ninja_sub_chg_stat_pk1 PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        1146880
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn1 CHECK ( PROCESS_STATUS IN ('IN_PROGRESS','WAITING','PRSD_ERROR','PRSD_SUCCESS')  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn2 CHECK ( ACTION_CODE IN ('CANCEL','RESUME','SUSPEND')  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn3 CHECK ( priority BETWEEN 1 AND 5  )
/

ALTER TABLE ninja_sub_change_status
  ADD CONSTRAINT ninja_sub_chg_conn4 CHECK (
subscriber_no LIKE '%047%')
/


-- Triggers for NINJA_SUB_CHANGE_STATUS

CREATE OR REPLACE TRIGGER ninja_sub_chg_stat_trg1
BEFORE INSERT
ON ninja_sub_change_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	ninja_sub_chg_stat_seq.nextval
		INTO	:new.trans_number
		FROM	dual;

        SELECT sysdate
        INTO :new.enter_time
        FROM dual;
        IF :new.request_time IS NULL
        THEN
            :new.request_time := :new.enter_time;
        END IF;
        IF :new.process_status IS NULL
        THEN
            :new.process_status := 'WAITING';
        END IF;

END;
/

-- End of DDL script for NINJA_SUB_CHANGE_STATUS

-- Start of DDL script for NINJA_TNOR_TRANS
-- Generated 11-mar-03  10:54:11 am
-- from ernst-NINJA:6

-- Table NINJA_TNOR_TRANS

CREATE TABLE ninja_tnor_trans
 (
  referasn_nr                VARCHAR2(25),
  record_text                VARCHAR2(255)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     7577600
      NEXT        3874816
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_TNOR_TRANS

COMMENT ON TABLE ninja_tnor_trans IS 'Transaction list of applied telenor charges'
/

-- Indexes for NINJA_TNOR_TRANS

CREATE  INDEX ntt_idx1
 ON ninja_tnor_trans
  ( referasn_nr  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     3481600
   NEXT        1720320
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_TNOR_TRANS

-- Start of DDL script for NINJA_USER
-- Generated 11-mar-03  10:54:11 am
-- from ernst-NINJA:6

-- Table NINJA_USER

CREATE TABLE ninja_user
 (
  username                   VARCHAR2(32) NOT NULL,
  fokus_logon                NUMBER(10)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_USER

COMMENT ON TABLE ninja_user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for NINJA_USER

CREATE  UNIQUE INDEX sys_c0056039
 ON ninja_user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_USER

ALTER TABLE ninja_user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for NINJA_USER

-- Start of DDL script for NP_BATCH
-- Generated 11-mar-03  10:54:11 am
-- from ernst-NINJA:6

-- Table NP_BATCH

CREATE TABLE np_batch
 (
  agreement_code             VARCHAR2(15),
  port_date_time             VARCHAR2(14),
  ban                        VARCHAR2(9),
  dealer                     VARCHAR2(5),
  sales_rep                  VARCHAR2(5),
  ctn                        VARCHAR2(8),
  sim                        VARCHAR2(20),
  donor_code                 VARCHAR2(3),
  first_name                 VARCHAR2(32),
  last_name                  VARCHAR2(60),
  addt_title                 VARCHAR2(60),
  postcode                   VARCHAR2(9),
  city                       VARCHAR2(39),
  street_name                VARCHAR2(60),
  house_no                   VARCHAR2(20),
  letter                     VARCHAR2(2),
  floor                      VARCHAR2(2),
  door                       VARCHAR2(4),
  email                      VARCHAR2(90),
  vm_number                  VARCHAR2(8),
  vm_fax_no                  VARCHAR2(8),
  data_asyn                  VARCHAR2(8),
  data_isdn                  VARCHAR2(8),
  data_hs                    VARCHAR2(8),
  fax_no                     VARCHAR2(8),
  cug_soc                    VARCHAR2(9),
  cug_pni                    VARCHAR2(5),
  process_time               DATE,
  process_status             VARCHAR2(15),
  status_desc                VARCHAR2(300),
  requestor_id               VARCHAR2(30)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Indexes for NP_BATCH

CREATE  UNIQUE INDEX np_batch_idx1
 ON np_batch
  ( ctn  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NP_BATCH

-- Start of DDL script for NP_DONOR_CODES
-- Generated 11-mar-03  10:54:12 am
-- from ernst-NINJA:6

-- Table NP_DONOR_CODES

CREATE TABLE np_donor_codes
 (
  np_donor_code              VARCHAR2(10),
  np_donor_name              VARCHAR2(60),
  np_netcom_net_ind          VARCHAR2(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for NP_DONOR_CODES

COMMENT ON TABLE np_donor_codes IS 'Contains the Donor Codes for Number Protability'
/

-- Column Comments for NP_DONOR_CODES

COMMENT ON COLUMN np_donor_codes.np_donor_code IS 'Code to identify the Donor'
/
COMMENT ON COLUMN np_donor_codes.np_donor_name IS 'Name of the Donor Operator'
/
COMMENT ON COLUMN np_donor_codes.np_netcom_net_ind IS 'Indicates if this Donor uses NetComs'' Network'
/

-- Indexes for NP_DONOR_CODES

CREATE  UNIQUE INDEX np_dc_idx1
 ON np_donor_codes
  ( np_donor_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for NP_DONOR_CODES

-- Start of DDL script for NP_TIME_PORT
-- Generated 11-mar-03  10:54:12 am
-- from ernst-NINJA:6

-- Table NP_TIME_PORT

CREATE TABLE np_time_port
 (
  np_ref                     NUMBER(8),
  np_nrdb_ref_id             VARCHAR2(20),
  np_user                    VARCHAR2(16),
  np_ctn                     VARCHAR2(11),
  np_original_donor_code     VARCHAR2(10),
  np_donor_code              VARCHAR2(10),
  np_recipient_code          VARCHAR2(10),
  np_date_time_created       VARCHAR2(14),
  np_date_time_modified      VARCHAR2(14),
  np_date_time_port          VARCHAR2(14),
  np_description             VARCHAR2(150),
  np_action                  VARCHAR2(4),
  np_status                  VARCHAR2(4),
  np_ids_blob                BLOB DEFAULT empty_blob(),
  np_retries                 NUMBER(*,0) DEFAULT 0
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     104857600
      NEXT        52428800
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Column Comments for NP_TIME_PORT

COMMENT ON COLUMN np_time_port.np_action IS 'Ninja Action to Perform when Retrieving the Request.'
/
COMMENT ON COLUMN np_time_port.np_ctn IS 'Main CTN for the Porting Request.'
/
COMMENT ON COLUMN np_time_port.np_date_time_created IS 'Date/Time YYYYMMDDHHMMSS of the entry into the Table.'
/
COMMENT ON COLUMN np_time_port.np_date_time_modified IS 'Date/Time YYYYMMDDHHMMSS of the last update of the Request.'
/
COMMENT ON COLUMN np_time_port.np_date_time_port IS 'Date/Time YYYYMMDDHHMMSS the Port should take place.'
/
COMMENT ON COLUMN np_time_port.np_description IS 'Description of the Result of the Latest Processing.'
/
COMMENT ON COLUMN np_time_port.np_donor_code IS 'NRDB Current Donor holding the CTN.'
/
COMMENT ON COLUMN np_time_port.np_ids_blob IS 'BLOB containing the NPactionIDS containing all the required details for Processing by Ninja.'
/
COMMENT ON COLUMN np_time_port.np_nrdb_ref_id IS 'NRDB Reference ID.'
/
COMMENT ON COLUMN np_time_port.np_original_donor_code IS 'NRDB Original Donor Code of the CTN.'
/
COMMENT ON COLUMN np_time_port.np_recipient_code IS 'NRDB Donor Code for the Requester of the CTN.'
/
COMMENT ON COLUMN np_time_port.np_ref IS 'Unique key. Automatically generated upon insert.'
/
COMMENT ON COLUMN np_time_port.np_retries IS 'Number of times the transaction has been attempted.'
/
COMMENT ON COLUMN np_time_port.np_status IS 'Status of the Request.'
/
COMMENT ON COLUMN np_time_port.np_user IS 'User Entering the Request.'
/

-- Indexes for NP_TIME_PORT

CREATE  INDEX np_time_port_idx1
 ON np_time_port
  ( np_ctn,
    np_status  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        147456
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

CREATE  INDEX np_time_port_idx2
 ON np_time_port
  ( np_status,
    np_date_time_port  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        147456
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NP_TIME_PORT

ALTER TABLE np_time_port
 ADD PRIMARY KEY (np_ref)
/


-- Triggers for NP_TIME_PORT

CREATE OR REPLACE TRIGGER np_time_port_trg1
BEFORE INSERT  OR UPDATE
ON np_time_port
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
    v_cnt1 NUMBER;
BEGIN
		IF INSERTING
		THEN
            SELECT COUNT(*)
            INTO v_cnt1
            FROM NP_TIME_PORT
            WHERE (np_ctn = :new.np_ctn and np_status = 'INIT');
            IF v_cnt1 != 0
            THEN
                  RAISE_APPLICATION_ERROR( -20001, 'CTN exists in pending state within the Porting Table' );
            END IF;

            SELECT	np_ref_seq.nextval
			INTO	:new.np_ref
			FROM 	dual;
		END IF;
	END;
/

-- End of DDL script for NP_TIME_PORT

-- Start of DDL script for PERFORMANCE_TEST
-- Generated 11-mar-03  10:54:13 am
-- from ernst-NINJA:6

-- Table PERFORMANCE_TEST

CREATE TABLE performance_test
 (
  thread_no                  NUMBER(3),
  subscriber_no              VARCHAR2(20),
  bean_start                 NUMBER(15),
  bean_end                   NUMBER(15),
  method_start               NUMBER(15),
  method_end                 NUMBER(15)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     106496
      NEXT        106496
      PCTINCREASE 0
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for PERFORMANCE_TEST

-- Start of DDL script for PERSISTING_DISCOUNTS
-- Generated 11-mar-03  10:54:13 am
-- from ernst-NINJA:6

-- Table PERSISTING_DISCOUNTS

CREATE TABLE persisting_discounts
 (
  discount_code              VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for PERSISTING_DISCOUNTS

-- Start of DDL script for PLAN_TABLE
-- Generated 11-mar-03  10:54:13 am
-- from ernst-NINJA:6

-- Table PLAN_TABLE

CREATE TABLE plan_table
 (
  statement_id               VARCHAR2(30),
  timestamp                  DATE,
  remarks                    VARCHAR2(80),
  operation                  VARCHAR2(30),
  options                    VARCHAR2(30),
  object_node                VARCHAR2(128),
  object_owner               VARCHAR2(30),
  object_name                VARCHAR2(30),
  object_instance            NUMBER(*,0),
  object_type                VARCHAR2(30),
  optimizer                  VARCHAR2(255),
  search_columns             NUMBER(*,0),
  id                         NUMBER(*,0),
  parent_id                  NUMBER(*,0),
  position                   NUMBER(*,0),
  other                      LONG
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for PLAN_TABLE

-- Start of DDL script for PP_CHANGE_REASON_CODES
-- Generated 11-mar-03  10:54:14 am
-- from ernst-NINJA:6

-- Table PP_CHANGE_REASON_CODES

CREATE TABLE pp_change_reason_codes
 (
  pp_from                    VARCHAR2(9) NOT NULL,
  pp_to                      VARCHAR2(9) NOT NULL,
  new_commitment             NUMBER(2) NOT NULL,
  reason_code                VARCHAR2(4) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     16384
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PP_CHANGE_REASON_CODES

COMMENT ON TABLE pp_change_reason_codes IS 'Contains the Reason Codes to be Used for Price Plan Changes'
/

-- Column Comments for PP_CHANGE_REASON_CODES

COMMENT ON COLUMN pp_change_reason_codes.new_commitment IS 'The Number of Months of Commitment for the new Price Plan'
/
COMMENT ON COLUMN pp_change_reason_codes.pp_from IS 'The Original Price Plan code of the subscriber'
/
COMMENT ON COLUMN pp_change_reason_codes.pp_to IS 'The New Price Plan for the Subscriber'
/
COMMENT ON COLUMN pp_change_reason_codes.reason_code IS 'The Reason Code to be used for the Change Priceplan'
/

-- Indexes for PP_CHANGE_REASON_CODES

CREATE  UNIQUE INDEX pp_chg_rsn_idx1
 ON pp_change_reason_codes
  ( pp_from,
    pp_to,
    new_commitment  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     16384
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for PP_CHANGE_REASON_CODES

-- Start of DDL script for PRICEPLANS
-- Generated 11-mar-03  10:54:14 am
-- from ernst-NINJA:6

-- Table PRICEPLANS

CREATE TABLE priceplans
 (
  priceplan_code             VARCHAR2(9) NOT NULL,
  priceplan_type             VARCHAR2(15) NOT NULL,
  priceplan_bill_type        VARCHAR2(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PRICEPLANS

COMMENT ON TABLE priceplans IS 'Holds all valid priceplan SOC''s'
/

-- Column Comments for PRICEPLANS

COMMENT ON COLUMN priceplans.priceplan_bill_type IS 'Indicates how the priceplan is invoiced. ''R''=Regular, ''C''=Kontroll and ''P''=Prepaid.'
/
COMMENT ON COLUMN priceplans.priceplan_code IS 'Priceplan SOC'
/
COMMENT ON COLUMN priceplans.priceplan_type IS 'Priceplan type. Valid values = ''GSM'', ''CDA'' and ''PBX'''
/

-- Indexes for PRICEPLANS

CREATE  INDEX priceplans_idx1
 ON priceplans
  ( priceplan_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for PRICEPLANS

ALTER TABLE priceplans
 ADD PRIMARY KEY (priceplan_code)
/

ALTER TABLE priceplans
 ADD CONSTRAINT priceplans_con102 FOREIGN KEY (priceplan_code)
      REFERENCES SOCS(soc)
/

ALTER TABLE priceplans
  ADD CONSTRAINT priceplans_con100 CHECK (priceplan_type IN ('CDA', 'GSM', 'PBX'))
/

ALTER TABLE priceplans
  ADD CONSTRAINT priceplans_con101 CHECK (priceplan_bill_type IN ('R', 'C', 'P'))
/


-- End of DDL script for PRICEPLANS

-- Start of DDL script for PRICEPLANS_DEALER_GROUPS
-- Generated 11-mar-03  10:54:15 am
-- from ernst-NINJA:6

-- Table PRICEPLANS_DEALER_GROUPS

CREATE TABLE priceplans_dealer_groups
 (
  priceplan_code             VARCHAR2(9) NOT NULL,
  dealer_group               VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PRICEPLANS_DEALER_GROUPS

COMMENT ON TABLE priceplans_dealer_groups IS 'Holds relation between priceplans and dealer groups'
/

-- Column Comments for PRICEPLANS_DEALER_GROUPS

COMMENT ON COLUMN priceplans_dealer_groups.dealer_group IS 'Foreign key column from DEALER_GROUPS'
/
COMMENT ON COLUMN priceplans_dealer_groups.priceplan_code IS 'Foreign key column from PRICEPLANS'
/

-- Indexes for PRICEPLANS_DEALER_GROUPS

CREATE  INDEX priceplans_dealer_groups_idx1
 ON priceplans_dealer_groups
  ( priceplan_code,
    dealer_group  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX priceplans_dealer_groups_idx2
 ON priceplans_dealer_groups
  ( dealer_group,
    priceplan_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for PRICEPLANS_DEALER_GROUPS

ALTER TABLE priceplans_dealer_groups
 ADD PRIMARY KEY (priceplan_code,dealer_group)
/

ALTER TABLE priceplans_dealer_groups
 ADD CONSTRAINT priceplans_dealer_groups_con1 FOREIGN KEY (priceplan_code)
      REFERENCES PRICEPLANS(priceplan_code)
/

ALTER TABLE priceplans_dealer_groups
 ADD CONSTRAINT priceplans_dealer_groups_con2 FOREIGN KEY (dealer_group)
      REFERENCES DEALER_GROUPS(dealer_group)
/


-- End of DDL script for PRICEPLANS_DEALER_GROUPS

-- Start of DDL script for PRICEPLAN_REPLACEMENTS
-- Generated 11-mar-03  10:54:15 am
-- from ernst-NINJA:6

-- Table PRICEPLAN_REPLACEMENTS

CREATE TABLE priceplan_replacements
 (
  org_priceplan              VARCHAR2(9) NOT NULL,
  new_priceplan              VARCHAR2(9) NOT NULL,
  org_soc                    VARCHAR2(9) NOT NULL,
  new_soc                    VARCHAR2(9) NOT NULL,
  replacement_mode           VARCHAR2(1) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     139264
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PRICEPLAN_REPLACEMENTS

COMMENT ON TABLE priceplan_replacements IS 'Contains the rules for the replacements of additional SOC''s, when the priceplan SOC is changed'
/

-- Column Comments for PRICEPLAN_REPLACEMENTS

COMMENT ON COLUMN priceplan_replacements.new_priceplan IS 'New priceplan SOC'
/
COMMENT ON COLUMN priceplan_replacements.new_soc IS 'SOC which will replace the original additional SOC'
/
COMMENT ON COLUMN priceplan_replacements.org_priceplan IS 'Original priceplan SOC'
/
COMMENT ON COLUMN priceplan_replacements.org_soc IS 'Original additional SOC'
/
COMMENT ON COLUMN priceplan_replacements.replacement_mode IS '''D''=Original SOC is deleted, ''R''=Original SOC is replaced by new SOC'
/

-- Indexes for PRICEPLAN_REPLACEMENTS

CREATE  INDEX priceplan_replacements_idx1
 ON priceplan_replacements
  ( org_priceplan,
    new_priceplan  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for PRICEPLAN_REPLACEMENTS

ALTER TABLE priceplan_replacements
 ADD PRIMARY KEY (org_priceplan,new_priceplan,org_soc,new_soc)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE priceplan_replacements
 ADD CONSTRAINT priceplan_replacements_con1 FOREIGN KEY (org_priceplan)
      REFERENCES PRICEPLANS(priceplan_code)
/

ALTER TABLE priceplan_replacements
 ADD CONSTRAINT priceplan_replacements_con2 FOREIGN KEY (new_priceplan)
      REFERENCES PRICEPLANS(priceplan_code)
/

ALTER TABLE priceplan_replacements
 ADD CONSTRAINT priceplan_replacements_con3 FOREIGN KEY (org_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE priceplan_replacements
 ADD CONSTRAINT priceplan_replacements_con4 FOREIGN KEY (new_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE priceplan_replacements
  ADD CONSTRAINT priceplan_replacements_con100 CHECK (replacement_mode IN ('D', 'R'))
/


-- Triggers for PRICEPLAN_REPLACEMENTS

CREATE OR REPLACE TRIGGER priceplan_replacements_trg1
BEFORE INSERT  OR UPDATE
ON priceplan_replacements
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
		v_cnt   NUMBER;
	BEGIN
		IF :new.org_priceplan = :new.new_priceplan
		THEN
			RAISE_APPLICATION_ERROR( -20001, 'ORG_PRICEPLAN and NEW_PRICEPLAN cannot be identical' );
		END IF;

		IF :new.org_soc = :new.new_soc
		THEN
			RAISE_APPLICATION_ERROR( -20001, 'ORG_SOC and NEW_SOC cannot be identical' );
		END IF;
	END;
/

-- End of DDL script for PRICEPLAN_REPLACEMENTS

-- Start of DDL script for PROCESSED_FEATURES
-- Generated 11-mar-03  10:54:16 am
-- from ernst-NINJA:6

-- Table PROCESSED_FEATURES

CREATE TABLE processed_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PROCESSED_FEATURES

COMMENT ON TABLE processed_features IS 'Holds features of successfully processed SOC''s'
/

-- Column Comments for PROCESSED_FEATURES

COMMENT ON COLUMN processed_features.feature_code IS 'SOC feature'
/
COMMENT ON COLUMN processed_features.trans_number IS 'Foreign key column from SERVICE_TRANSACTIONS table'
/

-- Constraints for PROCESSED_FEATURES

ALTER TABLE processed_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE processed_features
 ADD CONSTRAINT processed_features_con1 FOREIGN KEY (trans_number)
      REFERENCES SERVICE_TRANSACTIONS(trans_number)
/


-- End of DDL script for PROCESSED_FEATURES

-- Start of DDL script for PROCESSED_FEATURE_PARMS
-- Generated 11-mar-03  10:54:16 am
-- from ernst-NINJA:6

-- Table PROCESSED_FEATURE_PARMS

CREATE TABLE processed_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for PROCESSED_FEATURE_PARMS

COMMENT ON TABLE processed_feature_parms IS 'Holds feature parameter values'
/

-- Column Comments for PROCESSED_FEATURE_PARMS

COMMENT ON COLUMN processed_feature_parms.feature_code IS 'Foreign key column from PROCESSED_FEATURES table'
/
COMMENT ON COLUMN processed_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN processed_feature_parms.trans_number IS 'Foreign key column from PROCESSED_FEATURES table'
/
COMMENT ON COLUMN processed_feature_parms.value IS 'Value of parameter'
/

-- Constraints for PROCESSED_FEATURE_PARMS

ALTER TABLE processed_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE processed_feature_parms
 ADD CONSTRAINT processed_feature_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES PROCESSED_FEATURES(trans_number,feature_code)
/


-- End of DDL script for PROCESSED_FEATURE_PARMS

-- Start of DDL script for REASON_SEVERITY
-- Generated 11-mar-03  10:54:17 am
-- from ernst-NINJA:6

-- Table REASON_SEVERITY

CREATE TABLE reason_severity
 (
  status_avt_code            VARCHAR2(20) NOT NULL,
  status_avt_rsn_code        VARCHAR2(20) NOT NULL,
  neg                        VARCHAR2(10) NOT NULL,
  csa                        VARCHAR2(20),
  description                VARCHAR2(50)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for REASON_SEVERITY

COMMENT ON TABLE reason_severity IS 'Ninja reference table to hold Resaon Severity of CSM_STATUS_ACTIVITY records'
/

-- Column Comments for REASON_SEVERITY

COMMENT ON COLUMN reason_severity.neg IS 'Indicates if the Reason is Negative from a Credit Point of View'
/
COMMENT ON COLUMN reason_severity.status_avt_code IS 'CSA_ACTIVITY_CODE - Last Status Activity of the Ban/Subscriber'
/
COMMENT ON COLUMN reason_severity.status_avt_rsn_code IS 'CSA_ACTIVITY_RSN_CODE - Reason Code used for the Last Status Change Activity'
/

-- Indexes for REASON_SEVERITY

CREATE  UNIQUE INDEX reason_severity_idx1
 ON reason_severity
  ( status_avt_code,
    status_avt_rsn_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for REASON_SEVERITY

-- Start of DDL script for RESERVED_NUMBERS
-- Generated 11-mar-03  10:54:17 am
-- from ernst-NINJA:6

-- Table RESERVED_NUMBERS

CREATE TABLE reserved_numbers
 (
  ctn                        VARCHAR2(20) NOT NULL,
  dealer_code                VARCHAR2(5) NOT NULL,
  reserved_date              DATE NOT NULL,
  no_of_days_reserved        NUMBER(3) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     245760
      NEXT        106496
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for RESERVED_NUMBERS

COMMENT ON TABLE reserved_numbers IS 'Holds all number currently reserved by dealers'
/

-- Column Comments for RESERVED_NUMBERS

COMMENT ON COLUMN reserved_numbers.ctn IS 'Number which is reserved'
/
COMMENT ON COLUMN reserved_numbers.dealer_code IS 'Foreign key column from DEALERS'
/
COMMENT ON COLUMN reserved_numbers.no_of_days_reserved IS 'Number of days where number is to be reserved'
/
COMMENT ON COLUMN reserved_numbers.reserved_date IS 'Date when number was reserved'
/

-- Indexes for RESERVED_NUMBERS

CREATE  INDEX reserved_numbers_idx1
 ON reserved_numbers
  ( dealer_code,
    ctn  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX reserved_numbers_idx2
 ON reserved_numbers
  ( ctn,
    dealer_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for RESERVED_NUMBERS

ALTER TABLE reserved_numbers
 ADD PRIMARY KEY (ctn)
/

ALTER TABLE reserved_numbers
 ADD CONSTRAINT reserved_numbers_con1 FOREIGN KEY (dealer_code)
      REFERENCES DEALERS(dealer_code)
/


-- End of DDL script for RESERVED_NUMBERS

-- Start of DDL script for RESPONSE_RECORDS
-- Generated 11-mar-03  10:54:18 am
-- from ernst-NINJA:6

-- Table RESPONSE_RECORDS

CREATE TABLE response_records
 (
  request_id                 NUMBER(9) NOT NULL,
  enrollment_status          VARCHAR2(1) NOT NULL,
  reason_code                VARCHAR2(15),
  message                    VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for RESPONSE_RECORDS

COMMENT ON TABLE response_records IS 'Holds information about the response records.'
/

-- Column Comments for RESPONSE_RECORDS

COMMENT ON COLUMN response_records.enrollment_status IS 'Status of request. Valid values: ''A''=Request accepted and ''N''=Request rejected.'
/
COMMENT ON COLUMN response_records.message IS 'Free text describing the reason for rejection.'
/
COMMENT ON COLUMN response_records.reason_code IS 'Reason code if request is rejected.'
/
COMMENT ON COLUMN response_records.request_id IS 'Foreign key column from table BBS_RECORDS.'
/

-- Constraints for RESPONSE_RECORDS

ALTER TABLE response_records
 ADD PRIMARY KEY (request_id)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     98304
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE response_records
 ADD CONSTRAINT response_records_con1 FOREIGN KEY (request_id)
      REFERENCES BBS_RECORDS(request_id)
/

ALTER TABLE response_records
  ADD CONSTRAINT response_records100 CHECK (enrollment_status IN ('A', 'N'))
/


-- End of DDL script for RESPONSE_RECORDS

-- Start of DDL script for SERVICE_PROVIDERS
-- Generated 11-mar-03  10:54:18 am
-- from ernst-NINJA:6

-- Table SERVICE_PROVIDERS

CREATE TABLE service_providers
 (
  service_provider_code      VARCHAR2(15) NOT NULL,
  root_ban                   NUMBER(9) NOT NULL,
  current_active_ban         NUMBER(9) NOT NULL,
  max_subscriptions          NUMBER(4) NOT NULL,
  dealer_code                VARCHAR2(5) NOT NULL,
  nl_code                    VARCHAR2(3) NOT NULL,
  short_name                 VARCHAR2(1) NOT NULL,
  language_code              VARCHAR2(3),
  ban_sub_type               VARCHAR2(2),
  operator_code              VARCHAR2(3),
  last_business_name         VARCHAR2(61),
  first_name                 VARCHAR2(33),
  adr_country                VARCHAR2(4),
  adr_zip                    VARCHAR2(10),
  adr_street_name            VARCHAR2(61),
  adr_city                   VARCHAR2(40),
  adr_house_letter           VARCHAR2(3),
  adr_house_no               VARCHAR2(21),
  adr_door_no                VARCHAR2(5),
  adr_story                  VARCHAR2(3),
  adr_email                  VARCHAR2(151)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SERVICE_PROVIDERS

COMMENT ON TABLE service_providers IS 'Holds information of all valid service providers'
/

-- Column Comments for SERVICE_PROVIDERS

COMMENT ON COLUMN service_providers.adr_city IS 'SP City'
/
COMMENT ON COLUMN service_providers.adr_country IS 'SP Country'
/
COMMENT ON COLUMN service_providers.adr_door_no IS 'SP Door No'
/
COMMENT ON COLUMN service_providers.adr_email IS 'SP Email'
/
COMMENT ON COLUMN service_providers.adr_house_letter IS 'SP House Letter'
/
COMMENT ON COLUMN service_providers.adr_house_no IS 'SP House Number'
/
COMMENT ON COLUMN service_providers.adr_story IS 'SP Floor No'
/
COMMENT ON COLUMN service_providers.adr_street_name IS 'SP Street Name'
/
COMMENT ON COLUMN service_providers.adr_zip IS 'SP Zip'
/
COMMENT ON COLUMN service_providers.ban_sub_type IS 'Specifies the BAN Sub Type for the Service Provider'
/
COMMENT ON COLUMN service_providers.current_active_ban IS 'BAN where subscriptions of the service provider is currently added'
/
COMMENT ON COLUMN service_providers.dealer_code IS 'Service providers dealer code in Fokus'
/
COMMENT ON COLUMN service_providers.first_name IS 'SP First Name'
/
COMMENT ON COLUMN service_providers.language_code IS 'Specifies the language used by the service provider'
/
COMMENT ON COLUMN service_providers.last_business_name IS 'SP Last Name'
/
COMMENT ON COLUMN service_providers.max_subscriptions IS 'Maximum number of subscriptions per BAN'
/
COMMENT ON COLUMN service_providers.nl_code IS 'Service providers number location code in Fokus'
/
COMMENT ON COLUMN service_providers.operator_code IS 'Specifies the NP Operator Code of the SP'
/
COMMENT ON COLUMN service_providers.root_ban IS 'Service providers root BAN in Fokus'
/
COMMENT ON COLUMN service_providers.service_provider_code IS 'Unique code identifying the service provider'
/
COMMENT ON COLUMN service_providers.short_name IS 'Service providers short name'
/

-- Indexes for SERVICE_PROVIDERS

CREATE  INDEX service_providers_idx1
 ON service_providers
  ( service_provider_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SERVICE_PROVIDERS

ALTER TABLE service_providers
 ADD PRIMARY KEY (service_provider_code)
/

ALTER TABLE service_providers
 ADD CONSTRAINT service_providers_con1 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- End of DDL script for SERVICE_PROVIDERS

-- Start of DDL script for SERVICE_TRANSACTIONS
-- Generated 11-mar-03  10:54:19 am
-- from ernst-NINJA:6

-- Table SERVICE_TRANSACTIONS

CREATE TABLE service_transactions
 (
  trans_number               NUMBER(9) NOT NULL,
  subscriber_no              VARCHAR2(20) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action_code                VARCHAR2(15) NOT NULL,
  enter_time                 DATE NOT NULL,
  request_time               DATE NOT NULL,
  process_time               DATE,
  process_status             VARCHAR2(15) NOT NULL,
  status_desc                VARCHAR2(300),
  dealer_code                VARCHAR2(5),
  sales_agent                VARCHAR2(5),
  priority                   NUMBER(1) NOT NULL,
  success_msg_id             NUMBER(6),
  error_msg_id               NUMBER(6),
  msg_status_desc            VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        10485760
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SERVICE_TRANSACTIONS

COMMENT ON TABLE service_transactions IS 'Holds SOC transactions (add/modify/delete) to be processed by the ServiceManipulationClient'
/

-- Column Comments for SERVICE_TRANSACTIONS

COMMENT ON COLUMN service_transactions.action_code IS 'Code specifying the transaction type. Valid values: ADD, MODIFY and DELETE'
/
COMMENT ON COLUMN service_transactions.enter_time IS 'Time when row was inserted into this table. Automatically generated value'
/
COMMENT ON COLUMN service_transactions.error_msg_id IS 'SMS message to be send if an error ocurred during processing.'
/
COMMENT ON COLUMN service_transactions.msg_status_desc IS 'NULL if the SMS message was sent successfully. Otherwise contains an error message.'
/
COMMENT ON COLUMN service_transactions.priority IS 'Transaction priority. Value from 1 to 5 where 1 is highest priority.'
/
COMMENT ON COLUMN service_transactions.process_status IS 'Process status. Valid values: WAITING, IN_PROGRESS, PRSD_SUCCESS, PRSD_ERROR and PRSD_FATAL'
/
COMMENT ON COLUMN service_transactions.process_time IS 'Time when service request was processed'
/
COMMENT ON COLUMN service_transactions.request_time IS 'Time when transaction must be processed. Defaults to value in NETER_TIME column'
/
COMMENT ON COLUMN service_transactions.soc IS 'SOC which needs to be Added/modified/deleted'
/
COMMENT ON COLUMN service_transactions.status_desc IS 'Error message'
/
COMMENT ON COLUMN service_transactions.subscriber_no IS 'Subscriber where the transaction must be carried out'
/
COMMENT ON COLUMN service_transactions.success_msg_id IS 'SMS message to be send if transaction was processed successfully.'
/
COMMENT ON COLUMN service_transactions.trans_number IS 'Unique transaction number.'
/

-- Indexes for SERVICE_TRANSACTIONS

CREATE  INDEX service_transactions_idx1
 ON service_transactions
  ( process_status,
    priority,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX service_transactions_idx2
 ON service_transactions
  ( subscriber_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX service_transactions_idx3
 ON service_transactions
  ( subscriber_no,
    enter_time  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        8724480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for SERVICE_TRANSACTIONS

ALTER TABLE service_transactions
 ADD PRIMARY KEY (trans_number)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE service_transactions
  ADD CONSTRAINT service_transactions100 CHECK ( action_code IN ('ADD', 'MODIFY', 'DELETE'))
/

ALTER TABLE service_transactions
  ADD CONSTRAINT service_transactions101 CHECK ( process_status IN ('WAITING', 'IN_PROGRESS', 'PRSD_SUCCESS', 'PRSD_ERROR', 'PRSD_FATAL'))
/

ALTER TABLE service_transactions
  ADD CONSTRAINT service_transactions102 CHECK ( priority BETWEEN 1 AND 5 )
/


-- Triggers for SERVICE_TRANSACTIONS

CREATE OR REPLACE TRIGGER service_transactions_trg1
BEFORE INSERT
ON service_transactions
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
  v_success_count     NUMBER DEFAULT 0;
        v_error_count       NUMBER DEFAULT 0;

 BEGIN
  IF INSERTING
  THEN
            -- Set enter time. And if request time is not set, then set it to enter time
   SELECT sysdate
   INTO :new.enter_time
   FROM dual;

   IF :new.request_time IS NULL
   THEN
    :new.request_time := :new.enter_time;
   END IF;

            -- Make sure that we have valid values in the SMS message columns
            IF :new.success_msg_id IS NOT NULL
            THEN
                SELECT  COUNT(*)
                INTO    v_success_count
                FROM    sms_messages
                WHERE   msg_id = :new.success_msg_id;

                IF v_success_count < 1
                THEN
                    RAISE_APPLICATION_ERROR( -20001, 'SUCCESS_MSG_ID in not defined in SMS_MESSAGES.' );
                END IF;
            END IF;

            IF :new.success_msg_id is not null
            THEN
                SELECT  COUNT(*)
                INTO    v_error_count
                FROM    sms_messages
                WHERE   msg_id = :new.success_msg_id;

                IF v_error_count < 1
                THEN
                    RAISE_APPLICATION_ERROR( -20001, 'ERROR_MSG_ID in not defined in SMS_MESSAGES.' );
                END IF;

            END IF;

  END IF;
 END;
/

-- End of DDL script for SERVICE_TRANSACTIONS

-- Start of DDL script for SERVICE_TRAN_FEATURES
-- Generated 11-mar-03  10:54:20 am
-- from ernst-NINJA:6

-- Table SERVICE_TRAN_FEATURES

CREATE TABLE service_tran_features
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SERVICE_TRAN_FEATURES

COMMENT ON TABLE service_tran_features IS 'Holds features for SOC''s to be processed by the ServiceManipulationClient'
/

-- Column Comments for SERVICE_TRAN_FEATURES

COMMENT ON COLUMN service_tran_features.feature_code IS 'Feature code of SOC to be processed'
/
COMMENT ON COLUMN service_tran_features.trans_number IS 'Foreign key from SERVICE_TRANSACTIONS'
/

-- Constraints for SERVICE_TRAN_FEATURES

ALTER TABLE service_tran_features
 ADD PRIMARY KEY (trans_number,feature_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4227072
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE service_tran_features
 ADD CONSTRAINT service_tran_features_con1 FOREIGN KEY (trans_number)
      REFERENCES SERVICE_TRANSACTIONS(trans_number)
/


-- End of DDL script for SERVICE_TRAN_FEATURES

-- Start of DDL script for SERVICE_TRAN_FEATURE_PARMS
-- Generated 11-mar-03  10:54:20 am
-- from ernst-NINJA:6

-- Table SERVICE_TRAN_FEATURE_PARMS

CREATE TABLE service_tran_feature_parms
 (
  trans_number               NUMBER(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  parameter_code             VARCHAR2(15) NOT NULL,
  value                      VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     10485760
      NEXT        5242880
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SERVICE_TRAN_FEATURE_PARMS

COMMENT ON TABLE service_tran_feature_parms IS 'Holds feature parameter values'
/

-- Column Comments for SERVICE_TRAN_FEATURE_PARMS

COMMENT ON COLUMN service_tran_feature_parms.feature_code IS 'Foreign key column from SERVICE_TRAN_FEATURES table'
/
COMMENT ON COLUMN service_tran_feature_parms.parameter_code IS 'Parameter code'
/
COMMENT ON COLUMN service_tran_feature_parms.trans_number IS 'Foreign key column from SERVICE_TRAN_FEATURES table'
/
COMMENT ON COLUMN service_tran_feature_parms.value IS 'Value of parameter'
/

-- Constraints for SERVICE_TRAN_FEATURE_PARMS

ALTER TABLE service_tran_feature_parms
 ADD PRIMARY KEY (trans_number,feature_code,parameter_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     4259840
   NEXT        2097152
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE service_tran_feature_parms
 ADD CONSTRAINT service_tran_feat_parms_con1 FOREIGN KEY (trans_number,feature_code)
      REFERENCES SERVICE_TRAN_FEATURES(trans_number,feature_code)
/


-- End of DDL script for SERVICE_TRAN_FEATURE_PARMS

-- Start of DDL script for SMS_MESSAGES
-- Generated 11-mar-03  10:54:21 am
-- from ernst-NINJA:6

-- Table SMS_MESSAGES

CREATE TABLE sms_messages
 (
  msg_id                     NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL,
  from_ctn                   VARCHAR2(10) NOT NULL,
  msg_text                   VARCHAR2(200) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     106496
      NEXT        57344
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SMS_MESSAGES

COMMENT ON TABLE sms_messages IS 'Holds SMS messages.'
/

-- Column Comments for SMS_MESSAGES

COMMENT ON COLUMN sms_messages.from_ctn IS 'Originating CTN of this message.'
/
COMMENT ON COLUMN sms_messages.language_code IS 'Language code. Foreign key fromm LANGUAGES table.'
/
COMMENT ON COLUMN sms_messages.msg_id IS 'Message ID.'
/
COMMENT ON COLUMN sms_messages.msg_text IS 'SMS text. Valid bind variables: :DESC and :SPECIAL_TELNO.'
/

-- Constraints for SMS_MESSAGES

ALTER TABLE sms_messages
 ADD PRIMARY KEY (msg_id,language_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE sms_messages
 ADD CONSTRAINT sms_messages_con1 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- End of DDL script for SMS_MESSAGES

-- Start of DDL script for SOCS
-- Generated 11-mar-03  10:54:21 am
-- from ernst-NINJA:6

-- Table SOCS

CREATE TABLE socs
 (
  soc                        VARCHAR2(9) NOT NULL,
  soc_type                   VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS

COMMENT ON TABLE socs IS 'Holds all valid SOC''s'
/

-- Column Comments for SOCS

COMMENT ON COLUMN socs.soc IS 'SOC code'
/
COMMENT ON COLUMN socs.soc_type IS 'Valid values: ''F-AND-F'', ''VOICEMAIL'', ''DATA'', ''FAX'', ''SECRET'', ''OTHER'', ''GPRS'', ''WOFFICE'', ''CUGVPN'', ''PREPAY'', ''PRICEPLAN'''
/

-- Indexes for SOCS

CREATE  INDEX socs_idx1
 ON socs
  ( soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SOCS

ALTER TABLE socs
 ADD PRIMARY KEY (soc)
/

ALTER TABLE socs
  ADD CONSTRAINT socs_con100 CHECK (
soc_type IN     ( 'F-AND-F', 'VOICEMAIL', 'DATA', 'FAX', 'SECRET', 'OTHER', 'GPRS', 'WOFFICE', 'CUGVPN', 'PREPAY', 'PRICEPLAN' ))
/


-- End of DDL script for SOCS

-- Start of DDL script for SOCS_ARGS
-- Generated 11-mar-03  10:54:21 am
-- from ernst-NINJA:6

-- Table SOCS_ARGS

CREATE TABLE socs_args
 (
  argument                   VARCHAR2(30) NOT NULL,
  priceplan_code             VARCHAR2(9) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action                     VARCHAR2(15) NOT NULL,
  success_sms_id             NUMBER(6),
  error_sms_id               NUMBER(6),
  effective_date             DATE NOT NULL,
  expiration_date            DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS_ARGS

COMMENT ON TABLE socs_args IS 'Holds the reference between the argument specified by the KONTANT system and the SOC which is involved in the transaction.'
/

-- Column Comments for SOCS_ARGS

COMMENT ON COLUMN socs_args.action IS 'Action performend on request. Valid values: ''ADD_SERVICE'' and ''ROBOT_1''.'
/
COMMENT ON COLUMN socs_args.argument IS 'Argument specified by KONTANT system.'
/
COMMENT ON COLUMN socs_args.effective_date IS 'Date when this relation is effective from.'
/
COMMENT ON COLUMN socs_args.error_sms_id IS 'ID of SMS to be sent upon un-successful completion.'
/
COMMENT ON COLUMN socs_args.expiration_date IS 'Date when this relation expires.'
/
COMMENT ON COLUMN socs_args.priceplan_code IS 'Priceplan of subscription.'
/
COMMENT ON COLUMN socs_args.soc IS 'SOC code which relates to the argument.'
/
COMMENT ON COLUMN socs_args.success_sms_id IS 'ID of SMS to be sent upon successful completion.'
/

-- Constraints for SOCS_ARGS

ALTER TABLE socs_args
 ADD PRIMARY KEY (argument,priceplan_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

ALTER TABLE socs_args
  ADD CONSTRAINT socs_args101 CHECK ( action IN ('ADD_SERVICE', 'ROBOT_1'))
/


-- End of DDL script for SOCS_ARGS

-- Start of DDL script for SOCS_DEALER_GROUPS
-- Generated 11-mar-03  10:54:22 am
-- from ernst-NINJA:6

-- Table SOCS_DEALER_GROUPS

CREATE TABLE socs_dealer_groups
 (
  soc                        VARCHAR2(9) NOT NULL,
  dealer_group               VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS_DEALER_GROUPS

COMMENT ON TABLE socs_dealer_groups IS 'Holds relation between socs and dealer groups'
/

-- Column Comments for SOCS_DEALER_GROUPS

COMMENT ON COLUMN socs_dealer_groups.dealer_group IS 'Foreign key column from DEALER_GROUPS'
/
COMMENT ON COLUMN socs_dealer_groups.soc IS 'Foreign key column from SOC'
/

-- Indexes for SOCS_DEALER_GROUPS

CREATE  INDEX socs_dealer_groups_idx1
 ON socs_dealer_groups
  ( soc,
    dealer_group  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     49152
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX socs_dealer_groups_idx2
 ON socs_dealer_groups
  ( dealer_group,
    soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     49152
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SOCS_DEALER_GROUPS

ALTER TABLE socs_dealer_groups
 ADD PRIMARY KEY (soc,dealer_group)
/

ALTER TABLE socs_dealer_groups
 ADD CONSTRAINT socs_dealer_groups_con1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE socs_dealer_groups
 ADD CONSTRAINT socs_dealer_groups_con2 FOREIGN KEY (dealer_group)
      REFERENCES DEALER_GROUPS(dealer_group)
/


-- End of DDL script for SOCS_DEALER_GROUPS

-- Start of DDL script for SOCS_FEATURES
-- Generated 11-mar-03  10:54:22 am
-- from ernst-NINJA:6

-- Table SOCS_FEATURES

CREATE TABLE socs_features
 (
  soc                        VARCHAR2(9) NOT NULL,
  feature_code               VARCHAR2(6) NOT NULL,
  feature_type               VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS_FEATURES

COMMENT ON TABLE socs_features IS 'Holds all valid features for each SOC'
/

-- Column Comments for SOCS_FEATURES

COMMENT ON COLUMN socs_features.feature_code IS 'Foreign key column from FEATURES'
/
COMMENT ON COLUMN socs_features.feature_type IS 'Feature type. Valid values: ''F-AND-F'', ''MMS'', ''REGULAR'', ''GPRS'', ''CUGVPN'' and ''NINJA'''
/
COMMENT ON COLUMN socs_features.soc IS 'Foreign key columns from SOCS'
/

-- Indexes for SOCS_FEATURES

CREATE  INDEX features_idx1
 ON socs_features
  ( feature_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX socs_features_idx1
 ON socs_features
  ( soc,
    feature_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX socs_features_idx2
 ON socs_features
  ( feature_code,
    soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SOCS_FEATURES

ALTER TABLE socs_features
 ADD PRIMARY KEY (soc,feature_code)
/

ALTER TABLE socs_features
 ADD CONSTRAINT socs_features_con1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE socs_features
 ADD CONSTRAINT socs_features_con2 FOREIGN KEY (feature_code)
      REFERENCES FEATURES(feature_code)
/

ALTER TABLE socs_features
  ADD CONSTRAINT socs_features100 CHECK (
feature_type IN ('F-AND-F', 'MMS', 'REGULAR', 'GPRS', 'CUGVPN', 'NINJA'))
/


-- End of DDL script for SOCS_FEATURES

-- Start of DDL script for SOCS_SMS_MESSAGES
-- Generated 11-mar-03  10:54:23 am
-- from ernst-NINJA:6

-- Table SOCS_SMS_MESSAGES

CREATE TABLE socs_sms_messages
 (
  soc                        VARCHAR2(9) NOT NULL,
  action_code                VARCHAR2(15) NOT NULL,
  success_msg_id             NUMBER(6),
  error_msg_id               NUMBER(6)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     106496
      NEXT        57344
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS_SMS_MESSAGES

COMMENT ON TABLE socs_sms_messages IS 'Holds SMS ID of the SMS messages to be sent by the service manipulator.'
/

-- Column Comments for SOCS_SMS_MESSAGES

COMMENT ON COLUMN socs_sms_messages.action_code IS 'Action performed on SOC'
/
COMMENT ON COLUMN socs_sms_messages.error_msg_id IS 'ID of SMS message sent upon unsuccessful completion'
/
COMMENT ON COLUMN socs_sms_messages.soc IS 'SOC involved in the transction.'
/
COMMENT ON COLUMN socs_sms_messages.success_msg_id IS 'ID of SMS message sent upon successful completion'
/

-- Constraints for SOCS_SMS_MESSAGES

ALTER TABLE socs_sms_messages
 ADD PRIMARY KEY (soc,action_code)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/


-- End of DDL script for SOCS_SMS_MESSAGES

-- Start of DDL script for SOCS_SOC_DESCRIPTIONS
-- Generated 11-mar-03  10:54:23 am
-- from ernst-NINJA:6

-- Table SOCS_SOC_DESCRIPTIONS

CREATE TABLE socs_soc_descriptions
 (
  soc                        VARCHAR2(9) NOT NULL,
  soc_name_id                NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOCS_SOC_DESCRIPTIONS

COMMENT ON TABLE socs_soc_descriptions IS 'Holds relations between SOC''s and their descriptions'
/

-- Column Comments for SOCS_SOC_DESCRIPTIONS

COMMENT ON COLUMN socs_soc_descriptions.soc IS 'Foreign key column from SOC'
/
COMMENT ON COLUMN socs_soc_descriptions.soc_name_id IS 'Foreign key column from SOC_DESCRIPTIONS'
/

-- Indexes for SOCS_SOC_DESCRIPTIONS

CREATE  INDEX socs_soc_descriptions_idx1
 ON socs_soc_descriptions
  ( soc,
    soc_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     81920
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SOCS_SOC_DESCRIPTIONS

ALTER TABLE socs_soc_descriptions
 ADD PRIMARY KEY (soc,soc_name_id,language_code)
/

ALTER TABLE socs_soc_descriptions
 ADD CONSTRAINT socs_soc_descriptions_con1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE socs_soc_descriptions
 ADD CONSTRAINT socs_soc_descriptions_con2 FOREIGN KEY (soc_name_id,language_code)
      REFERENCES SOC_DESCRIPTIONS(soc_name_id,language_code)
/


-- End of DDL script for SOCS_SOC_DESCRIPTIONS

-- Start of DDL script for SOC_DESCRIPTIONS
-- Generated 11-mar-03  10:54:24 am
-- from ernst-NINJA:6

-- Table SOC_DESCRIPTIONS

CREATE TABLE soc_descriptions
 (
  soc_name_id                NUMBER(6) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SOC_DESCRIPTIONS

COMMENT ON TABLE soc_descriptions IS 'Holds SOC descriptions'
/

-- Column Comments for SOC_DESCRIPTIONS

COMMENT ON COLUMN soc_descriptions.description IS 'SOC description text'
/
COMMENT ON COLUMN soc_descriptions.language_code IS 'Foreign key column from LANGUAGES'
/
COMMENT ON COLUMN soc_descriptions.soc_name_id IS 'Unique number identifying the description. Generated automatically on insert'
/

-- Indexes for SOC_DESCRIPTIONS

CREATE  INDEX soc_descriptions_idx1
 ON soc_descriptions
  ( soc_name_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SOC_DESCRIPTIONS

ALTER TABLE soc_descriptions
 ADD PRIMARY KEY (soc_name_id,language_code)
/

ALTER TABLE soc_descriptions
 ADD CONSTRAINT soc_descriptions_con2 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- Triggers for SOC_DESCRIPTIONS

CREATE OR REPLACE TRIGGER soc_descriptions_trg1
BEFORE INSERT
ON soc_descriptions
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
		SELECT	soc_name_id_seq.nextval
		INTO	:new.soc_name_id
		FROM	dual;
	END;
/

-- End of DDL script for SOC_DESCRIPTIONS

-- Start of DDL script for SPECIAL_PROMOTIONS
-- Generated 11-mar-03  10:54:25 am
-- from ernst-NINJA:6

-- Table SPECIAL_PROMOTIONS

CREATE TABLE special_promotions
 (
  soc                        VARCHAR2(9) NOT NULL,
  promotion_soc              VARCHAR2(9) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     16384
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for SPECIAL_PROMOTIONS

COMMENT ON TABLE special_promotions IS 'Holds relations between SOC and their special promotiona SOCs'
/

-- Column Comments for SPECIAL_PROMOTIONS

COMMENT ON COLUMN special_promotions.promotion_soc IS 'Promotional SOC'
/
COMMENT ON COLUMN special_promotions.soc IS 'Foreign key column from SOCS'
/

-- Constraints for SPECIAL_PROMOTIONS

ALTER TABLE special_promotions
 ADD PRIMARY KEY (soc)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

ALTER TABLE special_promotions
 ADD CONSTRAINT special_promotions_con1 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE special_promotions
 ADD CONSTRAINT special_promotions_con2 FOREIGN KEY (promotion_soc)
      REFERENCES SOCS(soc)
/


-- End of DDL script for SPECIAL_PROMOTIONS

-- Start of DDL script for SUBSCRIPTION_TYPES
-- Generated 11-mar-03  10:54:25 am
-- from ernst-NINJA:6

-- Table SUBSCRIPTION_TYPES

CREATE TABLE subscription_types
 (
  subscription_type_id       VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SUBSCRIPTION_TYPES

COMMENT ON TABLE subscription_types IS 'Holds subscription type codes'
/

-- Column Comments for SUBSCRIPTION_TYPES

COMMENT ON COLUMN subscription_types.subscription_type_id IS 'Unique code to identify a subscription type'
/

-- Indexes for SUBSCRIPTION_TYPES

CREATE  INDEX subscription_types_idx1
 ON subscription_types
  ( subscription_type_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SUBSCRIPTION_TYPES

ALTER TABLE subscription_types
 ADD PRIMARY KEY (subscription_type_id)
/


-- End of DDL script for SUBSCRIPTION_TYPES

-- Start of DDL script for SUBSCRIPTION_TYPES_SOCS
-- Generated 11-mar-03  10:54:26 am
-- from ernst-NINJA:6

-- Table SUBSCRIPTION_TYPES_SOCS

CREATE TABLE subscription_types_socs
 (
  subscription_type_id       VARCHAR2(15) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  effective_date             DATE NOT NULL,
  expiration_date            DATE,
  displayable                VARCHAR2(1) NOT NULL,
  add_mode                   VARCHAR2(1) NOT NULL,
  modify_mode                VARCHAR2(1) NOT NULL,
  delete_mode                VARCHAR2(1) NOT NULL,
  ninja_mode_activate        VARCHAR2(1),
  ninja_mode_change          VARCHAR2(1),
  ninja_mode_delete          VARCHAR2(1),
  ninja_replacement_soc      VARCHAR2(9),
  overidden_by_soc           VARCHAR2(9),
  additionally_adds_soc      VARCHAR2(9)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     163840
      NEXT        57344
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SUBSCRIPTION_TYPES_SOCS

COMMENT ON TABLE subscription_types_socs IS 'Contains all additional SOC''s available for each subscription type'
/

-- Column Comments for SUBSCRIPTION_TYPES_SOCS

COMMENT ON COLUMN subscription_types_socs.additionally_adds_soc IS 'Soc that will be added if the soc is added by Ninja.'
/
COMMENT ON COLUMN subscription_types_socs.add_mode IS '''A''=Automatic add by Ninja. (refers to rules in Fokus)   ''N''=No additions allowed. ''O''=SOC can be added by end-user. ''R''=Addition referred to CS'
/
COMMENT ON COLUMN subscription_types_socs.delete_mode IS '''Y''=Manual delete by end-user allowed. ''N''=No deletion allowed. ''R''=Deletions is referred to CS.'
/
COMMENT ON COLUMN subscription_types_socs.displayable IS '(Y/N) Is the SOC displayable to the end-user'
/
COMMENT ON COLUMN subscription_types_socs.effective_date IS 'First day when relation is active'
/
COMMENT ON COLUMN subscription_types_socs.expiration_date IS 'Last day when relation is active'
/
COMMENT ON COLUMN subscription_types_socs.modify_mode IS '''Y''=Manual modification by end-user allowed. ''N''=No modifications allowed. ''R''=Modifications referred to CS'
/
COMMENT ON COLUMN subscription_types_socs.ninja_mode_activate IS '''M'' - Added By Ninja if a coexisting Soc hasn''t been chosen'
/
COMMENT ON COLUMN subscription_types_socs.ninja_mode_change IS '''Y'' - Ninja is able to add this Soc'
/
COMMENT ON COLUMN subscription_types_socs.ninja_mode_delete IS '''Y'' - Ninja is able to Delete This Soc'
/
COMMENT ON COLUMN subscription_types_socs.ninja_replacement_soc IS 'Soc that Ninja will replace with during a clean of Subscription'
/
COMMENT ON COLUMN subscription_types_socs.overidden_by_soc IS 'Soc that will overide the addition of this Soc by Ninja'
/
COMMENT ON COLUMN subscription_types_socs.soc IS 'Foreign key column from SOCS'
/
COMMENT ON COLUMN subscription_types_socs.subscription_type_id IS 'Foreign key column from SUBSCRIPTION_TYPES'
/

-- Indexes for SUBSCRIPTION_TYPES_SOCS

CREATE  INDEX subscription_types_socs_idx1
 ON subscription_types_socs
  ( subscription_type_id,
    soc  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     114688
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

CREATE  INDEX subscription_types_socs_idx2
 ON subscription_types_socs
  ( soc,
    subscription_type_id  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     98304
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SUBSCRIPTION_TYPES_SOCS

ALTER TABLE subscription_types_socs
 ADD PRIMARY KEY (subscription_type_id,soc)
/

ALTER TABLE subscription_types_socs
 ADD CONSTRAINT subscription_types_socs_con1 FOREIGN KEY (subscription_type_id)
      REFERENCES SUBSCRIPTION_TYPES(subscription_type_id)
/

ALTER TABLE subscription_types_socs
 ADD CONSTRAINT subscription_types_socs_con2 FOREIGN KEY (soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE subscription_types_socs
 ADD CONSTRAINT subscription_types_socs_con3 FOREIGN KEY (ninja_replacement_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE subscription_types_socs
 ADD CONSTRAINT subscription_types_socs_con4 FOREIGN KEY (overidden_by_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE subscription_types_socs
 ADD CONSTRAINT subscription_types_socs_con5 FOREIGN KEY (additionally_adds_soc)
      REFERENCES SOCS(soc)
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con100 CHECK (displayable IN ('Y', 'N'))
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con101 CHECK ( add_mode IN ('A', 'N', 'O', 'R')  )
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con102 CHECK (modify_mode IN ('Y', 'N', 'R'))
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con103 CHECK (delete_mode IN ('Y', 'N', 'R'))
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con104 CHECK ( ninja_mode_activate IN ('M','A')  )
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con105 CHECK ( ninja_mode_change IN ('Y')  )
/

ALTER TABLE subscription_types_socs
  ADD CONSTRAINT subscription_types_socs_con106 CHECK ( ninja_mode_delete IN ('Y')  )
/


-- Triggers for SUBSCRIPTION_TYPES_SOCS

CREATE OR REPLACE TRIGGER subscription_types_socs_trg1
BEFORE INSERT  OR UPDATE
ON subscription_types_socs
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN

		IF :new.effective_date IS NOT NULL
		THEN
			:new.effective_date := TRUNC(:new.effective_date);
		END IF;

		IF :new.expiration_date IS NOT NULL
		THEN
			:new.expiration_date := TRUNC(:new.expiration_date);
		END IF;
	END;
/

-- End of DDL script for SUBSCRIPTION_TYPES_SOCS

-- Start of DDL script for SUBSCRIPTION_TYPE_DESC
-- Generated 11-mar-03  10:54:27 am
-- from ernst-NINJA:6

-- Table SUBSCRIPTION_TYPE_DESC

CREATE TABLE subscription_type_desc
 (
  subscription_type_id       VARCHAR2(15) NOT NULL,
  language_code              VARCHAR2(3) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SUBSCRIPTION_TYPE_DESC

COMMENT ON TABLE subscription_type_desc IS 'Holds the text descriptions of the different subscription types'
/

-- Column Comments for SUBSCRIPTION_TYPE_DESC

COMMENT ON COLUMN subscription_type_desc.description IS 'Description text'
/
COMMENT ON COLUMN subscription_type_desc.language_code IS 'Foreign key column from LANGUAGES'
/
COMMENT ON COLUMN subscription_type_desc.subscription_type_id IS 'Foreign key column from SUBSCRIPTION_TYPES'
/

-- Indexes for SUBSCRIPTION_TYPE_DESC

CREATE  INDEX subscription_type_desc_idx1
 ON subscription_type_desc
  ( subscription_type_id,
    language_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SUBSCRIPTION_TYPE_DESC

ALTER TABLE subscription_type_desc
 ADD PRIMARY KEY (subscription_type_id,language_code)
/

ALTER TABLE subscription_type_desc
 ADD CONSTRAINT subscription_type_desc_con1 FOREIGN KEY (subscription_type_id)
      REFERENCES SUBSCRIPTION_TYPES(subscription_type_id)
/

ALTER TABLE subscription_type_desc
 ADD CONSTRAINT subscription_type_desc_con2 FOREIGN KEY (language_code)
      REFERENCES LANGUAGES(language_code)
/


-- End of DDL script for SUBSCRIPTION_TYPE_DESC

-- Start of DDL script for SYSTEM_DEFAULTS
-- Generated 11-mar-03  10:54:27 am
-- from ernst-NINJA:6

-- Table SYSTEM_DEFAULTS

CREATE TABLE system_defaults
 (
  key                        VARCHAR2(50) NOT NULL,
  value                      VARCHAR2(500),
  value_type                 VARCHAR2(7) NOT NULL,
  description                VARCHAR2(100)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     24576
      NEXT        8192
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for SYSTEM_DEFAULTS

COMMENT ON TABLE system_defaults IS 'Default system settings. Works like a hashtable!!!'
/

-- Column Comments for SYSTEM_DEFAULTS

COMMENT ON COLUMN system_defaults.description IS 'Description of the default setting/value'
/
COMMENT ON COLUMN system_defaults.key IS 'Key, e.g. LANGUAGE'
/
COMMENT ON COLUMN system_defaults.value IS 'Value, e.g. ENG or NOR'
/
COMMENT ON COLUMN system_defaults.value_type IS 'Type of the contents of the VALUE column. Valid values: ''STRING'', ''INTEGER'', ''FLOAT'' and ''BYTE'''
/

-- Indexes for SYSTEM_DEFAULTS

CREATE  INDEX system_defaults_idx1
 ON system_defaults
  ( key  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     32768
   NEXT        16384
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- Constraints for SYSTEM_DEFAULTS

ALTER TABLE system_defaults
 ADD PRIMARY KEY (key)
/

ALTER TABLE system_defaults
  ADD CONSTRAINT system_defaults_con100 CHECK (value_type IN ('STRING', 'INTEGER', 'FLOAT'))
/


-- End of DDL script for SYSTEM_DEFAULTS

-- Start of DDL script for TACS_X_HANDSETS
-- Generated 11-mar-03  10:54:28 am
-- from ernst-NINJA:6

-- Table TACS_X_HANDSETS

CREATE TABLE tacs_x_handsets
 (
  tac                        VARCHAR2(6) NOT NULL,
  item_id                    VARCHAR2(15) NOT NULL,
  ninja_operation            VARCHAR2(5) NOT NULL,
  new_commit_months          NUMBER(2) NOT NULL,
  provisioning_code          NUMBER(5) NOT NULL,
  effective_date             DATE NOT NULL,
  expiration_date            DATE NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     20971520
      NEXT        20971520
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- Comments for TACS_X_HANDSETS

COMMENT ON TABLE tacs_x_handsets IS 'Contains the List of Handsets Valid for the TAC '
/

-- Column Comments for TACS_X_HANDSETS

COMMENT ON COLUMN tacs_x_handsets.effective_date IS 'The Effective Date for this Combination'
/
COMMENT ON COLUMN tacs_x_handsets.expiration_date IS 'The Expiration Date for this combination'
/
COMMENT ON COLUMN tacs_x_handsets.item_id IS 'Valid ITEM_ID as defined in the Fokus ref tables ITEM_DEFINITION'
/
COMMENT ON COLUMN tacs_x_handsets.new_commit_months IS 'The number of months of new Commitment.'
/
COMMENT ON COLUMN tacs_x_handsets.ninja_operation IS 'The Operation (''ACTV'' , ''PPCHG'') - * - Wildcard for any operation.'
/
COMMENT ON COLUMN tacs_x_handsets.provisioning_code IS 'References The link table HANDSETS_X_PROVISION_SOC'
/
COMMENT ON COLUMN tacs_x_handsets.tac IS 'The First 6 digits of the IMEI - Known as the TAC'
/

-- Indexes for TACS_X_HANDSETS

CREATE  UNIQUE INDEX tacs_x_handsets_idx1
 ON tacs_x_handsets
  ( tac,
    item_id,
    provisioning_code  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     10485760
   NEXT        10485760
   PCTINCREASE 0
   MINEXTENTS  2
   MAXEXTENTS  500
   )
/

-- End of DDL script for TACS_X_HANDSETS

-- Start of DDL script for TALK2ME_TMP_LOAD
-- Generated 11-mar-03  10:54:28 am
-- from ernst-NINJA:6

-- Table TALK2ME_TMP_LOAD

CREATE TABLE talk2me_tmp_load
 (
  subscriber_no              VARCHAR2(20),
  col_b                      VARCHAR2(60),
  col_c                      VARCHAR2(60),
  col_d                      VARCHAR2(60),
  col_e                      VARCHAR2(60),
  col_f                      VARCHAR2(60),
  col_g                      VARCHAR2(60),
  col_h                      VARCHAR2(60),
  col_i                      VARCHAR2(60),
  col_j                      VARCHAR2(60),
  col_k                      VARCHAR2(60),
  col_l                      VARCHAR2(60),
  col_m                      VARCHAR2(60),
  col_n                      VARCHAR2(60),
  col_o                      VARCHAR2(60),
  col_p                      VARCHAR2(60),
  col_q                      VARCHAR2(60),
  col_r                      VARCHAR2(60)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for TALK2ME_TMP_LOAD

COMMENT ON TABLE talk2me_tmp_load IS 'Temporary Load table for talk 2 me response files'
/

-- End of DDL script for TALK2ME_TMP_LOAD

-- Start of DDL script for TALK2ME_TMP_TRANS
-- Generated 11-mar-03  10:54:29 am
-- from ernst-NINJA:6

-- Table TALK2ME_TMP_TRANS

CREATE TABLE talk2me_tmp_trans
 (
  subscriber_no              VARCHAR2(20) NOT NULL,
  soc                        VARCHAR2(9) NOT NULL,
  action                     VARCHAR2(15) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Constraints for TALK2ME_TMP_TRANS

ALTER TABLE talk2me_tmp_trans
 ADD CONSTRAINT talk2me_tmp_conn1 PRIMARY KEY (subscriber_no,soc,action)
 USING INDEX
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE ninja_data1
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/


-- End of DDL script for TALK2ME_TMP_TRANS

-- Start of DDL script for TMP_BRAWE_MAN_LIST
-- Generated 11-mar-03  10:54:29 am
-- from ernst-NINJA:6

-- Table TMP_BRAWE_MAN_LIST

CREATE TABLE tmp_brawe_man_list
 (
  man                        NUMBER(9),
  ban_count                  NUMBER(4)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- End of DDL script for TMP_BRAWE_MAN_LIST

-- Start of DDL script for TMP_CHECK
-- Generated 11-mar-03  10:54:29 am
-- from ernst-NINJA:6

-- Table TMP_CHECK

CREATE TABLE tmp_check
 (
  ctn                        VARCHAR2(20),
  sim                        VARCHAR2(20),
  aa                         VARCHAR2(10),
  bb                         VARCHAR2(10),
  cc                         VARCHAR2(20),
  dd                         VARCHAR2(10),
  ee                         VARCHAR2(40),
  ff                         VARCHAR2(40),
  gg                         VARCHAR2(30),
  hh                         VARCHAR2(20),
  jj                         VARCHAR2(20)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     32768
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- End of DDL script for TMP_CHECK
