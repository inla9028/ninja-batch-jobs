UPDATE master_transactions 
set process_status = 'WAITING',
status_desc = null 
WHERE process_status = 'PRSD_ERROR'
AND soc = 'FLEX'
AND status_desc NOT LIKE 'SOC is already on subscription%';
COMMIT;
