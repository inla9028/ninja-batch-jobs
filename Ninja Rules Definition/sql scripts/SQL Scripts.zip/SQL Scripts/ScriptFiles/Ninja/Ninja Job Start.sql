update ninja_jobs set job_status = 'STARTING' where job_id = 28;
commit work;
