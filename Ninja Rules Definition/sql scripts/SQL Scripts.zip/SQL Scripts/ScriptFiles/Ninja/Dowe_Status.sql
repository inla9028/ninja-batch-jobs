select to_char(dowe_request_dt,'YYYY-MM-DD'), dowe_proc_status, count(*)
from dowe_queue
group by to_char(dowe_request_dt,'YYYY-MM-DD'), dowe_proc_status
order by to_char(dowe_request_dt,'YYYY-MM-DD') DESC
