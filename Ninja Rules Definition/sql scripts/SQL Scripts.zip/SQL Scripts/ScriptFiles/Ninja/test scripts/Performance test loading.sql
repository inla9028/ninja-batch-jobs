INSERT INTO performance_test
SELECT SUBSTR(subscriber_no, 14)+40, subscriber_no, NULL,NULL,NULL,NULL,rtrim(soc),NULL,NULL,null FROM service_agreement@prod.world
WHERE service_type = 'P'
AND expiration_date > SYSDATE
AND soc NOT LIKE 'PV%'
AND subscriber_no LIKE 'GSM04793%'
AND ROWNUM < 5001;
COMMIT;

