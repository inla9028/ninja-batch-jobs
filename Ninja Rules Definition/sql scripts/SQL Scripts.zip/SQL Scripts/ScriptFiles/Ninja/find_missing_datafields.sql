 select * from ninja_datafield_new
 where not exists (select ''
                  from ninja_datafield
                  where dataset_name = ninja_datafield_new.dataset_name
                  and   datafield_name = ninja_datafield_new.datafield_name)
