
-- Start of DDL script for NINJA_DATAFIELD
-- Generated 15-mai-00  5:20:18 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD

DROP TABLE interf.ninja_datafield
/

-- Table NINJA_DATAFIELD

CREATE TABLE interf.ninja_datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD

CREATE  UNIQUE INDEX interf.ninja_datafield_name_pk
 ON interf.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
/

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES interf.ninja_dataset(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD

-- Start of DDL script for NINJA_DATAFIELD_VALUE
-- Generated 15-mai-00  5:20:18 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD_VALUE

DROP TABLE interf.ninja_datafield_value
/

-- Table NINJA_DATAFIELD_VALUE

CREATE TABLE interf.ninja_datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0),
  datafield_ismandatory      NUMBER(*,0),
  datafield_occurrance       NUMBER(*,0) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD_VALUE

CREATE  UNIQUE INDEX interf.ninja_datafield_value_pk
 ON interf.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD_VALUE

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafieldv_ds_fk FOREIGN KEY (dataset_name,datafield_name)
      REFERENCES interf.ninja_datafield(dataset_name,datafield_name) ON DELETE CASCADE
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_user_name_fk FOREIGN KEY (username)
      REFERENCES interf.ninja_user(username) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD_VALUE

-- Start of DDL script for NINJA_DATASET
-- Generated 15-mai-00  5:20:19 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASET

DROP TABLE interf.ninja_dataset
/

-- Table NINJA_DATASET

CREATE TABLE interf.ninja_dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1),
  dataset_comment            VARCHAR2(80)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        65536
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATASET

CREATE  UNIQUE INDEX interf.ninja_dataset_name_pk
 ON interf.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATASET

ALTER TABLE interf.ninja_dataset
 ADD CONSTRAINT ninja_dataset_name_pk PRIMARY KEY (dataset_name)
/


-- End of DDL script for NINJA_DATASET

-- Start of DDL script for NINJA_USER
-- Generated 15-mai-00  5:20:19 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_USER

DROP TABLE interf.ninja_user
/

-- Table NINJA_USER

CREATE TABLE interf.ninja_user
 (
  username                   VARCHAR2(32) NOT NULL,
  dataset_name               VARCHAR2(32)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_USER

COMMENT ON TABLE interf.ninja_user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for NINJA_USER

CREATE  UNIQUE INDEX interf.sys_c0056039
 ON interf.ninja_user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_USER

ALTER TABLE interf.ninja_user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for NINJA_USER
