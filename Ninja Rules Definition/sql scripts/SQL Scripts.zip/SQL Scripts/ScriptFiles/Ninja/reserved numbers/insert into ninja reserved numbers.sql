INSERT INTO reserved_numbers
SELECT ctn, 'NENI', SYSDATE -1, 1
FROM tn_inv@prod.world
WHERE ctn IN ('04798252319');
COMMIT;
