SELECT * FROM tn_inv_history@prod.world
WHERE ctn IN ('04793263600','04798227618','04798227617')
ORDER BY ctn,sys_creation_date
