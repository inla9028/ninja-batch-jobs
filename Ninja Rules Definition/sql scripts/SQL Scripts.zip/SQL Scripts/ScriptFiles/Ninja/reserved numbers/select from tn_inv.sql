SELECT * FROM tn_inv@prod.world
WHERE ctn IN ('04798293104')
