update ninja_datafield_value
set datafield_value = 'ninja'
where datafield_name = 'APPLICATION_ID'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = 'PRDENV' -- 'APPCLNG5'
where datafield_name = 'ENV_CODE'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = 'NTC'
where datafield_name = 'MARKET_CODE'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = '0'
where datafield_name = 'ONLINE_TRX_NO'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = '0'
where datafield_name = 'SESSION_ID'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = 'O'
where datafield_name = 'TRANSACTION_MODE'
and dataset_name like '%_in_%';
update ninja_datafield_value
set datafield_value = '200900'
where datafield_name = 'OPERATOR_ID'
and dataset_name like '%_in_%';
commit work;

