
 SELECT
    SUBSCRIBER_NO,
    CUSTOMER_ID,
    OPERATOR_ID,
    APPLICATION_ID,
    EFFECTIVE_DATE,
    INIT_ACTIVATION_DATE,
    SUB_STATUS,
    SUB_STATUS_DATE,
    ORIGINAL_INIT_DATE,
    SUB_STATUS_LAST_ACT,
    SUB_STATUS_RSN_CODE,
    DEALER_CODE,
    ORG_DEALER_CODE,
    SALES_AGENT,
    ORG_SALES_AGENT,
    SUB_STS_ISSUE_DATE,
    EARLIEST_ACTV_DATE,
    LISTED_IND,
    ALLOW_ADVERTISING_IND,
    AUTO_RELEASE_IND
 FROM NTCAPPO.SUBSCRIBER a
where customer_id in (404574303,538803305,878113307,904574308)
and sub_status in ('R','A','S')
and not exists (select ' ' from service_agreement b where a.subscriber_no = b.subscriber_no and a.customer_id = b.customer_id and b.soc like 'VM%' and b.expiration_date > sysdate)
