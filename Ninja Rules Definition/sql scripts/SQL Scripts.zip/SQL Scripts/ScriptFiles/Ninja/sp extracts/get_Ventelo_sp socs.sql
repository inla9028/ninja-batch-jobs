create table mw_tmp_ventelo_socs as
 SELECT
    BAN,
    substr(SUBSCRIBER_NO,4) as subscriber,
    SOC,
    SOC_EFFECTIVE_DATE,
    FEATURE_CODE,
    SERVICE_TYPE,
    FTR_EFFECTIVE_DATE,
    FTR_EXPIRATION_DATE,
    substr(FTR_SPECIAL_TELNO,4) as additional_telno
 FROM NTCAPPO.SERVICE_FEATURE@prod.world
where ban in (113269203,
113269203,
114975204,
123269201,
130214208,
155030208,
169707205,
206613309,
216621300,
262621204,
263115305,
269707204,
284133204,
333048205,
352629208,
373442201,
413269200,
538015207,
559008107,
573629201,
578259103,
605115302,
652629205,
806613303,
859008104,
881115307,
985613306)
and (service_type = 'P' or ftr_special_telno != subscriber_no or feature_code = 'CPKGGS')
--and ftr_expiration_date > sysdate
and feature_code not in ('S-PERS','TRANS','GSMVOI','SMS','GSMINT','GSMVPR','S-FORW','FRWD','B-SMSO','B-TEL','FRWINT','FW180','GSMNET','S-BAR','B-SMST','GSM2R','VOCAC','GSM810','GSM815','GSMFEM');
/*and ( (soc <> 'VMVS+' and feature_code <> 'CPKGGS')
or (soc <> 'VMVS' and feature_code <> 'CPKGGS'))*/
commit work;
