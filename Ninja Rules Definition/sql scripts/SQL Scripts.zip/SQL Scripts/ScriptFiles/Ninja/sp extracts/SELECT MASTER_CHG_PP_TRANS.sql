SELECT a.subscriber_no, a.new_priceplan, a.new_campaign_code,
       a.new_subscription_type, a.handle_commitment, a.effective_date,
       a.dealer, a.sales_agent, a.reason_code, a.memo_text,
       a.waive_fees, a.enter_time, a.request_time, a.process_time,
       a.process_status, a.status_desc, a.priority, a.requestor_id,
       a.skip_ninja_validation
  FROM master_chg_pp_trans a
  WHERE a.requestor_id = 'LRI TD842'
  ORDER BY a.process_status
