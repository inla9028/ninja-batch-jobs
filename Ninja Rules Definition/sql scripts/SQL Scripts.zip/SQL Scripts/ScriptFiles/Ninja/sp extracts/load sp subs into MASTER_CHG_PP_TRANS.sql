INSERT INTO master_chg_pp_trans 
SELECT a.subscriber_no, 'PVSH', '000000000', 'PVSHREG1', null, null, 'SC01', 'A', 'VS01', 'Change PVSL to PVSH - Requested by Sense (Ref: Lars Ritland TD842)',
       'Y', sysdate, sysdate, null, 'IN_PROGRESS', null, '3', 'LRI TD842','N'
  FROM  mw_tmp_pvsl_subs@fokusninja a;
  COMMIT;
