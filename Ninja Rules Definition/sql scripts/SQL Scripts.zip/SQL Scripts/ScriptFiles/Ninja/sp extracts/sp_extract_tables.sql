
-- Start of DDL script for MW_TMP_VENTELO
-- Generated 11-okt-02  3:57:49 am
-- from ernst-NINJA:1

-- Table MW_TMP_VENTELO

CREATE TABLE mw_tmp_ventelo
 (
  subscriber                 VARCHAR2(17),
  effective_date             DATE NOT NULL,
  init_activation_date       DATE NOT NULL,
  sub_status                 CHAR(1) NOT NULL,
  sub_status_date            DATE NOT NULL,
  original_init_date         DATE NOT NULL,
  sub_status_last_act        CHAR(3),
  sub_status_rsn_code        CHAR(4),
  customer_ban               NUMBER(9),
  dealer_code                CHAR(5),
  org_dealer_code            CHAR(5),
  customer_id                NUMBER(9) NOT NULL,
  subscriber_id              NUMBER(9) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     40960
      NEXT        1146880
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO

-- Start of DDL script for MW_TMP_VENTELO_PRODS
-- Generated 11-okt-02  3:57:59 am
-- from ernst-NINJA:1

-- Table MW_TMP_VENTELO_PRODS

CREATE TABLE mw_tmp_ventelo_prods
 (
  ban                        NUMBER(9) NOT NULL,
  subscriber                 VARCHAR2(17),
  soc                        CHAR(9) NOT NULL,
  soc_effective_date         DATE NOT NULL,
  feature_code               CHAR(6) NOT NULL,
  service_type               CHAR(1) NOT NULL,
  ftr_effective_date         DATE NOT NULL,
  ftr_expiration_date        DATE NOT NULL,
  additional_telno           VARCHAR2(17)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     40960
      NEXT        3874816
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO_PRODS

-- Start of DDL script for MW_TMP_VENTELO_SIMS
-- Generated 11-okt-02  3:58:07 am
-- from ernst-NINJA:1

-- Table MW_TMP_VENTELO_SIMS

CREATE TABLE mw_tmp_ventelo_sims
 (
  customer_id                NUMBER(9) NOT NULL,
  subscriber                 VARCHAR2(17),
  equipment_no               VARCHAR2(20) NOT NULL,
  init_activation_date       DATE NOT NULL,
  expiration_date            DATE,
  imsi                       VARCHAR2(15),
  effective_date             DATE,
  sw_state_ind               CHAR(1),
  last_sw_actv_date          DATE
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- End of DDL script for MW_TMP_VENTELO_SIMS
