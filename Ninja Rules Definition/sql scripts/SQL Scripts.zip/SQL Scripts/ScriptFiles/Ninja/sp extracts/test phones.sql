select ctn
from tn_inv,msisdn_hlr_relation
where ctn between msisdn_begin_range and msisdn_end_range
and phy_hlr = '56'
and ngp = 'VOI' and ctn_status = 'AA'
