delete from mw_tmp_ventelo_socs where soc like 'VM%' and feature_code = 'CPKGGS';
delete from mw_tmp_ventelo_socs where feature_code = 'S-PERS';
commit work;

