
 SELECT
    SOC,count(*)
 FROM NINJA.MW_TMP_VENTELO_PRODS a
where ftr_expiration_date > sysdate
and not exists (select ' ' from subscription_types_socs b where subscription_type_id in ('PVGHREG1','PVGLREG1') and rtrim(a.soc) = b.soc)
group by soc
