DROP TABLE mw_tmp_pvsl_subs;
CREATE TABLE mw_tmp_pvsl_subs 
AS SELECT a.subscriber_no, RTRIM(a.soc) AS priceplan, a.ban, a.soc_effective_date, a.dealer_code, 'X' AS account_type, 'XX' AS account_sub_type, 'X' AS sub_status, 'XXXXX' AS sub_dealer
FROM ntcappo.service_agreement a
WHERE a.service_type = 'P'
AND a.soc = 'PVSL'
AND nvl(a.expiration_date, SYSDATE+1) > SYSDATE;
COMMIT;

CREATE UNIQUE INDEX mw_tmp_vsl_s1 ON mw_tmp_pvsl_subs
  (
    subscriber_no                   ASC
  );

CREATE INDEX mw_tmp_vsl2 ON mw_tmp_pvsl_subs
  (
    ban                             ASC
  );



UPDATE mw_tmp_pvsl_subs a
SET (a.sub_dealer, a.sub_status) = (SELECT b.dealer_code, b.sub_status
                                         FROM ntcappo.subscriber b
                                         WHERE b.subscriber_no = a.subscriber_no
                                         AND b.customer_id = a.ban);
COMMIT;        

UPDATE mw_tmp_pvsl_subs a
SET (a.account_type, a.account_sub_type) = (SELECT b.account_type, rtrim(b.account_sub_type)
                                         FROM ntcappo.billing_account b
                                         WHERE b.customer_id = a.ban);
COMMIT;        
             
