UPDATE mw_tmp_pvsl_subs a
SET (a.sub_dealer, a.sub_status) = (SELECT b.dealer_code, b.sub_status
                                         FROM ntcappo.subscriber b
                                         WHERE b.subscriber_no = a.subscriber_no
                                         AND b.customer_id = a.ban);
COMMIT;        

UPDATE mw_tmp_pvsl_subs a
SET (a.account_type, a.account_sub_type) = (SELECT b.account_type, rtrim(b.account_sub_type)
                                         FROM ntcappo.billing_account b
                                         WHERE b.customer_id = a.ban);
COMMIT;        
                                 
