update master_chg_pp_trans a
SET a.process_status = 'WAITING', a.status_desc = null
  WHERE a.requestor_id = 'LRI TD842'
  AND a.process_status = 'PRSD_ERROR'
  AND a.status_desc LIKE '%Tuxedo%';
  COMMIT;
