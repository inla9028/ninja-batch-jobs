select ban || ',' from ban_hierarchy_tree@prod.world where tree_root_ban = 559008107
