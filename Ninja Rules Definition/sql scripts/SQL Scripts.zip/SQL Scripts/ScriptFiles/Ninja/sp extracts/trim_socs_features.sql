update mw_tmp_you_socs set soc = rtrim(soc), feature_code = rtrim(feature_code);
commit work;
