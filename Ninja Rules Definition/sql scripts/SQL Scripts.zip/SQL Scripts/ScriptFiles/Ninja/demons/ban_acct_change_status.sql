select process_status, count(*)
from ban_acct_type_change
group by process_status
