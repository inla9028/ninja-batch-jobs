select to_char(process_time, 'YYYYMMDD HH24MI'), count(*)
from ban_acct_type_change
where process_status = 'PRSD_SUCCESS'
and process_time is not null
group by to_char(process_time, 'YYYYMMDD HH24MI')
