select process_status, count(*)
from master_chg_pp_trans
where requestor_id = 'SLG 27.05.03'
group by process_status
