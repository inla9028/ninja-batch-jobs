 SELECT
process_stream,count(*)
    
 FROM NINJA.PPBK_CONV_PROCD_SUBS
 where process_status = 'WAITING'
group by process_stream
