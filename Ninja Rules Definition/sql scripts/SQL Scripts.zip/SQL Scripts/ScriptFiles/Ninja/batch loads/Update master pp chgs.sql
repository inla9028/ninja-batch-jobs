update master_chg_pp_trans set process_status = 'WAITING', process_time = null, status_desc = null
where requestor_id = 'SLG 27.05.03' and process_status = 'PRSD_ERROR' and status_desc = 'Illegal Change Rating Combination No match found for specified Combination.'



commit work;
