update mw_tmp_hlr_trans
set hlr = 3
where hlr is null;
commit;
