select process_status, count(*)
from mms_transactions
group by process_status
