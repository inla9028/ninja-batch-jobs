update master_chg_pp_trans
set process_status = 'WAITING'
where REQUESTOR_ID = 'AGT 25.03.2003 (OSLOKOMMUNE)'
and process_status = 'IN_PROGRESS';
commit;
