update mw_tmp_hlr_trans
set hlr = (select physical_hlr
           from fokus_phy_lgl_hlr, msisdn_hlr_relation@prod.world
           where substr(subscriber_no, 4) between msisdn_begin_range and msisdn_end_range
           and phy_hlr = logical_hlr);
commit work;
