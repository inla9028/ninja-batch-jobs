
 SELECT
    TRANS_NUMBER,
    HLR,
    SUBSCRIBER_NO,
    SOC,
    ACTION_CODE,
    NEW_SOC,
    ENTER_TIME,
    REQUEST_TIME,
    PROCESS_TIME,
    PROCESS_STATUS,
    STATUS_DESC,
    DEALER_CODE,
    SALES_AGENT,
    PRIORITY,
    REQUEST_ID,
    MEMO_TEXT
 FROM NINJA.MASTER_HLR_TRANSACTIONS
where request_time > sysdate -.1
and process_status = 'PRSD_ERROR'
