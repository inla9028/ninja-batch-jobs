update ban_acct_type_change
set process_status = 'WAITING'
where process_status = 'IN_PROGRESS';
commit work;
