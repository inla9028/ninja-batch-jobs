insert into mw_tmp_hlr_trans
select subscriber_no, null,'GPRS02','ADD',null,null,null,'SLG GPRS ADD',null
from mw_tmp_gprsppadd;-- order by substr(subscriber_no,14,1),substr(subscriber_no,11,1) ; --where subscriber_no like 'GSM0474%';
delete from mw_tmp_gprsppadd;-- where subscriber_no like 'GSM0474%';
commit;
