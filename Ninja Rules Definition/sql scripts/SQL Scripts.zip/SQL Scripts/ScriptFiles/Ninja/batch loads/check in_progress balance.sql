
 SELECT
    substr(to_char(man),9,1), count(SUBSCRIBER_NO)
    
 FROM NINJA.PPBK_CONV_PROCD_SUBS
 where process_status = 'IN_PROGRESS'
group by substr(to_char(man),9,1)
order by 2 desc
