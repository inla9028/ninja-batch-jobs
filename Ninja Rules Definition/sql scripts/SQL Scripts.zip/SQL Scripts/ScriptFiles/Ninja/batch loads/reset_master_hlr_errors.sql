update master_hlr_transactions set process_status = 'WAITING', status_desc = null
where process_status = 'PRSD_ERROR' and status_desc like 'Could not find BAN for subscribe%';
commit work;
