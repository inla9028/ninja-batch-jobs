select hlr,process_status,count(*)
from master_hlr_transactions
--where process_status = 'WAITING'
group by hlr,process_status
