select 'Start - ' || sysdate from dual;
create table mw_tmp_mms_subs as
select BAN,SUBSCRIBER_NO,SOC
from NTCAPPO.SERVICE_AGREEMENT
where soc = 'MMS01' and expiration_date > sysdate;
commit work;
select 'Finish - ' || sysdate from dual;
