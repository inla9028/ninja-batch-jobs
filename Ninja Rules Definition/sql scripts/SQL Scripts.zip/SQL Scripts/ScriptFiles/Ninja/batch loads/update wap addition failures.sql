update MASTER_TRANSACTIONS set process_status = 'WAITING', status_desc = null, process_time = null
where request_id = 'MW WAP1'
and process_status <> 'PRSD_SUCCESS' and status_desc like 'Invalid Subscriber Status. (Current state%';
commit work;
