insert into MW_TMP_GPRSPPADD
select subscriber_no
from service_agreement@prod t1
where t1.soc = ('PKOC')
and nvl(t1.expiration_date, to_date('47001231','YYYYMMDD')) > sysdate
and not exists (select ' ' from service_agreement@prod t2
                where t1.ban = t2.ban
                and t1.subscriber_no = t2.subscriber_no
                and (t2.soc = 'GPRS02' or t2.soc = 'GPRS03' or t2.soc = 'GPRSPRE')
                and nvl(t2.expiration_date, to_date('47001231','YYYYMMDD')) > sysdate);
commit;
