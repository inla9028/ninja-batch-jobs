insert into mw_tmp_trans
select subscriber_no, 'GPRSPRE','ADD',null,null,null,'PP GRPS Add',null
from mw_tmp_gprsppadd order by substr(subscriber_no,14,1),substr(subscriber_no,11,1) ; --where subscriber_no like 'GSM0474%';
delete from mw_tmp_gprsppadd where subscriber_no like 'GSM0474%';
commit;
