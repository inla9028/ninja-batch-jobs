select * from service_feature where subscriber_no in  ('GSM04790996014','GSM04792810211')
