INSERT INTO NINJA_PP_PRODS
            (spc_agr_type,
             acct_type,
             acct_sub_type,
             campaign,
             price_plan,
             soc_code,
             product_name,
             optionality_ind,
             displayable_ind,
             addition_ind,
             deletion_ind,
             fokus_desc,
             additional_parms,
             soc_group)

SELECT       spc_agr_type,
             acct_type,
             acct_sub_type,
             campaign,
             price_plan,
             'DATASFA',
             product_name,
             optionality_ind,
             displayable_ind,
             addition_ind,
             deletion_ind,
             fokus_desc,
             additional_parms,
             soc_group
FROM NINJA_PP_PRODS
WHERE spc_agr_type = 'R'
AND   acct_type = 'B'
AND   acct_sub_type = 'S'
AND   campaign = '000000000'
AND   price_plan = 'PQSFA'
AND   soc_code = 'DATASKA';

COMMIT;
