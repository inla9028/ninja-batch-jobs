insert into ninja_datafield_value
            (dataset_name,
            datafield_name,
            username,
            datafield_value,
            datafield_islocked,
            datafield_ismandatory,
            datafield_occurrance)
select  dataset_name,
        datafield_name,
        'MBWTest1',
        datafield_value,
        datafield_islocked,
        datafield_ismandatory,
        datafield_occurrance
from ninja_datafield_value
where username = 'TestUser1';
--and dataset_name like 'CsGtCtn_%';

commit;
