update chg_priceplan_trans
set dealer = 'NET', sales_agent = 'A', priority = 5
where new_priceplan = 'PKOM' and priority = 3;
commit;
