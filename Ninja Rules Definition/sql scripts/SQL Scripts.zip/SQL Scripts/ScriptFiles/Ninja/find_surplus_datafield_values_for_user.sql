--select 'delete from ninja_datafield_value where dataset_name = ''' || dataset_name || ''' and datafield_name = ''' || datafield_name || ''';' from ninja_datafield_value
select * from ninja_datafield_value
where username = 'NinjaInternal'
and not exists (select ' '
                from ninja_datafield
                where dataset_name = ninja_datafield_value.dataset_name
                and   datafield_name = ninja_datafield_value.datafield_name
                and   username = 'NinjaInternal');
