update performance_test
set bean_start = null,bean_end = null, method_start = null, method_end = null;
commit;
