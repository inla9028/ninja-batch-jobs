
-- Start of DDL script for NINJA_DATAFIELD_VALUE
-- Generated 6-apr-00  7:14:48 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD_VALUE

DROP TABLE interf.ninja_datafield_value
/

-- Table NINJA_DATAFIELD_VALUE

CREATE TABLE interf.ninja_datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0),
  datafield_ismandatory      NUMBER(*,0),
  datafield_occurrance       NUMBER(*,0) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD_VALUE

CREATE  UNIQUE INDEX interf.ninja_datafield_value_pk
 ON interf.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD_VALUE

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafieldv_ds_fk FOREIGN KEY (dataset_name,datafield_name)
      REFERENCES interf.ninja_datafield(dataset_name,datafield_name) ON DELETE CASCADE
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_user_name_fk FOREIGN KEY (username)
      REFERENCES interf.ninja_user(username) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD_VALUE
