insert into ninja_datafield_value
            (dataset_name,
            datafield_name,
            username,
            datafield_value,
            datafield_islocked,
            datafield_ismandatory,
            datafield_occurrance)
select  dataset_name,
        datafield_name,
        'ORIONuser',
        datafield_value,
        datafield_islocked,
        datafield_ismandatory,
        datafield_occurrance
from ninja_datafield_value
where username = 'NinjaInternal';
--and dataset_name in ('CsSvPNP_in_DSet','CsSvPNP_out_DSet');


commit;
--rollback;
