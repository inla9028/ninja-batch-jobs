select new_priceplan,to_char(process_time, 'DDMM HH24 MI'),process_status,count(*)
from chg_priceplan_trans
where request_time > sysdate -2 and new_priceplan = 'PKOM'
group by new_priceplan,to_char(process_time, 'DDMM HH24 MI'),process_status
