update np_time_port set np_status = 'FAIL' where NP_DESCRIPTION = 'Unknown Error Occurred' and np_status = 'INIT';
commit;
