insert into ninja_datafield_value (dataset_name, datafield_name, username, datafield_occurrance)
select dset.dataset_name dataset_name, datafield_name, 'TestUser1' username, 0 occurrance
from ninja_dataset dset, ninja_datafield dfield
where dset.dataset_name = dfield.dataset_name
--and dataset_type = 'out'
--and in_use = 1
and dset.dataset_name in ('CvSvBan_in_DSet','CvSvBan_out_DSet');

commit;
