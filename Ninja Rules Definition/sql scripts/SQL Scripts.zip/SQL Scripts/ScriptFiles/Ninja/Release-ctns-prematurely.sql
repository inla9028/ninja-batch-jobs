update reserved_numbers set reserved_date = reserved_date -.95 where reserved_date < sysdate -.5;
commit;
