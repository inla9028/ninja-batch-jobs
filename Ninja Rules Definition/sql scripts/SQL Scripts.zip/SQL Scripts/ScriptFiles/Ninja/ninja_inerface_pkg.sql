
-- Start of DDL script for NINJA_INTERFACE
-- Generated 15-mai-00  5:21:34 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_INTERFACE

DROP PACKAGE interf.ninja_interface
/

-- Package NINJA_INTERFACE

CREATE OR REPLACE
Package INTERF.NINJA_INTERFACE
  IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, initial revision.
-- SAH         000406  Added set_dataset and set_datafield

  -- Create a cursortype for the ninja_datasets view
  TYPE dataset_list IS REF CURSOR RETURN ninja_datasets%ROWTYPE;

  -- Get
  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%type )
    RETURN dataset_list;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER;

  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER;

END; -- Package Specification NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE
