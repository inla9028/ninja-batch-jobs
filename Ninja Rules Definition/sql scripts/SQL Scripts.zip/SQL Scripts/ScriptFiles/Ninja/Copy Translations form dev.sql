insert into ninja_ads_parms
(select * from ninjatest.ninja_ads_parms);
commit;
insert into ninja_prod_desc
(select * from ninjatest.ninja_prod_desc);
commit;
insert into ninja_pp_prods
(select * from ninjatest.ninja_pp_prods);
commit;
insert into ninja_acct_pp
(select * from ninjatest.ninja_acct_pp);
commit;
