delete from dowe_queue
where dowe_order_id > '89000';

commit;
