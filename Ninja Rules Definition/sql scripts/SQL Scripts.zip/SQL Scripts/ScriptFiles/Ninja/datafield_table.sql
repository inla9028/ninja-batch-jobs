
-- Start of DDL script for NINJA_DATAFIELD
-- Generated 15-mai-00  5:19:28 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD

DROP TABLE interf.ninja_datafield
/

-- Table NINJA_DATAFIELD

CREATE TABLE interf.ninja_datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD

CREATE  UNIQUE INDEX interf.ninja_datafield_name_pk
 ON interf.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
/

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES interf.ninja_dataset(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD
