
-- Start of DDL script for NINJA_DATASETS
-- Generated 6-jun-00  10:58:34 am
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASETS

DROP VIEW interf.ninja_datasets
/

-- View NINJA_DATASETS

CREATE OR REPLACE VIEW interf.ninja_datasets (
   dataset_name,
   datafield_name,
   datafield_type,
   username,
   datafield_occurrance,
   datafield_value,
   datafield_ismandatory,
   datafield_islocked,
   in_use )
AS
SELECT dset.dataset_name,
       dfield.datafield_name,
       datafield_type,
       usr.username,
       datafield_occurrance,
       datafield_value,
       datafield_ismandatory,
       datafield_islocked,
       dfield.in_use
FROM   ninja_dataset dset,
       ninja_datafield dfield,
       ninja_datafield_value dfieldv,
       ninja_user usr
WHERE  dset.in_use = 1
AND    dfield.in_use = 1
AND    dset.dataset_name = dfield.dataset_name
AND    dfield.dataset_name = dfieldv.dataset_name
AND    dfield.datafield_name = dfieldv.datafield_name
AND    dfieldv.username = usr.username
/

-- End of DDL script for NINJA_DATASETS
