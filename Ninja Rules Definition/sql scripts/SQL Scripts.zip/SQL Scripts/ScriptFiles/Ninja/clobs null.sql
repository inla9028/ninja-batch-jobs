SELECT * 
FROM np_time_port
WHERE status = 'WAITING'
AND nvl(dbms_lob.getlength(xml_clob),0) = 0;

SELECT * 
FROM np_time_port
WHERE status = 'WAITING'
AND nrdb_ref_id LIKE 'TEMP%'
AND DBMS_LOB.instr(xml_clob, '12OP') > 0;





UPDATE np_time_port set status = 'NULL_CLOB' WHERE nvl(dbms_lob.getlength(xml_clob),0) = 0 AND status = 'WAITING';
COMMIT WORK;
