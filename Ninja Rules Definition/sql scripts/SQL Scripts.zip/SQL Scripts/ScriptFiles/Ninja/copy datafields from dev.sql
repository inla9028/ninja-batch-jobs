insert into ninja_datafield_value
(select *
 from ninjatest.ninja_datafield_value
 where username = 'Tele1EUR');
 --and dataset_name in ('GnChkAdrVld_in_DSet','GnChkAdrVld_out_DSet','GnGtTree_in_DSet','GnGtTree_out_DSet'));

commit;
