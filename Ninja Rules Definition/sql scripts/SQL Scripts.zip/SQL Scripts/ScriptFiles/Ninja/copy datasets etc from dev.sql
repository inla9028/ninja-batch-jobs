insert into ninja_dataset
(select * from ninjaactst.ninja_dataset@ninjaactst);
commit;
insert into ninja_datafield
(select * from ninjaactst.ninja_datafield@ninjaactst);
commit;
insert into ninja_datafield_value
(select * from ninjaactst.ninja_datafield_value@ninjaactst);
commit;
--rollback;
