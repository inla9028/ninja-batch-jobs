select soc,to_char(process_time, 'DDMM HH24 MI'),process_status,count(*)
from service_transactions
where request_time > sysdate -2
group by soc,to_char(process_time, 'DDMM HH24 MI'),process_status
