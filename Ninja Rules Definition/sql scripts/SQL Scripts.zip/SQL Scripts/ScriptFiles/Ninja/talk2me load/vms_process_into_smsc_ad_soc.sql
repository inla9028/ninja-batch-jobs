insert into fokus.smsc_ad_soc@kontant.world
select subscriber_no, null, 'ADD', 1, sysdate, null, '1992'
from talk2me_tmp_load where col_b is not null;
commit;
