select a.* from service_transactions a
where exists (select ' ' from talk2me_tmp_load b where a.subscriber_no = b.subscriber_no)
and request_time > sysdate -.5
