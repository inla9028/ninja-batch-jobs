update talk2me_tmp_load
set subscriber_no = 'GSM047' || subscriber_no;
commit;
