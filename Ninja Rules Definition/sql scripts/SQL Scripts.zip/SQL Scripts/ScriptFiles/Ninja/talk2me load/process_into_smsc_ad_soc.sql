insert into fokus.smsc_ad_soc@kontant.world
select subscriber_no, 'NORDENP', 'ADD', 1, sysdate, null, null
from talk2me_tmp_load where col_e is not null;
commit;
