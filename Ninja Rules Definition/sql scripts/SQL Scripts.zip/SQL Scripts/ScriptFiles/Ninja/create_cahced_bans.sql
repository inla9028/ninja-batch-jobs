CREATE TABLE cached_ban_trees
 (
  tree_root_ban              NUMBER(9),
  time_stored                DATE,              
  ban_tree_ids               BLOB DEFAULT empty_blob()
 )
 TABLESPACE ninja_data1
 STORAGE   (
      INITIAL     50M
      NEXT        25M
)      
   	LOB (ban_tree_ids) STORE AS (TABLESPACE NINJA_BLOB1
	CACHE 
	STORAGE (INITIAL 500M
	NEXT 500M )
	)

   
/

-- Comments for CACHED_BAN_TREES

COMMENT ON TABLE cached_ban_trees IS 'Contains the Cached Ban Tree IDS''s'
/

-- Column Comments for CACHED_BAN_TREES

COMMENT ON COLUMN cached_ban_trees.time_stored IS 'Time the Tree was Stored'
/
COMMENT ON COLUMN cached_ban_trees.tree_root_ban IS 'The Trre Root Ban'
/

-- End of DDL script for CACHED_BAN_TREES
