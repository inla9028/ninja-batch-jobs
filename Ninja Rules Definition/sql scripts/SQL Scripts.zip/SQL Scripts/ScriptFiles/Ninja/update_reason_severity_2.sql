update reason_severity
set csa = (select rtrim(csa_activity_desc)
           from csm_status_activity@prod.world
           where rtrim(csa_activity_code) = status_avt_code
           and rtrim(csa_activity_rsn_code) = status_avt_rsn_code)
           ,
    description = (select rtrim(csa_activity_rsn_desc)
           from csm_status_activity@prod.world
           where rtrim(csa_activity_code) = status_avt_code
           and rtrim(csa_activity_rsn_code) = status_avt_rsn_code);
           
           commit worK;
