
-- Start of DDL script for NINJA_USER
-- Generated 6-apr-00  7:13:57 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_USER

DROP TABLE interf.ninja_user
/

-- Table NINJA_USER

CREATE TABLE interf.ninja_user
 (
  username                   VARCHAR2(32) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_USER

COMMENT ON TABLE interf.ninja_user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for NINJA_USER

CREATE  UNIQUE INDEX interf.sys_c0056039
 ON interf.ninja_user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_USER

ALTER TABLE interf.ninja_user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for NINJA_USER
