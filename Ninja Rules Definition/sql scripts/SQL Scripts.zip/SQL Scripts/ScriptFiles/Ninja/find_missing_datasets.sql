select * from ninja_dataset_new
where not exists (select ' ' from ninja_dataset where dataset_name = ninja_dataset_new.dataset_name)
