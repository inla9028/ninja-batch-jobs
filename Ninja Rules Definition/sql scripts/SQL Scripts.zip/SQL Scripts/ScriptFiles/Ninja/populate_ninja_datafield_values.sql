delete from ninja_datafield_value where username = 'custval';
insert into ninja_datafield_value
            (dataset_name,
            datafield_name,
            username,
            datafield_value,
            datafield_islocked,
            datafield_ismandatory,
            datafield_occurrance)
select  dataset_name,
        datafield_name,
        'custval',
        datafield_value,
        datafield_islocked,
        datafield_ismandatory,
        datafield_occurrance
from ninja_datafield_value
where username = 'NinjaInternal';

update ninja_datafield_value
set datafield_value = '200900'
where username = 'custval'
and datafield_name = 'OPERATOR_ID'
and dataset_name like '%_in_%';



commit;
--rollback;
