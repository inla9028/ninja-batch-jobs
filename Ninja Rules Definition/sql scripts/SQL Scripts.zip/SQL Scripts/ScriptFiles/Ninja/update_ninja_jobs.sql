update ninja_jobs_redesign
set job_status = --'STARTING'
                 --'STOPPING'
                 'STOPPED';
--WHERE job_id in (9);
commit;
