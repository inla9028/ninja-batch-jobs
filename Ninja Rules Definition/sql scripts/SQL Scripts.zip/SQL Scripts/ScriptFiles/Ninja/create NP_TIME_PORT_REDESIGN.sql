-- Start of DDL Script for Table NINJADEV.NP_TIME_PORT_REDESIGN
-- Generated 01.09.2003 13:21:30 from NINJADEV@NINJA.WSRV1.NETCOM-GSM.NO

CREATE TABLE np_time_port_redesign
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    nrdb_ref_id                    VARCHAR2(20) NOT NULL,
    user_id                        VARCHAR2(16) NOT NULL,
    ctn                            VARCHAR2(11) NOT NULL,
    number_owner_code              VARCHAR2(10) NOT NULL,
    donor_code                     VARCHAR2(10) NOT NULL,
    recipient_code                 VARCHAR2(10) NOT NULL,
    date_time_created              DATE NOT NULL,
    date_time_modified             DATE NOT NULL,
    date_time_port                 DATE NOT NULL,
    description                    VARCHAR2(150),
    action                         VARCHAR2(4) NOT NULL,
    status                         VARCHAR2(4) NOT NULL,
    dto_blob                       BLOB DEFAULT empty_blob(),
    retries                        NUMBER(*,0) DEFAULT 0   NOT NULL)
   	LOB (dto_blob) STORE AS (TABLESPACE NINJA_BLOB1
	CACHE 
	STORAGE (INITIAL 100M
	NEXT 50M )
	)

   

/
-- Indexes for NP_TIME_PORT_REDESIGN

CREATE UNIQUE INDEX np_time_port_redesign_idx1 ON np_time_port_redesign
  (
    ctn                             ASC
  )
/
CREATE UNIQUE INDEX np_time_port_redesign_idx2 ON np_time_port_redesign
  (
    status                          ASC,
    date_time_port                  ASC
  )
/
CREATE UNIQUE INDEX np_time_port_redesign_idx3 ON np_time_port_redesign
  (
    ninja_ref_id                    ASC
  )
/


-- Constraints for NP_TIME_PORT_REDESIGN

ALTER TABLE np_time_port_redesign
ADD PRIMARY KEY (ninja_ref_id)
/

-- Triggers for NP_TIME_PORT_REDESIGN

CREATE OR REPLACE TRIGGER np_time_port_redesign_trg1
 BEFORE
  INSERT OR UPDATE
 ON np_time_port_redesign
REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
DECLARE
    v_cnt1 NUMBER;
BEGIN
		IF INSERTING
		THEN
            SELECT COUNT(*)
            INTO v_cnt1
            FROM NP_TIME_PORT_REDESIGN
            WHERE (ctn = :new.ctn and status = 'INIT');
            IF v_cnt1 != 0
            THEN
                  RAISE_APPLICATION_ERROR( -20001, 'CTN exists in pending state within the porting table' );
            END IF;

            SELECT	np_ref_seq_redesign.nextval
			INTO	:new.ninja_ref_id
			FROM 	dual;
		END IF;
	END;
/

-- Comments for NP_TIME_PORT_REDESIGN

COMMENT ON COLUMN np_time_port_redesign.action IS 'Ninja action to perform when retrieving the request.'
/
COMMENT ON COLUMN np_time_port_redesign.ctn IS 'Main CTN for the Porting Request.'
/
COMMENT ON COLUMN np_time_port_redesign.date_time_created IS 'Date/Time YYYYMMDDHHMMSS of the entry into the Table.'
/
COMMENT ON COLUMN np_time_port_redesign.date_time_modified IS 'Date/Time YYYYMMDDHHMMSS of the last update of the Request.'
/
COMMENT ON COLUMN np_time_port_redesign.date_time_port IS 'Date/Time YYYYMMDDHHMMSS the port should take place.'
/
COMMENT ON COLUMN np_time_port_redesign.description IS 'Description of the result of the latest processing.'
/
COMMENT ON COLUMN np_time_port_redesign.donor_code IS 'NRDB code of operator currently having the CTN.'
/
COMMENT ON COLUMN np_time_port_redesign.dto_blob IS 'BLOB containing the NinjaTimePortDetailsDTO containing all the required details for Processing by Ninja.'
/
COMMENT ON COLUMN np_time_port_redesign.ninja_ref_id IS 'Unique key. Automatically generated upon insert.'
/
COMMENT ON COLUMN np_time_port_redesign.nrdb_ref_id IS 'NRDB reference ID.'
/
COMMENT ON COLUMN np_time_port_redesign.number_owner_code IS 'NRDB code of operator owning the CTN.'
/
COMMENT ON COLUMN np_time_port_redesign.recipient_code IS 'NRDB code of operator receiving the CTN.'
/
COMMENT ON COLUMN np_time_port_redesign.retries IS 'Number of times the transaction has been attempted.'
/
COMMENT ON COLUMN np_time_port_redesign.status IS 'Status of the request.'
/
COMMENT ON COLUMN np_time_port_redesign.user_id IS 'User entering the request.'
/

-- End of DDL Script for Table NINJADEV.NP_TIME_PORT_REDESIGN

