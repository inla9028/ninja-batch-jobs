insert into ninja_datafield_value
(select dataset_name,datafield_name,username,datafield_value,datafield_islocked,datafield_ismandatory, 2 from
    ninja_datafield_value
    where dataset_name = 'CsSrchCtn_in_DSet' and datafield_name = 'PRODTP_ARR' and username = 'midas' and datafield_occurrance = 1);

    commit;
