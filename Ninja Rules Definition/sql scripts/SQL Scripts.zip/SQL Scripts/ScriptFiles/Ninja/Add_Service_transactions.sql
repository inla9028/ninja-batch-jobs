insert into service_transactions
select sub,
       soc,
       to_date('20011201120000','YYYYMMDDHHMISS'),
       to_date('20011201120000','YYYYMMDDHHMISS'),
       null,
       'WAITING',
       null
from mw_tmp_subs
where sub = 'GSM04793212360';
insert into service_tran_features
