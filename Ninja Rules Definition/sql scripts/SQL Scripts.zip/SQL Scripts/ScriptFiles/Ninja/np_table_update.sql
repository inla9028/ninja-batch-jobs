insert 
into np_time_port  (NP_REF,
                    NP_NRDB_REF_ID,
                    NP_USER,
                    NP_CTN, 
                    NP_ORIGINAL_DONOR_CODE, 
                    NP_DONOR_CODE, 
                    NP_RECIPIENT_CODE, 
                    NP_DATE_TIME_CREATED, 
                    NP_DATE_TIME_MODIFIED, 
                    NP_DATE_TIME_PORT, 
                    NP_DESCRIPTION, 
                    NP_ACTION, 
                    NP_STATUS, 
                    NP_IDS_BLOB)
select (null, 
        NP_NRDB_REF_ID,
        NP_USER,
        NP_CTN, 
        NP_ORIGINAL_DONOR_CODE, 
        NP_DONOR_CODE, 
        NP_RECIPIENT_CODE, 
        NP_DATE_TIME_CREATED, 
        NP_DATE_TIME_MODIFIED, 
        NP_DATE_TIME_PORT, 
        NP_DESCRIPTION, 
        NP_ACTION, 
        NP_STATUS, 
        NP_IDS_BLOB)
from tmp_np_time_port
where 

                            
                          
                          

