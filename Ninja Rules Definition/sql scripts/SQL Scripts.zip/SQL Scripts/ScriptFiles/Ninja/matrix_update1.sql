update ninja_pp_prods
set product_name = 'NOTDEFINED',
    optionality_ind = 'N',
    displayable_ind = 'N',
    addition_ind = 'N',
    deletion_ind = 'R',
    additional_parms = 'N',
    soc_group = ''
 where product_name is null;
 commit;
