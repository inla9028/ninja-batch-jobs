update master_transactions
set process_status = 'WAITING'
where process_status = 'IN_PROGRESS';
commit;
