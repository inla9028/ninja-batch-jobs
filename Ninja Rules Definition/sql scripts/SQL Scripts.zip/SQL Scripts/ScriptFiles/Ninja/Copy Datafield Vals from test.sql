insert into ninja_datafield_value
select * from ninja_datafield_value@ninjaactst
where dataset_Name like 'MmGtMemo%';
commit;
