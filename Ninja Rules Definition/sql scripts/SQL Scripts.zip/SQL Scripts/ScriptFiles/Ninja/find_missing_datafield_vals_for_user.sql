select * from ninja_datafield
where exists (select unique dataset_name
              from ninja_datafield_value
              where dataset_name = ninja_datafield.dataset_name
              and   username = 'NinjaInternal')
and not exists (select ' '
                from ninja_datafield_value
                where dataset_name = ninja_datafield.dataset_name
                and   datafield_name = ninja_datafield.datafield_name
                and   username = 'NinjaInternal');
