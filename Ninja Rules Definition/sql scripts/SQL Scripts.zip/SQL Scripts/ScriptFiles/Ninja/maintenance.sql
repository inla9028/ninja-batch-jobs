select datafield_name, datafield_value, datafield_islocked, datafield_ismandatory, datafield_occurrance
from interf.ninja_datafield_value
where dataset_name = 'CsSrchCtn_in_DSet'
order by datafield_name
