update ninja_datafield_value
set datafield_value = 'NTCTENV9'
where datafield_value = 'NTCTENV6';

commit;
