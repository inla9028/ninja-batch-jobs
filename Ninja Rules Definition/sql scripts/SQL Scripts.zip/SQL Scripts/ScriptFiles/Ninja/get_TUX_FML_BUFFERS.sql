SELECT
    FIELD_SEQ,
    FIELD_NAME,
    FIELD_MAX_OCCURENCE,
    FIELD_TYPE,
    FIELD_SIZE
 FROM NINJADEV.TUX_FML_BUFFERS
where SVC_NAME = 'csApiBan'
and buffer_type = 'IN'
order by field_seq
