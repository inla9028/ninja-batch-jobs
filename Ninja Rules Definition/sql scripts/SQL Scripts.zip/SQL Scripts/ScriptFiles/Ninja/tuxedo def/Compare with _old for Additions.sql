SELECT * 
FROM tux_fml_buffers_new a
WHERE EXISTS (SELECT ' '
              FROM tux_services b
              WHERE b.svc_name = a.svc_name
              AND b.in_use = 'Y')
AND NOT EXISTS (SELECT ' '
                FROM tux_fml_buffers c
                WHERE c.svc_name = a.svc_name
                AND c.buffer_type = a.buffer_type
                AND c.field_name = a.field_name) 
ORDER BY a.svc_name, a.buffer_type,a.field_seq				             
