SELECT a.svc_name, a.in_use
  FROM tux_services_new a
  WHERE NOT EXISTS (SELECT ' ' 
                    FROM tux_services_old b
                    WHERE b.svc_name = a.svc_name)
                    
SELECT a.svc_name, a.in_use
  FROM tux_services_old a
  WHERE NOT EXISTS (SELECT ' ' 
                    FROM tux_services_new b
                    WHERE b.svc_name = a.svc_name)                    
