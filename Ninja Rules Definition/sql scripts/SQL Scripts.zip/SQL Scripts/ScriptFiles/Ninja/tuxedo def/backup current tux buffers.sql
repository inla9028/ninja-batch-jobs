create table tux_fml_buffers_old
as select * from tux_fml_buffers;
commit;
