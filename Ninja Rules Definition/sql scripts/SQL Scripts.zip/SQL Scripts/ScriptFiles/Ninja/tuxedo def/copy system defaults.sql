INSERT INTO system_defaults
SELECT a.key, a.value, a.value_type, a.description
  FROM ninjacstaging.system_defaults@ninjaprod1.world a
  WHERE NOT EXISTS (SELECT ' ' 
                    FROM system_defaults b
                    WHERE b.KEY = a.KEY);
COMMIT;                    
