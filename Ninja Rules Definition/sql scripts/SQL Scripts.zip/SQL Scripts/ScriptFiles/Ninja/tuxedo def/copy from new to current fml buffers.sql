insert into tux_fml_buffers
select * from tux_fml_buffers_new
order by svc_name,buffer_type,field_seq;
commit work;
