insert into tux_services_new (select distinct svc_name,null from tux_fml_buffers_new);
