update tux_fml_buffers_new a
set a.field_def_value = (select b.field_def_value
                        from tux_fml_buffers b
                        where a.svc_name = b.svc_name
                        and a.buffer_type = b.buffer_type
                        and a.field_name = b.field_name);
                        
commit work;                        
