SELECT
svc_name,
    FIELD_SEQ,
    FIELD_NAME,
    FIELD_MAX_OCCURENCE,
    FIELD_TYPE,
    FIELD_SIZE,
    field_def_value
 FROM TUX_FML_BUFFERS
where SVC_NAME like 'csCrCtn%'
and buffer_type = 'IN'
order by svc_name,field_seq
