INSERT INTO tux_services
SELECT * FROM tux_services_new a
WHERE NOT EXISTS (SELECT ' '
                  FROM tux_services b
                  WHERE a.svc_name = b.svc_name)
ORDER BY a.svc_name;
COMMIT;
