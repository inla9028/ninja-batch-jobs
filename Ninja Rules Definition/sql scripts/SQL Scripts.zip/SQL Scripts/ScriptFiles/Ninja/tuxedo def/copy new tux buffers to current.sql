insert into tux_fml_buffers
select *
from tux_fml_buffers_new;
commit work;
