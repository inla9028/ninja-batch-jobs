INSERT INTO tux_services_new
SELECT distinct svc_name, NULL FROM tux_fml_buffers_new;
COMMIT work;
