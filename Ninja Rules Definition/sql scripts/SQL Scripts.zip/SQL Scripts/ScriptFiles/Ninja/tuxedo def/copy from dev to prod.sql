INSERT INTO tux_services
SELECT * FROM tux_services@ninjadevconfig ORDER BY svc_name;
INSERT INTO tux_fml_buffers
SELECT * FROM tux_fml_buffers@ninjadevconfig
ORDER BY svc_name,buffer_type,field_seq;
COMMIT WORK;
