DELETE FROM tux_fml_buffers;
DELETE FROM tux_services;
INSERT INTO tux_services SELECT * FROM ninjacstaging.tux_services;
INSERT INTO tux_fml_buffers
SELECT a.svc_name, a.buffer_type, a.field_name, a.field_seq,
       a.field_type, a.field_size, a.field_max_occurence,
       a.field_def_value
  FROM ninjacstaging.tux_fml_buffers a
  ORDER BY a.svc_name, a.buffer_type, a.field_seq;
  COMMIT WORK;
