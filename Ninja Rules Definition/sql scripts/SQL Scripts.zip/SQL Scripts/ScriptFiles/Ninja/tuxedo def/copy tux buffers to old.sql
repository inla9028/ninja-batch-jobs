insert into tux_fml_buffers_old select * from tux_fml_buffers;
commit work;
