DELETE FROM tux_fml_buffers;
DELETE FROM tux_services;
INSERT INTO tux_services SELECT * FROM ninjacstaging.tux_services@ninjaprod_master.world;
INSERT INTO tux_fml_buffers
SELECT *
  FROM ninjacstaging.tux_fml_buffers@ninjaprod_master.world
  ORDER BY svc_name, buffer_type, field_seq;
  COMMIT WORK;
