INSERT INTO tux_services
SELECT a.svc_name, a.in_use
  FROM tux_services_new a
  ORDER BY a.svc_name;
  COMMIT WORK;
INSERT INTO tux_fml_buffers
SELECT a.svc_name, a.buffer_type, a.field_name, a.field_seq,
       a.field_type, a.field_size, a.field_max_occurence,
       a.field_def_value
  FROM tux_fml_buffers_new a
ORDER BY a.svc_name, a.buffer_type,a.field_seq;
COMMIT;
