
-- Start of DDL script for NINJA_DATAFIELD
-- Generated 15-mai-00  5:23:24 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD

DROP TABLE interf.ninja_datafield
/

-- Table NINJA_DATAFIELD

CREATE TABLE interf.ninja_datafield
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  datafield_type             VARCHAR2(16),
  ismultiple                 NUMBER(*,0),
  datafield_comment          VARCHAR2(80),
  in_use                     NUMBER(*,0)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        1720320
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD

CREATE  UNIQUE INDEX interf.ninja_datafield_name_pk
 ON interf.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_name_pk PRIMARY KEY (dataset_name,datafield_name)
/

ALTER TABLE interf.ninja_datafield
 ADD CONSTRAINT ninja_datafield_dsetname_fk FOREIGN KEY (dataset_name)
      REFERENCES interf.ninja_dataset(dataset_name) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD

-- Start of DDL script for NINJA_DATAFIELD_NAME_PK
-- Generated 15-mai-00  5:23:25 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD_NAME_PK

DROP INDEX interf.ninja_datafield_name_pk
/

-- Index NINJA_DATAFIELD_NAME_PK

CREATE  UNIQUE INDEX interf.ninja_datafield_name_pk
 ON interf.ninja_datafield
  ( dataset_name,
    datafield_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        2580480
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATAFIELD_NAME_PK

-- Start of DDL script for NINJA_DATAFIELD_VALUE
-- Generated 15-mai-00  5:23:25 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD_VALUE

DROP TABLE interf.ninja_datafield_value
/

-- Table NINJA_DATAFIELD_VALUE

CREATE TABLE interf.ninja_datafield_value
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  datafield_name             VARCHAR2(32) NOT NULL,
  username                   VARCHAR2(32) NOT NULL,
  datafield_value            VARCHAR2(2000),
  datafield_islocked         NUMBER(*,0),
  datafield_ismandatory      NUMBER(*,0),
  datafield_occurrance       NUMBER(*,0) NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATAFIELD_VALUE

CREATE  UNIQUE INDEX interf.ninja_datafield_value_pk
 ON interf.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATAFIELD_VALUE

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafield_value_pk PRIMARY KEY (dataset_name,datafield_name,username,
 datafield_occurrance)
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_datafieldv_ds_fk FOREIGN KEY (dataset_name,datafield_name)
      REFERENCES interf.ninja_datafield(dataset_name,datafield_name) ON DELETE CASCADE
/

ALTER TABLE interf.ninja_datafield_value
 ADD CONSTRAINT ninja_user_name_fk FOREIGN KEY (username)
      REFERENCES interf.ninja_user(username) ON DELETE CASCADE
/


-- End of DDL script for NINJA_DATAFIELD_VALUE

-- Start of DDL script for NINJA_DATAFIELD_VALUE_PK
-- Generated 15-mai-00  5:23:25 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATAFIELD_VALUE_PK

DROP INDEX interf.ninja_datafield_value_pk
/

-- Index NINJA_DATAFIELD_VALUE_PK

CREATE  UNIQUE INDEX interf.ninja_datafield_value_pk
 ON interf.ninja_datafield_value
  ( dataset_name,
    datafield_name,
    username,
    datafield_occurrance  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATAFIELD_VALUE_PK

-- Start of DDL script for NINJA_DATASET
-- Generated 15-mai-00  5:23:25 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASET

DROP TABLE interf.ninja_dataset
/

-- Table NINJA_DATASET

CREATE TABLE interf.ninja_dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1),
  dataset_comment            VARCHAR2(80)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        65536
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATASET

CREATE  UNIQUE INDEX interf.ninja_dataset_name_pk
 ON interf.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATASET

ALTER TABLE interf.ninja_dataset
 ADD CONSTRAINT ninja_dataset_name_pk PRIMARY KEY (dataset_name)
/


-- End of DDL script for NINJA_DATASET

-- Start of DDL script for NINJA_DATASETS
-- Generated 15-mai-00  5:23:26 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASETS

DROP VIEW interf.ninja_datasets
/

-- View NINJA_DATASETS

CREATE OR REPLACE VIEW interf.ninja_datasets (
   dataset_name,
   datafield_name,
   datafield_type,
   username,
   datafield_occurrance,
   datafield_value,
   datafield_ismandatory,
   datafield_islocked,
   in_use )
AS
SELECT dset.dataset_name,
       dfield.datafield_name,
       datafield_type,
       usr.username,
       datafield_occurrance,
       datafield_value,
       datafield_ismandatory,
       datafield_islocked,
       dfield.in_use
FROM   ninja_dataset dset,
       ninja_datafield dfield,
       ninja_datafield_value dfieldv,
       ninja_user usr
WHERE  dset.in_use = 1
AND    dset.dataset_name = dfield.dataset_name
AND    dfield.dataset_name = dfieldv.dataset_name
AND    dfield.datafield_name = dfieldv.datafield_name
AND    dfieldv.username = usr.username
/

-- End of DDL script for NINJA_DATASETS

-- Start of DDL script for NINJA_DATASET_NAME_PK
-- Generated 15-mai-00  5:23:26 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASET_NAME_PK

DROP INDEX interf.ninja_dataset_name_pk
/

-- Index NINJA_DATASET_NAME_PK

CREATE  UNIQUE INDEX interf.ninja_dataset_name_pk
 ON interf.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for NINJA_DATASET_NAME_PK

-- Start of DDL script for NINJA_INTERFACE
-- Generated 15-mai-00  5:23:26 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_INTERFACE

DROP PACKAGE interf.ninja_interface
/

-- Package NINJA_INTERFACE

CREATE OR REPLACE
Package INTERF.NINJA_INTERFACE
  IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, initial revision.
-- SAH         000406  Added set_dataset and set_datafield

  -- Create a cursortype for the ninja_datasets view
  TYPE dataset_list IS REF CURSOR RETURN ninja_datasets%ROWTYPE;

  -- Get
  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%type )
    RETURN dataset_list;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER;

  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER;

END; -- Package Specification NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE

-- Start of DDL script for NINJA_INTERFACE
-- Generated 15-mai-00  5:23:26 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_INTERFACE

DROP PACKAGE BODY interf.ninja_interface
/

-- Package body NINJA_INTERFACE

CREATE OR REPLACE
Package Body INTERF.NINJA_INTERFACE
IS

-- Purpose: Procedures and functions to select and update in the ninja
--          environment.
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
-- SAH         000405  Created, Initial revision

  FUNCTION get_datasets
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      username IN NINJA_USER.USERNAME%TYPE )
    RETURN dataset_list
    AS
  BEGIN
    DECLARE dataset_list_c dataset_list;
    BEGIN
      OPEN dataset_list_c FOR
        SELECT * FROM ninja_datasets
        WHERE ninja_datasets.username = username
        AND ninja_datasets.dataset_name = datasetname
        ORDER BY dataset_name, datafield_name;
      RETURN dataset_list_c;
    END;
  END get_datasets;

  -- Insert or update a row in the dataset table
  FUNCTION set_dataset
    ( datasetname IN NINJA_DATASET.DATASET_NAME%type ,
      servicename IN NINJA_DATASET.SERVICE_NAME%type ,
      datasettype IN NINJA_DATASET.DATASET_TYPE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_dataset;


  -- Insert or update a row in the datafield table
  FUNCTION set_datafield
    ( datasetname IN NINJA_DATAFIELD.DATASET_NAME%type ,
      servicename IN NINJA_DATAFIELD.DATAFIELD_NAME%type ,
      datafieldtype IN NINJA_DATAFIELD.DATAFIELD_TYPE%type ,
      occurrance IN NINJA_DATAFIELD.ISMULTIPLE%type )
    RETURN INTEGER
    AS
  BEGIN
    RETURN 1;
  END set_datafield;

END; -- Package Body NINJA_INTERFACE
/

-- End of DDL script for NINJA_INTERFACE

-- Start of DDL script for NINJA_USER
-- Generated 15-mai-00  5:23:26 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_USER

DROP TABLE interf.ninja_user
/

-- Table NINJA_USER

CREATE TABLE interf.ninja_user
 (
  username                   VARCHAR2(32) NOT NULL,
  dataset_name               VARCHAR2(32)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Comments for NINJA_USER

COMMENT ON TABLE interf.ninja_user IS 'Valid users (interfacees) of the NINJA interface'
/

-- Indexes for NINJA_USER

CREATE  UNIQUE INDEX interf.sys_c0056039
 ON interf.ninja_user
  ( username  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_USER

ALTER TABLE interf.ninja_user
 ADD PRIMARY KEY (username)
/


-- End of DDL script for NINJA_USER
