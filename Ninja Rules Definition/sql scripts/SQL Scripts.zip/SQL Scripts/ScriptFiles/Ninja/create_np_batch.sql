
-- Start of DDL script for NP_BATCH
-- Generated 28-jan-02  5:42:17 am
-- from ninjaProd-NINJATEST:1

-- Table NP_BATCH

CREATE TABLE np_batch
 (
  agreement_code             VARCHAR2(15),
  port_date_time             VARCHAR2(14),
  ban                        VARCHAR2(9),
  dealer                     VARCHAR2(5),
  sales_rep                  VARCHAR2(5),
  ctn                        VARCHAR2(8),
  sim                        VARCHAR2(20),
  donor_code                 VARCHAR2(3),
  first_name                 VARCHAR2(32),
  last_name                  VARCHAR2(60),
  addt_title                 VARCHAR2(60),
  postcode                   VARCHAR2(9),
  city                       VARCHAR2(39),
  street_name                VARCHAR2(60),
  house_no                   VARCHAR2(20),
  letter                     VARCHAR2(2),
  floor                      VARCHAR2(2),
  door                       VARCHAR2(4),
  email                      VARCHAR2(90),
  vm_number                  VARCHAR2(8),
  vm_fax_no                  VARCHAR2(8),
  data_asyn                  VARCHAR2(8),
  data_isdn                  VARCHAR2(8),
  data_hs                    VARCHAR2(8),
  processed_date_time        DATE,
  processed_result           VARCHAR2(5),
  processed_message          VARCHAR2(150)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE data
 STORAGE   (
      INITIAL     16384
      NEXT        16384
      PCTINCREASE 0
      MINEXTENTS  2
      MAXEXTENTS  500
   )
/

-- End of DDL script for NP_BATCH
