insert into ngp_nl_assignment(nl,
                              ngp,
                              sys_creation_date,
                              sys_update_date,
                              operator_id,
                              application_id,
                              dl_service_code,
                              dl_update_stamp,
                              aa_sts_cnt,
                              max_inv_lvl,
                              min_inv_lvl,
                              conv_run_no)
                       select 'SNT',
                              ngp,
                              sys_creation_date,
                              sys_update_date,
                              operator_id,
                              application_id,
                              dl_service_code,
                              dl_update_stamp,
                              0,
                              max_inv_lvl,
                              min_inv_lvl,
                              conv_run_no
                       from ngp_nl_assignment 
                       where nl = 'SDR';
commit work;                       
                       
