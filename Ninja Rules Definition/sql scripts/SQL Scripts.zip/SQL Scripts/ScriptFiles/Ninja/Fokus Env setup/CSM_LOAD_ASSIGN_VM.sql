--------------------------------------------------------------------
--- Filename    : CSM_LOAD_ASSIGN_VM.sql
---
--- Patch title :load and assign available number to the default nl
---              in tn_inv table.
---
--- Patch id    : 
--- By          : Miri Shilat
--- Date        : February 2003
---
--- Description :
---
---------------------------------------------------------------------
--- Update      :
--- By          :
--- Description :
---------------------------------------------------------------------

ACCEPT date_time PROMPT 'ENTER DATE+TIME (DDMMYYYYHH24MI): '

spool LOG/pcr385_csm_load_assign_&&date_time

select 'START TIME: '||to_char(sysdate,'mm/dd/yyyy hh24:mi:ss') FROM dual;

sho user

set serveroutput on size 10000
set pages 40
set lines 200
set echo on
set feedback on


------------------------------------------------------------------------
--- create temporary tables.
------------------------------------------------------------------------
drop table pcr385_load_assign_errors;

create table pcr385_load_assign_errors
(CTN VARCHAR2(20),
NGP  CHAR(3),
NL   CHAR(3),
ERROR_MSG      VARCHAR2(100)   )
STORAGE ( INITIAL    1515520          NEXT       262144          MINEXTENTS 1          MAXEXTENTS 2147483645)  TABLESPACE APL_MED;

---alter table pcr385_load_assign_errors ADD CONSTRAINT pcr385_load_assign_errors_pk
---PRIMARY KEY
---(CTN);
---TABLESPACE POOL_IX;
---STORAGE ( INITIAL    1515520          NEXT       262144          MINEXTENTS 1          MAXEXTENTS
-- 2147483645);

------------------------------------------------------------------------
--- Patching the Database.
------------------------------------------------------------------------

------------------------------------------------------------------------
--- Declarations
------------------------------------------------------------------------

DECLARE

ftr_records number;
ctn_count number;
err_count number;
ok_count number;
commit_count number;
err_num NUMBER;
err_msg VARCHAR2(100);
dum_count number;
lower_v   number;
upper_v   number;
ix     number;
tmp_ctn VARCHAR2(100);
tmp_logical_date date;
tmp_nl CHAR(3);

CURSOR tn_grouping_cur IS
SELECT * 
FROM tn_grouping
WHERE NGP='VOC';

tn_grouping_rec tn_grouping_cur%ROWTYPE;

------------------------------------------------------------------------
--- Initialize variables.
------------------------------------------------------------------------

BEGIN

ftr_records:=0;
err_count:=0;
ok_count:=0;
ctn_count:=0;
commit_count:=0;

select logical_date into tmp_logical_date
from logical_date where LOGICAL_DATE_TYPE='O' and expiration_date is null;

OPEN tn_grouping_cur;

dbms_output.enable (1000000);

------------------------------------------------------------------------
--- Fetch records from the cursor and handle them one by one.
------------------------------------------------------------------------


LOOP
    
    FETCH tn_grouping_cur INTO tn_grouping_rec ;
    EXIT WHEN tn_grouping_cur%NOTFOUND;

    ftr_records:=ftr_records+1;
---    dbms_output.put_line('BEGIN_LINE_RANGE:  ' || tn_grouping_rec.BEGIN_LINE_RANGE || '  END_LINE_RANGE: ' || tn_grouping_rec.END_LINE_RANGE || ' NGP: ' || tn_grouping_rec.ngp || ' RANGE_TYPE: ' || tn_grouping_rec.RANGE_TYPE);

--------------------------------------------------------------------
-- For each range load and assign the number to tn_inv
--------------------------------------------------------------------

---    lower_v :=  substr( tn_grouping_rec.BEGIN_LINE_RANGE, 2, 10);
---    upper_v :=  substr( tn_grouping_rec.END_LINE_RANGE, 2, 10);

   lower_v := to_number (substr(tn_grouping_rec.BEGIN_LINE_RANGE,4,8));
     upper_v := to_number(substr( tn_grouping_rec.END_LINE_RANGE,4,8));

---    dbms_output.put_line('lower_v: ' || lower_v || ' upper_v: ' || upper_v);
    
    FOR ix IN lower_v..upper_v LOOP
    
     DECLARE
      next_record EXCEPTION;

     BEGIN
     ctn_count:= ctn_count+1;
     commit_count:= commit_count+1;
 
       tmp_ctn:= '047' || ix;
  
      select count(*) into dum_count from tn_inv where ctn=  tmp_ctn;
      IF( dum_count=1) THEN
        raise next_record;
      END IF;
   
       IF ( tn_grouping_rec.RANGE_TYPE = 'N') THEN
            
            tmp_nl:='SPL';
       ELSE
---           dbms_output.put_line('nl from acctp_ranges');
           select DEFAULT_NL into tmp_nl from acctp_ranges
           where tmp_ctn between RANGE_START and RANGE_END;

       END IF;

       ---dbms_output.put_line('ix: ' || ix || ' ctn: ' || tmp_ctn);

       INSERT INTO TN_INV values (tmp_ctn, sysdate, null, null, 'PCR385', '0', null,  tmp_logical_date, 'MAS', 1, 'AA', tmp_nl,  tn_grouping_rec.ngp, null, 'N', null,null,null,null);

       ---dbms_output.put_line('insert record to tn_inv');

       ok_count:= ok_count+1;

    EXCEPTION
    WHEN next_record THEN
    
   ---       dbms_output.put_line('next_record');
          err_count:=err_count+1; 
          INSERT INTO pcr385_load_assign_errors values (tmp_ctn ,  tn_grouping_rec.ngp  , tmp_nl ,'ctn exists in tn_inv' );
    WHEN NO_DATA_FOUND THEN
      ---    dbms_output.put_line('NO_DATA_FOUND');
        
          err_count:=err_count+1; 
          INSERT INTO pcr385_load_assign_errors values (tmp_ctn ,  tn_grouping_rec.ngp  , tmp_nl ,'No Data found in acctp_ranges' );
          
    WHEN TOO_MANY_ROWS THEN
         --- dbms_output.put_line('TOO_MANY_ROWS');
 
          err_count:=err_count+1; 
          INSERT INTO pcr385_load_assign_errors values (tmp_ctn ,  tn_grouping_rec.ngp  , tmp_nl ,'Too many rows' );
    WHEN others THEN
      ---    dbms_output.put_line('others');
          ---rollback;
          err_num := SQLCODE;
          err_msg := SUBSTR(SQLERRM, 1, 100);

          err_count:=err_count+1; 
---          dbms_output.put_line('failed continue with the next record'); 
          INSERT INTO pcr385_load_assign_errors values (tmp_ctn ,  tn_grouping_rec.ngp  , tmp_nl , err_msg  );
         

      END;

     IF (commit_count = 1000) THEN
         commit;
         commit_count:=0;
     END IF;
     
    END LOOP;


END LOOP;


CLOSE tn_grouping_cur;

commit;

--------------------------------------------------------------------
--  Update ngp_nl_assignment.
--------------------------------------------------------------------
UPDATE   NGP_NL_ASSIGNMENT NGP 
SET (AA_STS_CNT) =  (SELECT COUNT(*)
                     FROM TN_INV  TN 
                    WHERE CTN_STATUS ='AA'    
                     AND NGP.NL=TN.NL
                     AND NGP.NGP=TN.NGP)
WHERE NGP='VOC';

UPDATE NGP_NL_ASSIGNMENT NGP SET AA_STS_CNT =0 
WHERE AA_STS_CNT IS NULL AND NGP='VOC';

commit;

dbms_output.put_line('S T A T I S T I C      R E S U L T S:');
dbms_output.put_line('=====================================');

dbms_output.put_line('Total records from TN_GROUPING that were handled: ' || ftr_records);
dbms_output.put_line('Total CTNs that were handled by this job: ' || ctn_count);
dbms_output.put_line('Total CTNs that were inserted to pcr385_load_assign_errors: ' || err_count);
dbms_output.put_line('Total CTNs that were loaded automaticlly by this job: ' ||ok_count);


END;
/

select 'END TIME: '||to_char(sysdate,'mm/dd/yyyy hh24:mi:ss') FROM dual;
  !send_sms 4792015832 "The load VM patch was finished !!!!!"
  !send_sms 4793038778 "The load VM patch was finished !!!!!"


spool off


