delete from ngp_nl_assignment where nl = 'SNT';
commit work;
