update ninja_datafield_value
set datafield_value = 'ninja'
--where username = 'Ventelo'
where datafield_name = 'APPLICATION_ID'
and dataset_name like '%_in_%';

commit;
-- rollback;
