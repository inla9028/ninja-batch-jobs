SELECT method_name, to_char(TIMESTAMP, 'YYYYMMDD HH24') "Hour", COUNT(*) "Count", round(MAX(used_time)/1000,2) "Max", round(MIN(used_time)/1000,2) "Min", round(AVG(used_time)/1000,2) "Average"
FROM BRAWE.NINJA_RESPONSETIME_LOG
WHERE to_char(TIMESTAMP, 'DDMMYYYY') = '19112002'
GROUP BY method_name, to_char(TIMESTAMP, 'YYYYMMDD HH24')

