insert into ninja_jobs
(job_id, 
 job_status, 
 was_running, 
 sleep_time,
 sleep_mode, 
 next_exec_time, 
 status_time, 
 status_desc,
 bean, 
 method, 
 url, 
 user_name, 
 password, 
 job_desc)
 select 37, 
 job_status, 
 was_running, 
 sleep_time,
 sleep_mode, 
 next_exec_time, 
 status_time, 
 status_desc,
 bean, 
 method, 
 url, 
 user_name, 
 password, 
 job_desc
  FROM ninja_jobs 
  where job_id = 33;
  
  
  commit work;
