update ninja_datafield
set in_use = 1
where exists
    (select ' ' from ninja_dataset where ninja_dataset.dataset_name =  ninja_datafield.dataset_name and
                    ninja_dataset.in_use = 1);

                    commit;
