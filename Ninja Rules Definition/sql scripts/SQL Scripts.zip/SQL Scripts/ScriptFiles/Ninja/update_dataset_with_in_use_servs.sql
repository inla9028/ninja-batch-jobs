update ninja_dataset
set in_use = 1
where service_name in ('blLsUBChg_00','blGtChgCrd_00','arAdjRvrs_00');


commit;
--rollback;
