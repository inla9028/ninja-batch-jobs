select distinct(dataset_name) from ninja_datafield_value
where username = 'midas'
