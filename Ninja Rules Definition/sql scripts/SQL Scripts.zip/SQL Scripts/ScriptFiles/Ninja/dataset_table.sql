
-- Start of DDL script for NINJA_DATASET
-- Generated 6-apr-00  7:14:31 pm
-- from whouse-INTERF:1

-- Drop the old instance of NINJA_DATASET

DROP TABLE interf.ninja_dataset
/

-- Table NINJA_DATASET

CREATE TABLE interf.ninja_dataset
 (
  dataset_name               VARCHAR2(32) NOT NULL,
  service_name               VARCHAR2(32),
  dataset_type               VARCHAR2(16),
  in_use                     NUMBER(1)
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE inter_data01
 STORAGE   (
      INITIAL     40960
      NEXT        40960
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  505
   )
/

-- Indexes for NINJA_DATASET

CREATE  UNIQUE INDEX interf.ninja_dataset_name_pk
 ON interf.ninja_dataset
  ( dataset_name  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE inter_data01
 STORAGE (
   INITIAL     40960
   NEXT        65536
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- Constraints for NINJA_DATASET

ALTER TABLE interf.ninja_dataset
 ADD CONSTRAINT ninja_dataset_name_pk PRIMARY KEY (dataset_name)
/


-- End of DDL script for NINJA_DATASET
