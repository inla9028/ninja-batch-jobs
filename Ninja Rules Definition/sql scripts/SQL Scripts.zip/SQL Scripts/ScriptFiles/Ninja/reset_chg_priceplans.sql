update chg_priceplan_trans
set process_status = 'WAITING', status_desc = null, priority = 4
where process_status = 'PRSD_ERROR' and new_priceplan = 'PKOM';
commit work;
