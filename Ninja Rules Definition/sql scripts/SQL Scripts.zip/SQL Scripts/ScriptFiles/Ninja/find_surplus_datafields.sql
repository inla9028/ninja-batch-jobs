 select * from ninja_datafield
 where not exists (select ''
                  from ninja_datafield_new
                  where dataset_name = ninja_datafield.dataset_name
                  and   datafield_name = ninja_datafield.datafield_name)
