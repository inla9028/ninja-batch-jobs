delete from ninja_tnor_trans;

commit;
