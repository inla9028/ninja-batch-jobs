update ninja_datafield_value
set datafield_value = 'NTCTRN2'
where datafield_name = 'ENV_CODE'
--and username = 'TestUser1'
and dataset_name like '%_in_DSet';
commit;
