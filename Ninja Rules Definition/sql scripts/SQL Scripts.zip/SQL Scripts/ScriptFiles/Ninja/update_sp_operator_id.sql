update ninja_datafield_value
set datafield_value = '200929'
where username = 'ACNuser'
and datafield_name = 'OPERATOR_ID'
and dataset_name like '%_in_%';

commit;
-- rollback;
