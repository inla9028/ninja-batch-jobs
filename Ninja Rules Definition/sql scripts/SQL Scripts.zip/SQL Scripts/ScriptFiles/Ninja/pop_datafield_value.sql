insert into ninja_datafield_value
    (select dataset_name,datafield_name,'tnor',datafield_value,datafield_islocked,datafield_ismandatory,datafield_occurrance
     from ninja_datafield_value
     where username = 'TestUser1');

     commit;
