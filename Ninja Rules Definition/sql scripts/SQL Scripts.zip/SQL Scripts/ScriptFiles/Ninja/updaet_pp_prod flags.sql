update ninja_pp_prods
set optionality_ind ='P', displayable_ind ='Y', addition_ind = 'P', deletion_ind = 'Y'
where soc_code in  ('VMFREE+')
and price_plan like 'PPT%';
--product_name = 'CALLDETS';
commit;
