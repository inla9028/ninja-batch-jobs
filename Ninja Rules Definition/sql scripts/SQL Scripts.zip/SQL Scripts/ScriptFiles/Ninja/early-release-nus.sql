update reserved_numbers set reserved_date = reserved_date -2
where reserved_date < sysdate -.005;
commit work;
