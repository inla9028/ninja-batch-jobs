update ninja_datafield_value
set datafield_value = 'NTC'
where dataset_name like '%_in_%'
and datafield_name = 'MARKET_CODE'
and username = 'TestUser1';

commit;
