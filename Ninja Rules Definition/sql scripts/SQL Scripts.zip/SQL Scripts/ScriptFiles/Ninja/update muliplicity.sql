update ninja_datafield a
set a.ismultiple = (select b.ismultiple 
                    from ninja_datafield_new b
                    where a.dataset_name = b.dataset_name
                    and a.datafield_name = b.datafield_name
                    and b.ismultiple <> a.ismultiple);
                    
commit work;                    
                     
