--insert into ntctapp8.serial_item_inv t1
select t2.*
from serial_item_inv@prod.world t2, mw_tmp_sim t3
where t2.serial_number = t3.equipment_no
and rownum < 100
--commit;
