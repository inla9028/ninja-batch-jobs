select * from ninjaactst.ninja_datafield_value a
where not exists (select ' ' from ninja_datafield_value b
                  where a.dataset_name = b.dataset_name
                  and   a.datafield_name = b.datafield_name
                  and   a.username = b.username
                  and   a.datafield_occurrance = b.datafield_occurrance)
                  and a.datafield_value is not null
