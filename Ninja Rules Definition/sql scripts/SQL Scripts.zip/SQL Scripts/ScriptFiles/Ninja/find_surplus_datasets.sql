select * from ninja_dataset
where not exists (select ' ' from ninja_dataset_new where dataset_name = ninja_dataset.dataset_name)
