update ninja_dataset set in_use = 1 where dataset_name in ('CsSrchCtn_in_DSet', 'CsSrchCtn_out_DSet',
'GnLsUsrPrm_in_DSet', 'GnLsUsrPrm_out_DSet',
'ArGtCstBan_in_DSet', 'ArGtCstBan_out_DSet',
'BlLsUBInfo_in_DSet', 'BlLsUBInfo_out_DSet',
'ArGtOcInfo_in_DSet', 'ArGtOcInfo_out_DSet',
'ArCrCrg_in_DSet', 'ArCrCrg_out_DSet',
'ArBanBal_in_Dset', 'ArBanBal_out_Dset'
)
