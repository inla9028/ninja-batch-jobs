grant select on ninja_dataset to ninjaactst;
grant select on ninja_datafield to ninjaactst;
grant select on ninja_datafield_value to ninjaactst;
grant select on ninja_user to ninjaactst;
