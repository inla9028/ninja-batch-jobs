
-- Start of DDL script for FOKUS_FEATURES_IDX_1
-- Generated 20-Dec-99  11:15:26 am
-- from wh-CNVRTD:1

-- Index FOKUS_FEATURES_IDX_1

CREATE  INDEX fokus_features_idx_1
 ON fokus_features
  ( imsi,
    feature,
    sub_no  )
  TABLESPACE cnvrt_index
/

-- End of DDL script for FOKUS_FEATURES_IDX_1
