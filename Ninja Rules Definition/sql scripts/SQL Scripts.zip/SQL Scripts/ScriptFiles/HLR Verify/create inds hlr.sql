
-- Start of DDL script for HLR_IDX_1
-- Generated 20-Dec-99  11:16:19 am
-- from wh-CNVRTD:1

-- Index HLR_IDX_1

CREATE  INDEX hlr_idx_1
 ON hlr
  ( imsi,
    basic_service_code,
    capability_1,
    capability_2,
    sub_no  )
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  TABLESPACE cnvrt_index
 STORAGE (
   INITIAL     40960
   NEXT        40960
   PCTINCREASE 50
   MINEXTENTS  1
   MAXEXTENTS  505
   )
/

-- End of DDL script for HLR_IDX_1
