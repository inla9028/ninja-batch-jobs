----------------------------------------------------------------
PROMPT Creating index: CNVRT_SUBS_IDX1
CREATE INDEX	cnvrt_subs_idx1
ON		cnvrt_subs( subscriber_no  )
TABLESPACE	cnvrt_index;


-- Idexes for links file
CREATE INDEX TMP_BAN_IDX1
ON TMP_BAN
 (  TMP_ACCT
 )
TABLESPACE CNVRT_INDEX;

