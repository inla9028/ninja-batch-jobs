select count(*) from sms_send where sms_sendt is null
