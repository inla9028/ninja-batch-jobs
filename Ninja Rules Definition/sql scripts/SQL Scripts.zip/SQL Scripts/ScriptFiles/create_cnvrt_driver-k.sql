insert
into cnvrt_driver
select c_acct,c_contract
from contract
where c_cont_status in('AC','SU') and
    c_cycle_code = '10'

