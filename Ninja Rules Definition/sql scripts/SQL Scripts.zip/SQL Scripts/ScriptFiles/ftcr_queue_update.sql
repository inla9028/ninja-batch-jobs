update ftcr_queue
set ftcr_robot_no = 1
where ftcr_robot_no is null;
commit;
