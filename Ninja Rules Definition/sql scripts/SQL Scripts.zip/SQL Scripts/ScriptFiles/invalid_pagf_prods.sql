SELECT  *
FROM    PAG_F
WHERE   c_pag_phone_status IN ('AC','SU')
AND     c_primary_prod IN ('ISDND24','FAKSNUM')
 
