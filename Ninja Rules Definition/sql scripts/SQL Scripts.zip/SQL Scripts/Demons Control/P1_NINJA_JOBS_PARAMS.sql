SELECT a.machine_id, a.job_id, a.parameter_order, a.parameter_value,
       a.parameter_description
  FROM ninja_jobs_parameters a
  WHERE a.machine_id = 'NINJAP1_DEMON'
  ORDER BY a.job_id
