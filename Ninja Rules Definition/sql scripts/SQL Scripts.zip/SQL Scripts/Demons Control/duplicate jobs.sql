INSERT INTO ninja_jobs
SELECT a.machine_id, 
       58, 
       a.job_status, 
       a.was_running,
       a.sleep_time, 
       sysdate, 
       a.status_time, 
       a.status_desc,
       a.exec_method, 
       a.job_desc, 
       a.fixed_start, 
       a.hlr_based
  FROM ninja_jobs a
  WHERE a.machine_id = 'NINJAP2_DEMON'
  AND a.job_id = 50;
COMMIT;
INSERT INTO ninja_jobs_parameters
SELECT a.machine_id, 
       58, 
       a.parameter_order, 
       a.parameter_value,
       a.parameter_description
  FROM ninja_jobs_parameters a
  WHERE a.machine_id = 'NINJAP2_DEMON'
  AND a.job_id = 50;
  COMMIT;
