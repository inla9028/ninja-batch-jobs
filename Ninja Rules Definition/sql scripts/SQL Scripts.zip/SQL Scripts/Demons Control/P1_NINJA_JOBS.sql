SELECT a.machine_id, a.job_id, a.job_status, a.was_running,
       a.sleep_time, a.next_exec_time, a.status_time, a.status_desc,
       a.exec_method, a.job_desc, a.fixed_start, a.hlr_based
  FROM ninja_jobs a
  WHERE a.machine_id = 'NINJAP1_DEMON'
  ORDER BY a.job_id
