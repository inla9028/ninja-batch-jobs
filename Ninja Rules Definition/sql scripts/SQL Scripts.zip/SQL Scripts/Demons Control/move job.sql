UPDATE ninja_jobs
SET job_status = 'STOPPING'
WHERE job_id = 3;
COMMIT;


UPDATE ninja_jobs
SET machine_id = 'NINJAP2_DEMON'
WHERE job_id = 3;
UPDATE ninja_jobs_parameters
SET machine_id = 'NINJAP2_DEMON'
WHERE job_id = 3;
COMMIT WORK;


UPDATE ninja_jobs
SET job_status = 'STARTING'
WHERE job_id = 1;
COMMIT WORK;


