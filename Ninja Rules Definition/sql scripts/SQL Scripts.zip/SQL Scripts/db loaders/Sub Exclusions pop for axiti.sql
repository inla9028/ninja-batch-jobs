DELETE FROM ninjaconfig.ninja_subscriber_exclusions;
INSERT INTO ninjaconfig.ninja_subscriber_exclusions
SELECT subscriber_no, SYSDATE-1, TO_DATE('31124700','DDMMYYYY'), 'Subscription is owned by Axiti (Service Provider)'
FROM mw_tmp_subs_axiti@fokusninja;
COMMIT WORK;
