UPDATE mw_tmp_npdb_nos a
SET a.fokus_ban = (SELECT b.customer_id
                   FROM ntcappo.subscriber b
                   WHERE b.subscriber_no = a.mapped_to_fokus_sub
                   AND b.sub_status IN ('A','R','S'))
 WHERE a.fokus_subscriber_no IS NULL
 AND a.fokus_ban IS NULL 
 AND a.mapped_to_fokus_sub IS NOT NULL;
 COMMIT;
 
UPDATE mw_tmp_npdb_nos a
SET a.fokus_ban = (SELECT distinct(b.customer_id)
                   FROM ntcappo.service_feature b
                   WHERE b.ftr_special_telno = a.mapped_to_fokus_sub
                   AND SYSDATE BETWEEN b.ftr_effective_date AND b.ftr_expiration_date)
 WHERE a.fokus_subscriber_no IS NULL
 AND a.fokus_ban IS NULL 
 AND a.mapped_to_fokus_sub IS NOT NULL;
 COMMIT;
 
