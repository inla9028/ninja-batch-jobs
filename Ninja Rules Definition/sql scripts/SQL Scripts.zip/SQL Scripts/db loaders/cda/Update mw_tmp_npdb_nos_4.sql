UPDATE mw_tmp_npdb_nos a
SET a.pabx_leading_number = (SELECT c.leading_number
                   FROM ntcrefolc_lng5.pabx_tn_range b, ntcrefolc_lng5.pabx_list c
                   WHERE a.fixed_line_no BETWEEN b.tn_start_range AND b.tn_end_range
				   AND c.pabx_id = b.pabx_id)
WHERE a.fokus_subscriber_no IS NULL;
COMMIT;                   
               
                   

