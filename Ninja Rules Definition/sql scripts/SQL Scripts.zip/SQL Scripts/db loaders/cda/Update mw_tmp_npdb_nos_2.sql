UPDATE mw_tmp_npdb_nos a
SET a.fokus_subscriber_no = 'CDA' || a.fixed_line_no, a.fokus_sub_status = 'C' 
WHERE a.fokus_subscriber_no IS NULL
AND EXISTS  (SELECT ' '
             FROM ntcappo.subscriber b
             WHERE b.subscriber_no = 'CDA' || a.fixed_line_no);
COMMIT;             

UPDATE mw_tmp_npdb_nos a
SET a.fokus_subscriber_no = 'PBX' || a.fixed_line_no, a.fokus_sub_status = 'C' 
WHERE a.fokus_subscriber_no IS NULL
AND EXISTS  (SELECT ' '
             FROM ntcappo.subscriber b
             WHERE b.subscriber_no = 'PBX' || a.fixed_line_no);
COMMIT;             



