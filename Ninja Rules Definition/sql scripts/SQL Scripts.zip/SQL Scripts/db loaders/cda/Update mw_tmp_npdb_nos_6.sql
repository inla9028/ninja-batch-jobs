UPDATE mw_tmp_npdb_nos a
SET (a.cug_soc, a.cug_parms) = (SELECT RTRIM(b.soc), RTRIM(b.ftr_add_sw_prm)
                                FROM ntcappo.service_feature b
                                WHERE b.ftr_special_telno = 'PBX' || a.pabx_leading_number
                                AND SYSDATE BETWEEN b.ftr_effective_date AND b.ftr_expiration_date
                                AND b.feature_code = 'CUG')
 WHERE a.fokus_subscriber_no IS NULL
  AND a.fokus_ban IS NOT NULL;
  COMMIT;
  
