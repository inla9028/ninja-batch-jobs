UPDATE mw_tmp_npdb_nos a
SET (a.fokus_ban_status , a.fokus_ban_type ) = (SELECT b.ban_status, b.account_type || RTRIM(b.account_sub_type)
                                                FROM ntcappo.billing_account b
                                                WHERE b.customer_id = a.fokus_ban)
WHERE a.fokus_subscriber_no IS NULL
 AND a.fokus_ban IS not NULL;
 COMMIT;
  
