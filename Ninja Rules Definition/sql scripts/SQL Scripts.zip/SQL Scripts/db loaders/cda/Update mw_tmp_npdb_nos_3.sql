UPDATE mw_tmp_npdb_nos a
SET a.ban_count = (SELECT COUNT(DISTINCT(b.customer_id))
                   FROM ntcappo.subscriber b
                   WHERE b.subscriber_no = a.fokus_subscriber_no)
WHERE a.fokus_subscriber_no IS NOT NULL
AND a.fokus_sub_status = 'C';
COMMIT;                   
               
                   

