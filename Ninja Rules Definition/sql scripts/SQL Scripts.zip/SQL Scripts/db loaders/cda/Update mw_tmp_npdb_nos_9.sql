UPDATE mw_tmp_npdb_nos a
SET (a.fokus_ban,a.fokus_sub_status) = (SELECT b.customer_id, b.sub_status 
                   FROM ntcappo.subscriber b
                   WHERE b.subscriber_no = 'PBX' || a.pabx_leading_number
                   AND b.sub_status IN ('A','S','R'))
WHERE a.fokus_subscriber_no IS NULL
  AND a.pabx_leading_number IS not NULL;
  COMMIT;
