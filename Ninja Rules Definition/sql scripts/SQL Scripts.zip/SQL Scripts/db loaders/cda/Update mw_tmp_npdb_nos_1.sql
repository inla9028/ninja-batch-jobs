UPDATE mw_tmp_npdb_nos a
SET (a.fokus_subscriber_no,a.fokus_ban,a.fokus_sub_status) 
        = (SELECT b.subscriber_no, b.customer_id, b.sub_status
             FROM ntcappo.subscriber b
             WHERE b.subscriber_no = 'CDA' || a.fixed_line_no
             AND b.sub_status IN ('A','R','S'))
WHERE a.fokus_subscriber_no IS NULL;
COMMIT;             

UPDATE mw_tmp_npdb_nos a
SET (a.fokus_subscriber_no,a.fokus_ban,a.fokus_sub_status) 
        = (SELECT b.subscriber_no, b.customer_id, b.sub_status
             FROM ntcappo.subscriber b
             WHERE b.subscriber_no = 'PBX' || a.fixed_line_no
             AND b.sub_status IN ('A','R','S'))
WHERE a.fokus_subscriber_no IS NULL;
COMMIT;             



