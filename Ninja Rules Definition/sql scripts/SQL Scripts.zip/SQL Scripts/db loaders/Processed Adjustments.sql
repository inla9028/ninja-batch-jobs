SELECT a.process_status, SUM(a.amount), COUNT(*)
FROM batch_adjustment_addition a
  WHERE a.request_id = 'NET 15.06.2005'
  group BY a.process_status
