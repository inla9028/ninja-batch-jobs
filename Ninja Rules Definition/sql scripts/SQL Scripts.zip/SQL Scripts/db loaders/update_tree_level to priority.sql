UPDATE mw_tmp_can_bans SET tree_level = 10 - tree_level;

COMMIT WORK;
