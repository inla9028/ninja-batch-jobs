UPDATE fokus.smsc_ad_soc_batch a
SET (a.processed, a.processed_date, a.ninja_status_text) = (SELECT 'R', b.process_time, NVL(b.status_desc, b.process_status) 
                                                            FROM fokus_smsc_ad_soc_batch_n@ninja b
                                                            WHERE b.subscriber_no = a.subscriber_no
                                                            AND b.request_id = to_char(a.request_seq_no))
WHERE a.processed IS NULL;
COMMIT; 
                                                           
INSERT INTO fokus_smsc_ad_soc_batch_n@ninja
SELECT null, a.subscriber_no, a.soc, a.action, null,
       a.timestamp, a.timestamp, null, 'WAITING',
       null, null, null, '3',
       a.request_seq_no, null, null, '1'
  FROM fokus.smsc_ad_soc_batch a
  WHERE a.processed IS null;
COMMIT;

