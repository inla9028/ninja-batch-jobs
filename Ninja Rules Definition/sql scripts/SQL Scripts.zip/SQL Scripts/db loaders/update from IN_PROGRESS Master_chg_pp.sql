UPDATE master_chg_pp_trans SET process_status = 'WAITING'
WHERE process_status = 'IN_PROGRESS'
AND requestor_id = 'KRI 08.12.2005';
COMMIT WORK;
