UPDATE mw_tmp_pptbk_subs a
SET a.existing = (SELECT rtrim(b.soc) 
                  FROM service_agreement@prod.world b 
				  WHERE a.subscriber_no = b.subscriber_no
				  AND b.expiration_date > SYSDATE 
				  AND b.service_type = 'P');
COMMIT;


UPDATE mw_tmp_pptbk_subs a
SET a.existing_tb_soc = (SELECT rtrim(b.soc) 
                  FROM service_agreement@prod.world b 
				  WHERE a.subscriber_no = b.subscriber_no
				  AND b.soc LIKE 'MCT%'
				  AND b.service_type = 'R'
				  AND b.expiration_date > SYSDATE );
COMMIT;

UPDATE mw_tmp_pptbk_subs
SET new_priceplan = 'PSTB' 
WHERE new_priceplan IS NULL AND existing = 'PSFB';
UPDATE mw_tmp_pptbk_subs
SET new_priceplan = 'PSUB' 
WHERE new_priceplan IS NULL AND existing = 'PSGB';

UPDATE mw_tmp_pptbk_subs
SET new_priceplan = existing 
WHERE new_priceplan IS NULL AND existing IN ('PSTB','PSUB');
COMMIT;

						  

