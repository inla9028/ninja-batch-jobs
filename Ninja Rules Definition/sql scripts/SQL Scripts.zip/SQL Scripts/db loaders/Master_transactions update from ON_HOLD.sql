UPDATE master_transactions SET process_status = 'WAITING'
WHERE process_status = 'ON_HOLD' AND request_id = 'KRF 17.02.2005';
COMMIT WORK;
