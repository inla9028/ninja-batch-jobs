UPDATE tb_processing_trans SET process_status = 'WAITING'
WHERE process_status = 'IN_PROGRESS';
COMMIT WORK;
