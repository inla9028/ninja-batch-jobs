UPDATE ninjadata.sp_pp_activations a SET a.process_status = 'WAITING',a.status_desc = null
  WHERE a.process_status = 'PRSD_ERROR' and
  a.sp_code = 'ChessUser' AND a.status_desc LIKE 'Failed to create subscription.  Due to : PEE000000: General Non Specified Error.: Error occured while calling tuxedo service. Ban is in use%';
  COMMIT;
