
INSERT INTO mw_tmp_vm_subs(
vm_main_tn, 
vm_fax_tn, 
vm_vm_tn, 
vm_vm_email,
vm_msg_type, 
vm_msg_data_type, 
vm_msg_keep_delete,
fokus_sub)
SELECT  '047' || a.sub_main_tn, '047' || a.sub_fax_tn, '047' || a.sub_vm_tn, a.sub_vm_email,
       a.sub_msg_type, a.sub_msg_data_type, a.sub_msg_keep_delete, 'GSM047' || a.sub_main_tn
  FROM mw_tmp_trm_subs a;
  COMMIT;
  
