UPDATE mw_tmp_vm_subs a
SET a.fokus_ban = (SELECT b.customer_id 
				   FROM subscriber@prod.world b
				   WHERE b.subscriber_no = a.fokus_sub
				   AND b.sub_status IN ('A','R','S'));
COMMIT;				   
UPDATE mw_tmp_vm_subs a
SET a.fokus_vm_soc = (SELECT RTRIM(b.soc) 
                     FROM service_agreement@prod.world b
                     WHERE b.subscriber_no = a.fokus_sub
                     AND b.customer_id = a.fokus_ban
                     AND b.expiration_date > SYSDATE
                     AND b.soc LIKE 'V%'
                     AND EXISTS (SELECT ' ' FROM ninjarules.socs c
                     WHERE RTRIM(b.soc) = c.soc
                     AND c.soc_type = 'VOICEMAIL'));
COMMIT;                     

UPDATE mw_tmp_vm_subs a
SET a.fokus_vmemail_soc = (SELECT RTRIM(b.soc) 
                     FROM service_agreement@prod.world b
                     WHERE b.subscriber_no = a.fokus_sub
                     AND b.customer_id = a.fokus_ban
                     AND b.expiration_date > SYSDATE
                     AND b.soc LIKE 'V%'
                     AND EXISTS (SELECT ' ' FROM ninjarules.socs c
                     WHERE RTRIM(b.soc) = c.soc
                     AND c.soc_type = 'VMFRWRD'));
COMMIT;                     
                     

UPDATE mw_tmp_vm_subs a
SET a.fokus_vm_ctn = (SELECT RTRIM(b.ftr_special_telno) 
                     FROM service_feature@prod.world b
                     WHERE b.subscriber_no = a.fokus_sub
                     AND b.customer_id = a.fokus_ban
                     AND nvl(b.ftr_expiration_date, sysdate +1) > SYSDATE
                     AND rtrim(b.soc) = a.fokus_vm_soc
					 AND b.feature_code = (SELECT c.feature_code 
					                       FROM ninjarules.feature_parameters c
										   WHERE b.soc = c.soc
										   AND c.parameter_code = 'VMMSISDN'
										   AND c.parameter_type = 'CTN'))
					 WHERE a.fokus_vm_soc IS NOT null;
COMMIT; 
   
UPDATE mw_tmp_vm_subs a                    
SET a.fokus_vm_fax_ctn = (SELECT RTRIM(b.ftr_special_telno) 
                     FROM service_feature@prod.world b
                     WHERE b.subscriber_no = a.fokus_sub
                     AND b.customer_id = a.fokus_ban
                     AND nvl(b.ftr_expiration_date, sysdate +1) > SYSDATE
                     AND rtrim(b.soc) = a.fokus_vm_soc
					 AND b.feature_code = (SELECT c.feature_code 
					                       FROM ninjarules.feature_parameters c
										   WHERE b.soc = c.soc
										   AND c.parameter_code = 'FAXNO'
										   AND c.parameter_type = 'CTN'))
					 WHERE a.fokus_vm_soc IS NOT null;
COMMIT; 

