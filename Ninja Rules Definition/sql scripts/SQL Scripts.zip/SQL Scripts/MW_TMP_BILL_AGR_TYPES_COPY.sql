SELECT a.bill_agr_types_sub_id, a.agreement_type, a.ban_tree_ind,
       a.account_type, a.account_sub_type, a.org_priceplan,
       a.new_priceplan, a.org_commitment_band, a.new_commitment_months,
       a.new_campaign_id, a.remaining_com_months,
       a.subscription_type_id, a.effective_date, a.expiration_date,
       a.handset_provisioning, a.bill_desc_id_en, a.bill_desc_id_no,
       a.new_bill_agr_types_sub_ib
  FROM mw_tmp_bill_agr_types_copy a
  WHERE NOT EXISTS (SELECT ' ' 
                    FROM bill_agr_types_sub_types b
                    WHERE b.agreement_type = a.agreement_type
                    AND b.ban_tree_ind = a.ban_tree_ind
                    AND b.account_type = a.account_type
                    AND b.account_sub_type = a.account_sub_type
                    AND b.org_priceplan = a.org_priceplan
                    AND b.new_priceplan = a.new_priceplan
                    AND b.org_commitment_band = a.org_commitment_band
                    AND b.new_commitment_months = a.new_commitment_months
                    AND b.new_campaign_id = a.new_campaign_id
                    AND b.remaining_com_months = a.remaining_com_months
                    AND b.subscription_type_id = a.subscription_type_id)
  
