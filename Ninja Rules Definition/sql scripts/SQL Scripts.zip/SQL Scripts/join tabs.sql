INSERT INTO bill_agr_typ_sub_x_desc
SELECT a.bill_agr_types_sub_id, b.bill_agr_name_id, b.language_code
FROM mw_tmp_missing a, mw_tmp_descs b
WHERE a.agreement_type = b.agreement_type
AND a.account_type = b.account_type
AND a.account_sub_type = b.account_sub_type
AND a.new_priceplan = b.new_priceplan
AND a.new_campaign_id = b.new_campaign_id
ORDER BY a.new_priceplan, a.new_campaign_id, b.language_code
