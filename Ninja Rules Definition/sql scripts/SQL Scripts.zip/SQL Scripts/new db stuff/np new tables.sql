-- Start of DDL Script for Sequence NINJADATA.NINJA_REF_SEQ
-- Generated 20-sep-2005 8:42:17 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE SEQUENCE ninja_ref_seq
  INCREMENT BY 1
  START WITH 1
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  ORDER
  CACHE 20
/

-- End of DDL Script for Sequence NINJADATA.NINJA_REF_SEQ

-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT
-- Generated 20-sep-2005 8:42:30 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    nrdb_ref_id                    VARCHAR2(20) NOT NULL,
    user_id                        VARCHAR2(16) NOT NULL,
    ctn                            VARCHAR2(11) NOT NULL,
    ban                            NUMBER(9,0),
    number_owner_code              VARCHAR2(10) NOT NULL,
    donor_code                     VARCHAR2(10) NOT NULL,
    recipient_code                 VARCHAR2(10) NOT NULL,
    date_time_created              DATE NOT NULL,
    date_time_modified             DATE NOT NULL,
    date_time_port                 DATE NOT NULL,
    description                    VARCHAR2(600),
    action                         VARCHAR2(4) NOT NULL,
    proc_attempts                  NUMBER(*,0) DEFAULT 0   NOT NULL,
    status                         VARCHAR2(20) NOT NULL,
    ninja_action                   VARCHAR2(15))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     104857600
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Indexes for NINJA_TIME_PORT

CREATE UNIQUE INDEX ntp_idx1 ON ninja_time_port
  (
    ninja_ref_id                    ASC
  )
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/



-- Constraints for NINJA_TIME_PORT

ALTER TABLE ninja_time_port
ADD CONSTRAINT ntp_pk1 PRIMARY KEY (ninja_ref_id)
/


-- Triggers for NINJA_TIME_PORT

CREATE OR REPLACE TRIGGER NINJA_TIME_PORT_TRG1
 BEFORE 
 INSERT OR UPDATE
 ON NINJA_TIME_PORT
 REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE
    v_cnt1 NUMBER;
BEGIN
		IF INSERTING
		THEN
		   IF :new.ninja_ref_id IS NULL
		   THEN
            SELECT COUNT(*)
            INTO v_cnt1
            FROM NINJA_TIME_PORT
            WHERE (ctn = :new.ctn and proc_attempts = 0 and action = :new.action);
            IF v_cnt1 != 0
            THEN
                  RAISE_APPLICATION_ERROR( -20001, 'CTN exists in pending state within the porting table' );
            END IF;

            SELECT	ninja_np_ref_seq.nextval
			INTO	:new.ninja_ref_id
			FROM 	dual;
			END IF;
		END IF;
	END;
/


-- Comments for NINJA_TIME_PORT

COMMENT ON COLUMN ninja_time_port.action IS 'Ninja action to perform when retrieving the request.'
/
COMMENT ON COLUMN ninja_time_port.ban IS 'The Fokus Billing to transfer the Subscription to (In case of SP this is picked up at runtime).'
/
COMMENT ON COLUMN ninja_time_port.ctn IS 'Main CTN for the Porting Request.'
/
COMMENT ON COLUMN ninja_time_port.date_time_created IS 'Date/Time YYYYMMDDHHMMSS of the entry into the Table.'
/
COMMENT ON COLUMN ninja_time_port.date_time_modified IS 'Date/Time YYYYMMDDHHMMSS of the last update of the Request.'
/
COMMENT ON COLUMN ninja_time_port.date_time_port IS 'Date/Time YYYYMMDDHHMMSS the port should take place.'
/
COMMENT ON COLUMN ninja_time_port.description IS 'Description of the result of the latest processing.  Max 600 characters.'
/
COMMENT ON COLUMN ninja_time_port.donor_code IS 'NRDB code of operator currently having the CTN.'
/
COMMENT ON COLUMN ninja_time_port.ninja_action IS 'The Action That Ninja will Perform (SP_MOVE, NETCOM_MOVE etc)'
/
COMMENT ON COLUMN ninja_time_port.ninja_ref_id IS 'Unique key. Automatically generated upon insert.'
/
COMMENT ON COLUMN ninja_time_port.nrdb_ref_id IS 'NRDB reference ID.'
/
COMMENT ON COLUMN ninja_time_port.number_owner_code IS 'NRDB code of operator owning the CTN.'
/
COMMENT ON COLUMN ninja_time_port.proc_attempts IS 'Number of attemts to process this record.'
/
COMMENT ON COLUMN ninja_time_port.recipient_code IS 'NRDB code of operator receiving the CTN.'
/
COMMENT ON COLUMN ninja_time_port.status IS 'One description of process status.  WAITING, PRSD_SUCCESS, PRSD_ERROR.'
/
COMMENT ON COLUMN ninja_time_port.user_id IS 'User entering the request.'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT

-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_ADT_INFO
-- Generated 20-sep-2005 8:42:46 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_adt_info
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    org_membership_code            VARCHAR2(10),
    org_membership_no              VARCHAR2(30),
    org_membership_eff_date        DATE)
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     10485760
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Constraints for NINJA_TIME_PORT_ADT_INFO


ALTER TABLE ninja_time_port_adt_info
ADD CONSTRAINT ntpai_pk1 PRIMARY KEY (ninja_ref_id)
USING INDEX
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/


-- Comments for NINJA_TIME_PORT_ADT_INFO

COMMENT ON COLUMN ninja_time_port_adt_info.ninja_ref_id IS 'Unique Key for the Port Order'
/
COMMENT ON COLUMN ninja_time_port_adt_info.org_membership_code IS 'Membership Code'
/
COMMENT ON COLUMN ninja_time_port_adt_info.org_membership_eff_date IS 'The Membership effective Date'
/
COMMENT ON COLUMN ninja_time_port_adt_info.org_membership_no IS 'The Membership Number'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_ADT_INFO

-- Foreign Key
ALTER TABLE ninja_time_port_adt_info
ADD CONSTRAINT ntpadi_con1 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)


-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_ADT_NOS
-- Generated 20-sep-2005 8:43:03 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_adt_nos
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    additional_ctn                 VARCHAR2(20))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     10485760
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Indexes for NINJA_TIME_PORT_ADT_NOS

CREATE INDEX ntpan_idx1 ON ninja_time_port_adt_nos
  (
    ninja_ref_id                    ASC
  )
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/



-- Constraints for NINJA_TIME_PORT_ADT_NOS



-- Comments for NINJA_TIME_PORT_ADT_NOS

COMMENT ON COLUMN ninja_time_port_adt_nos.additional_ctn IS 'The Additional TelNo being Ported in'
/
COMMENT ON COLUMN ninja_time_port_adt_nos.ninja_ref_id IS 'Unique Key for the Port Order'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_ADT_NOS

-- Foreign Key
ALTER TABLE ninja_time_port_adt_nos
ADD CONSTRAINT ntpan_con1 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)


-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_EQUIPMENT
-- Generated 20-sep-2005 8:43:32 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_equipment
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    equipment_type                 VARCHAR2(1) NOT NULL,
    equipment_number               VARCHAR2(20) NOT NULL,
    primary_ind                    VARCHAR2(1))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     41943040
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Indexes for NINJA_TIME_PORT_EQUIPMENT

CREATE INDEX ntpe_idx1 ON ninja_time_port_equipment
  (
    ninja_ref_id                    ASC
  )
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     40960
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/



-- Constraints for NINJA_TIME_PORT_EQUIPMENT



-- Comments for NINJA_TIME_PORT_EQUIPMENT

COMMENT ON COLUMN ninja_time_port_equipment.equipment_number IS 'Equipment Number'
/
COMMENT ON COLUMN ninja_time_port_equipment.equipment_type IS 'Equipment Type ''E'' -Sim Card, ''H'' - Handset'
/
COMMENT ON COLUMN ninja_time_port_equipment.ninja_ref_id IS 'Unique Key for the Port Order'
/
COMMENT ON COLUMN ninja_time_port_equipment.primary_ind IS 'At least 1 Sim Card must be Primary'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_EQUIPMENT

-- Foreign Key
ALTER TABLE ninja_time_port_equipment
ADD CONSTRAINT ntpe_con1 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)


-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SERVICES
-- Generated 20-sep-2005 8:43:42 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_services
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    soc                            VARCHAR2(9) NOT NULL,
    dealer_code                    VARCHAR2(5),
    sales_agent                    VARCHAR2(5),
    priceplan_soc                  VARCHAR2(1))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     31457280
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Constraints for NINJA_TIME_PORT_SERVICES


ALTER TABLE ninja_time_port_services
ADD CONSTRAINT ntps_pk1 PRIMARY KEY (ninja_ref_id, soc)
USING INDEX
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/


-- Comments for NINJA_TIME_PORT_SERVICES

COMMENT ON COLUMN ninja_time_port_services.dealer_code IS 'Dealer Code Adding the Service'
/
COMMENT ON COLUMN ninja_time_port_services.ninja_ref_id IS 'Unique Key for the Port Order'
/
COMMENT ON COLUMN ninja_time_port_services.priceplan_soc IS '''Y'' - Indicates the Priceplan'
/
COMMENT ON COLUMN ninja_time_port_services.sales_agent IS 'Sales Agent Activating the Service'
/
COMMENT ON COLUMN ninja_time_port_services.soc IS 'The Fokus Soc Code'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SERVICES

-- Foreign Key
ALTER TABLE ninja_time_port_services
ADD CONSTRAINT ntps_con1 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)


-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SRV_FTR_PRMS
-- Generated 20-sep-2005 8:43:54 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_srv_ftr_prms
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    soc                            VARCHAR2(9) NOT NULL,
    feature_code                   VARCHAR2(6) NOT NULL,
    parameter_code                 VARCHAR2(20) NOT NULL,
    ftr_parm_value                 VARCHAR2(100))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     10485760
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Indexes for NINJA_TIME_PORT_SRV_FTR_PRMS

CREATE UNIQUE INDEX ntpsfp_idx1 ON ninja_time_port_srv_ftr_prms
  (
    ninja_ref_id                    ASC,
    soc                             ASC,
    feature_code                    ASC,
    parameter_code                  ASC
  )
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

CREATE INDEX ntpsrfp_idx2 ON ninja_time_port_srv_ftr_prms
  (
    ninja_ref_id                    ASC,
    soc                             ASC
  )
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/



-- Constraints for NINJA_TIME_PORT_SRV_FTR_PRMS




-- Comments for NINJA_TIME_PORT_SRV_FTR_PRMS

COMMENT ON COLUMN ninja_time_port_srv_ftr_prms.feature_code IS 'The Fokus Socs Feature Code'
/
COMMENT ON COLUMN ninja_time_port_srv_ftr_prms.ftr_parm_value IS 'The Parameter Value (we only store any client sent Values (most are defaulted in Fokus/Ninja)'
/
COMMENT ON COLUMN ninja_time_port_srv_ftr_prms.ninja_ref_id IS 'Unique Key for the Port Order'
/
COMMENT ON COLUMN ninja_time_port_srv_ftr_prms.parameter_code IS 'The Fokus Socs Feature Parameter'
/
COMMENT ON COLUMN ninja_time_port_srv_ftr_prms.soc IS 'The Fokus Soc Code'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SRV_FTR_PRMS

-- Foreign Key
ALTER TABLE ninja_time_port_srv_ftr_prms
ADD CONSTRAINT ntpsfp_fk1 FOREIGN KEY (ninja_ref_id, soc)
REFERENCES ninja_time_port_services (ninja_ref_id,soc)
/
ALTER TABLE ninja_time_port_srv_ftr_prms
ADD CONSTRAINT ntpsfp_fk2 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)


-- Start of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SUB_INFO
-- Generated 20-sep-2005 8:44:04 from NINJADATA@NINJAPROD1.WSRV1.NETCOM-GSM.NO

CREATE TABLE ninja_time_port_sub_info
    (ninja_ref_id                   NUMBER(8,0) NOT NULL,
    dealer_code                    VARCHAR2(5),
    sales_agent                    VARCHAR2(5),
    user_text                      VARCHAR2(2001),
    campaign_code                  VARCHAR2(9),
    agreement_code                 VARCHAR2(15),
    marketing_code                 VARCHAR2(1),
    user_first                     VARCHAR2(32),
    user_last                      VARCHAR2(60),
    user_dob                       DATE,
    role_ind                       VARCHAR2(1) DEFAULT NULL,
    user_keep_old_name_address     VARCHAR2(1) DEFAULT 'N',
    user_address_type              VARCHAR2(1) DEFAULT NULL,
    adr_country                    VARCHAR2(3) DEFAULT NULL

 ,
    adr_city                       VARCHAR2(39),
    adr_zip                        VARCHAR2(9),
    adr_street_name                VARCHAR2(60),
    adr_house_no                   VARCHAR2(20),
    adr_house_letter               VARCHAR2(2),
    adr_storey                     VARCHAR2(2),
    adr_door_no                    VARCHAR2(4),
    adr_pob                        VARCHAR2(10),
    adr_district                   VARCHAR2(40),
    adr_co_name                    VARCHAR2(60),
    email_addr                     VARCHAR2(150),
    additional_title               VARCHAR2(60))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  STORAGE   (
    INITIAL     104857600
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Constraints for NINJA_TIME_PORT_SUB_INFO


ALTER TABLE ninja_time_port_sub_info
ADD CONSTRAINT ntpsi_pk1 PRIMARY KEY (ninja_ref_id)
USING INDEX
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  STORAGE   (
    INITIAL     32768
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/


-- Comments for NINJA_TIME_PORT_SUB_INFO

COMMENT ON COLUMN ninja_time_port_sub_info.additional_title IS 'Additional Title'
/
COMMENT ON COLUMN ninja_time_port_sub_info.agreement_code IS 'Agreement Type if specified'
/
COMMENT ON COLUMN ninja_time_port_sub_info.campaign_code IS 'Campaign Code for the Change Rating'
/
COMMENT ON COLUMN ninja_time_port_sub_info.dealer_code IS 'Dealer Code Responsible for the Porting'
/
COMMENT ON COLUMN ninja_time_port_sub_info.marketing_code IS 'Marketing Code'
/
COMMENT ON COLUMN ninja_time_port_sub_info.ninja_ref_id IS 'Unique Key for the Port Order'
/
COMMENT ON COLUMN ninja_time_port_sub_info.role_ind IS 'Indicates if this user should be a Role'
/
COMMENT ON COLUMN ninja_time_port_sub_info.sales_agent IS 'Sales Agent Responsible for the Porting'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_address_type IS '''R''egular or ''P''ost box'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_dob IS 'Users Date of Birth'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_first IS 'Users First Name'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_keep_old_name_address IS 'Indicates wether the existing Name Address Should be kept (normally won''t)'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_last IS 'Users Last Name'
/
COMMENT ON COLUMN ninja_time_port_sub_info.user_text IS 'Text Specified by the User'
/

-- End of DDL Script for Table NINJADATA.NINJA_TIME_PORT_SUB_INFO

-- Foreign Key
ALTER TABLE ninja_time_port_sub_info
ADD CONSTRAINT ntpsi_fk1 FOREIGN KEY (ninja_ref_id)
REFERENCES ninja_time_port (ninja_ref_id)
/
-- End of DDL script for Foreign Key(s)
